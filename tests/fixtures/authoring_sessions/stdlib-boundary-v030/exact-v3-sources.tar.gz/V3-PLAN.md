# Version 3: enclosing manifest repair, authored before execution

This is informed follow-up after version 2 real observations, not a blind
benchmark. Version 2 omitted common/Qargo.toml, blocking ten source modules
on project edition validation. This NEW packet copies every version-2 file
byte-for-byte and adds common/Qargo.toml with schema-version=2 and
[qrate].edition="2026". All 16 case programs, exact matrix files and independent
requests are unchanged. The copied earlier plans, freeze records and absolute
paths are historical provenance for v2, not instructions to execute.

Fresh manual invocations will explicitly name THIS packet's module paths and
write artifacts to a separate NEW observations directory. For each of the
16 unary selected Raw roots: emit-proposal, verify-ir against its unchanged
preauthored artifact-only request if emission produced an artifact, and a
separate source-step check. No retry or weaker fallback. No recorded argv is
executed. A failed emission leaves dependent verification unperformed.

The immutable CLI is /private/tmp/qleisli-369-experiment-cli-0yu9btrs/qleisli
SHA256 601ec6e800e70d6d085c69c0fe568add0e2faa6429c02dd78ec7b420a71c6578.
The explicit native kernel is
/Users/masa/git/Qleisli/lean-kernel/.lake/build/bin/qleisli-kernel
SHA256 54c9d60b80f67217abd95c8fe6ec1c06aa262e142d5e6db30f46a20cb90faf07.
The copied binary's identity.json describes its runtime build; the current
Git HEAD is an observation, not a compiler/source-preservation attestation.
Record actual CLI/kernel hashes, source closure and HEAD before/after every
invocation, including any changing window; do not retry a changed window.

Programs use at most two qubits. Existing unchanged bundled QFT3 is permitted
if encountered; no new maximum cases. Inspect actual Unit pack/unpack, wire
maps and gate structures separately. CP's symmetric diagonal alone cannot
distinguish exchanged roles. One owned reference case does not prove an
arbitrary-reference theorem. Exact request acceptance is about the emitted
artifact; separate source steps are not a source-to-IR preservation proof.
No hardware, PR, quantitative RS, EXACT discharge, guarantee admission,
compiler preservation or certified synthesis/resource bound is claimed.

The original 32-case first packet, 128 first observations, v2 inputs and v2
observations remain untouched. This file and the manifest are additions only
in this new packet. Execution has not yet begun.
