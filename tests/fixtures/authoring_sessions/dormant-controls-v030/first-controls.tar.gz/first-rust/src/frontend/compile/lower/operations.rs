//! Static descriptions are compile-time arguments, never runtime owners.
use super::super::operations::{Bindings, Operation};
use super::*;

impl Lowerer<'_, '_> {
    pub(super) fn apply_operation(
        &mut self,
        module: &str,
        span: Span,
        op: &Operation,
        value: Value,
        access: Access,
    ) -> Result<Value, CompileError> {
        let slot = self.quantum(module, span, &value, false)?;
        let (domain, codomain) = if access == Access::Adjoint {
            (&op.codomain, &op.basis)
        } else {
            (&op.basis, &op.codomain)
        };
        if self.raw.registers[&slot].basis != *domain {
            return Err(self.error(
                module,
                span,
                ErrorCode::TypeMismatch,
                "operation and argument have different exact basis trees",
            ));
        }
        if !op.needs_raw() {
            let steps = op.steps(module, span, access, self.compiler)?;
            self.apply_circuit(slot, steps);
            self.add_contract_effect(module, span, op.effect);
            return Ok(value);
        }
        let body = op.raw(module, span, access, self.compiler)?;
        let original = &self.raw.registers[&slot];
        let input = QuantumPort {
            token: original.token,
            wires: original.wires.clone(),
            shape: body.boundary().input().shape,
        };
        let start = self.raw.operations.len();
        let output = crate::frontend::raw_splice::append(
            &mut self.raw,
            body.program(),
            &input,
            &mut self.compiler.exact_work,
        )
        .map_err(|e| self.compiler.op_error(module, span, e))?;
        // Check the actual renamed fragment, including its concrete ordered ports.
        let emitted = RawProgram {
            quantum_inputs: vec![input],
            classical_inputs: vec![],
            operations: self.raw.operations[start..].to_vec(),
            quantum_outputs: vec![output.token],
            classical_outputs: vec![],
            declared_effect: body.program().raw().declared_effect,
        };
        crate::frontend::pure::check(
            &self.compiler.kernel,
            &emitted,
            body.boundary().domain(),
            body.boundary().codomain(),
            Some(body.meaning()),
            &mut self.compiler.exact_work,
        )
        .map_err(|e| self.compiler.op_error(module, span, e))?;
        self.add_effect(module, span, emitted.declared_effect);
        self.add_contract_effect(module, span, op.effect);
        self.raw.registers.insert(
            slot,
            Register {
                token: output.token,
                wires: output.wires,
                basis: codomain.clone(),
            },
        );
        Ok(Value::Quantum(slot, Ty::quantum(codomain.clone())))
    }
    pub(super) fn constructed_inverse(
        &mut self,
        module: &str,
        span: Span,
        operation: &StaticOp,
        input: &Expr,
        env: &mut Env,
    ) -> Result<Value, CompileError> {
        let value = self.expr(module, input, env)?;
        let op = self.operation(module, operation, env)?;
        self.apply_operation(module, span, &op, value, Access::Adjoint)
    }

    pub(super) fn controlled_application(
        &mut self,
        module: &str,
        span: Span,
        operation: &StaticOp,
        args: &[Expr],
        env: &mut Env,
    ) -> Result<Value, CompileError> {
        let [control, target] = args else {
            return Err(self.error(
                module,
                span,
                ErrorCode::TypeMismatch,
                "controlled application requires a control and a target",
            ));
        };
        let c = self.expr(module, control, env)?;
        self.quantum(module, control.span, &c, true)?;
        let q = self.expr(module, target, env)?;
        let slot = self.quantum(module, target.span, &q, false)?;
        let op = self.operation(module, operation, env)?;
        if op.basis != self.raw.registers[&slot].basis {
            return Err(self.error(
                module,
                span,
                ErrorCode::TypeMismatch,
                "controlled operation and target have different exact basis trees",
            ));
        }
        let steps = op.steps(module, span, Access::Controlled, self.compiler)?;
        self.add_contract_effect(module, span, op.effect);
        let joined = self.sealed(module, span, "std::quantum", "join", vec![c, q])?;
        let slot = self.quantum(module, span, &joined, false)?;
        self.apply_circuit(slot, steps);
        self.sealed(module, span, "std::quantum", "split", vec![joined])
    }

    pub(super) fn bound_operation(&self, name: &Ident) -> Option<&Operation> {
        let id = self.compiler.locals().usage(name).static_parameter?;
        self.bindings.get(self.compiler.locals().key(id))
    }

    pub(super) fn operation(
        &mut self,
        module: &str,
        expr: &StaticOp,
        env: &Env,
    ) -> Result<Operation, CompileError> {
        self.compiler.tick(module, expr.span)?;
        // Parser and each constructed description bound recursive depth.
        match &expr.kind {
            StaticOpKind::Type(_) | StaticOpKind::Natural(_) | StaticOpKind::Specialize { .. } => {
                Err(self.error(
                    module,
                    expr.span,
                    ErrorCode::Unsupported,
                    "static argument is outside the finite lowering profile",
                ))
            }
            StaticOpKind::Name(name) => {
                self.static_name(module, name, env)?;
                if let Some(op) = self.bound_operation(name) {
                    let cost = op.copy_size();
                    self.compiler.charge(module, name.span, cost)?;
                    return Ok(self
                        .bound_operation(name)
                        .expect("retained static binding")
                        .clone());
                }
                self.compiler.provider(module, name, None)
            }
            StaticOpKind::Bind {
                implementation,
                meaning,
            } => {
                for name in [implementation, meaning] {
                    self.static_name(module, name, env)?;
                    if self.bound_operation(name).is_some() {
                        return Err(self.error(
                            module,
                            name.span,
                            ErrorCode::TypeMismatch,
                            "checked_op requires closed declarations",
                        ));
                    }
                }
                self.compiler
                    .provider(module, implementation, Some(meaning))
            }
            StaticOpKind::Inverse(a) | StaticOpKind::Controlled(a) | StaticOpKind::Repeat(_, a) => {
                let a = self.operation(module, a, env)?;
                self.compiler
                    .construct(module, expr.span, &expr.kind, a, None)
            }
            StaticOpKind::Then(a, b)
            | StaticOpKind::Tensor(a, b)
            | StaticOpKind::Conjugate(a, b) => {
                let a = self.operation(module, a, env)?;
                let b = self.operation(module, b, env)?;
                self.compiler
                    .construct(module, expr.span, &expr.kind, a, Some(b))
            }
        }
    }

    pub(super) fn static_name(
        &self,
        module: &str,
        name: &Ident,
        env: &Env,
    ) -> Result<(), CompileError> {
        if self
            .compiler
            .locals()
            .local_key(name)
            .is_some_and(|key| env.contains_key(key))
        {
            return Err(self.error(
                module,
                name.span,
                ErrorCode::TypeMismatch,
                "a local or spent runtime value cannot be a static operation",
            ));
        }
        Ok(())
    }

    pub(super) fn bind_operations(
        &mut self,
        key: &Key,
        args: &[StaticOp],
        env: &Env,
        site: CallSite<'_>,
    ) -> Result<Bindings, CompileError> {
        let decl = self.compiler.declarations[key];
        if decl.static_params.len() != args.len() {
            return Err(self.error(
                site.module,
                site.span,
                ErrorCode::Arity,
                "explicit static argument count does not match",
            ));
        }
        if args.is_empty() {
            return Ok(Bindings::new());
        }
        let expected = self.compiler.required_bindings(key)?;
        self.compiler
            .charge(site.module, site.span, args.len().saturating_mul(2))?;
        let mut bindings = Bindings::new();
        let mut identity = Vec::with_capacity(args.len());
        for (param, arg) in decl.static_params.iter().zip(args) {
            let actual = self.operation(site.module, arg, env)?;
            let binding = self.compiler.locals().binder(&param.name);
            let required = &expected[self.compiler.locals().key(binding)];
            self.compiler
                .validate_required_operation(required, &actual, site.module, arg.span)?;
            self.compiler.charge(
                site.module,
                arg.span,
                actual
                    .copy_size()
                    .saturating_mul(2)
                    .saturating_add(self.compiler.locals().key(binding).name.len())
                    .saturating_add(1),
            )?;
            identity.push(actual.clone());
            bindings.insert(self.compiler.locals().key(binding).clone(), actual);
        }
        self.compiler
            .record_operation_instance(*key, identity, site.module, site.span)?;
        Ok(bindings)
    }

    pub(super) fn operation_steps(
        &mut self,
        module: &str,
        name: &Ident,
        basis: &Ty,
        env: &Env,
        access: Access,
    ) -> Result<Option<Vec<CircuitStep>>, CompileError> {
        let Some(op) = self.bound_operation(name) else {
            return Ok(None);
        };
        let cost = op.copy_size();
        self.compiler.charge(module, name.span, cost)?;
        let op = self
            .bound_operation(name)
            .expect("retained static binding")
            .clone();
        self.static_name(module, name, env)?;
        if op.basis != *basis {
            return Err(self.error(
                module,
                name.span,
                ErrorCode::TypeMismatch,
                format!("operation and input have different exact basis trees: expected `Q<{}>`, found `Q<{basis}>`", op.basis),
            ));
        }
        self.add_contract_effect(module, name.span, op.effect);
        Ok(Some(op.steps(module, name.span, access, self.compiler)?))
    }

    pub(super) fn call_bound(
        &mut self,
        key: &Key,
        args: Vec<Value>,
        site: Option<CallSite<'_>>,
        bindings: Bindings,
    ) -> Result<Value, CompileError> {
        let previous = std::mem::replace(&mut self.bindings, bindings);
        let result = self.call_user(key, args, site);
        self.bindings = previous;
        result
    }
}
