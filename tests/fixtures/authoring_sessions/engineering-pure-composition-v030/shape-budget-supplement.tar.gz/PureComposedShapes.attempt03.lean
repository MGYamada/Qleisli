import PureComposedKernel
import PureComposedExamplesV1

/-! TP-31-PURE-COMPOSED-SHAPES-02, P1, supplemental bounded manual original IR.
Replace after reviewed production integration; retain first source/diagnostics.
No source or target preservation, accepted handle, access, cleanup or resources.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace PureComposedShapes
open QleisliKernel QleisliKernel.Semantics.Exact QleisliKernel.Semantics.Finite
open QleisliKernel.Semantics.Raw QleisliKernel.Semantics.Observation
open QleisliKernel.Qirf.EngineeringPure

private def literal (domain codomain : Basis) (input output : Port)
    (operations : List QleisliKernel.Semantics.Observation.Op) (effect : Effect)
    (required : Matrix) : LeafRequest :=
  ⟨⟨#[⟨[input],[],operations,[output.token],[],effect⟩],#[],#[],0,some (domain,codomain)⟩,
    #[0],input,output,required⟩

private def onePreparation (phase : Nat) : LeafRequest :=
  literal [.unit] [.bit] ⟨0,[],0⟩ ⟨3,[0],1⟩
    [.pure (.unpackUnit 0),.pure (.init0 1 0),.pure (.gate .x 1 2),
      .pure (.applyUnitary 2 3 (PureComposedExamples.phaseSteps 0 phase))] .iso
    ⟨2,1,[Scalar.zero,Exact.Scalar.phase phase]⟩

private def preparationComparison (epsilon : Coefficient := ⟨7,3⟩) : Request :=
  ⟨[.unit],[.bit],onePreparation 0,onePreparation 1,epsilon⟩

private def unitSteps (phase : Nat) : List Step := [⟨[],.monomial [] [0] [phase]⟩]
private def unitLeaf (phase : Nat) : LeafRequest :=
  literal [.unit] [.unit] ⟨0,[],0⟩ ⟨1,[],0⟩ [.pure (.applyUnitary 0 1 (unitSteps phase))]
    .unitary ⟨1,1,[Exact.Scalar.phase phase]⟩
private def unitComparison (phase : Nat := 1) (epsilon : Coefficient := ⟨7,3⟩) : Request :=
  ⟨[.unit],[.unit],unitLeaf 0,unitLeaf phase,epsilon⟩

private def asymmetricMatrix (left right : Nat) : Matrix :=
  ⟨4,2,(List.range 8).map fun index =>
    let row : Nat := index/2
    let col : Nat := index%2
    if row%2 = 1 && row/2 = col then Exact.Scalar.phase ((left + right*col : Nat) : Int) else Scalar.zero⟩
private def asymmetricParent (left right : Nat) : LeafRequest :=
  literal [.pair,.unit,.bit] [.pair,.bit,.bit] ⟨0,[0],1⟩ ⟨7,[1,0],2⟩
    [.pure (.split 0 1 2 0),.pure (.unpackUnit 1),.pure (.init0 3 1),.pure (.gate .x 3 4),
     .pure (.applyUnitary 4 5 (PureComposedExamples.phaseSteps 0 left)),
     .pure (.applyUnitary 2 6 (PureComposedExamples.phaseSteps 0 right)),.pure (.join 5 6 7)]
    .iso (asymmetricMatrix left right)

def asymmetric : Qirf.EngineeringPureComposed.Request :=
  ⟨preparationComparison,PureComposedExamples.compareRight,asymmetricParent 0 0,asymmetricParent 1 0⟩
def asymmetricTwoBudgets : Qirf.EngineeringPureComposed.Request :=
  {asymmetric with right := PureComposedExamples.compareLeft,parentIdeal := asymmetricParent 1 1}

private def reverseMatrix (left right : Nat) : Matrix :=
  ⟨4,2,(List.range 8).map fun index =>
    let row : Nat := index/2
    let col : Nat := index%2
    if row/2 = 1 && row%2 = col then Exact.Scalar.phase ((left*col + right : Nat) : Int) else Scalar.zero⟩
private def reverseParent (left right : Nat) : LeafRequest :=
  literal [.pair,.bit,.unit] [.pair,.bit,.bit] ⟨0,[0],1⟩ ⟨7,[0,1],2⟩
    [.pure (.split 0 1 2 1),.pure (.unpackUnit 2),
     .pure (.applyUnitary 1 3 (PureComposedExamples.phaseSteps 0 left)),
     .pure (.init0 4 1),.pure (.gate .x 4 5),
     .pure (.applyUnitary 5 6 (PureComposedExamples.phaseSteps 0 right)),.pure (.join 3 6 7)]
    .iso (reverseMatrix left right)
private def swappedAsymmetricParent (left right : Nat) : LeafRequest :=
  literal [.pair,.unit,.bit] [.pair,.bit,.bit] ⟨0,[0],1⟩ ⟨7,[0,1],2⟩
    [.pure (.split 0 1 2 0),.pure (.unpackUnit 1),.pure (.init0 3 1),.pure (.gate .x 3 4),
     .pure (.applyUnitary 4 5 (PureComposedExamples.phaseSteps 0 left)),
     .pure (.applyUnitary 2 6 (PureComposedExamples.phaseSteps 0 right)),.pure (.join 6 5 7)]
    .iso (reverseMatrix right left)

def asymmetricReverse : Qirf.EngineeringPureComposed.Request :=
  ⟨PureComposedExamples.compareLeft,preparationComparison,reverseParent 0 0,reverseParent 1 1⟩

private def zeroLeftMatrix (left right : Nat) : Matrix :=
  ⟨2,2,[Exact.Scalar.phase left,Scalar.zero,Scalar.zero,Exact.Scalar.phase (left+right)]⟩
private def zeroLeftParent (left right : Nat) : LeafRequest :=
  literal [.pair,.unit,.bit] [.pair,.unit,.bit] ⟨0,[0],1⟩ ⟨5,[0],1⟩
    [.pure (.split 0 1 2 0),.pure (.applyUnitary 1 3 (unitSteps left)),
      .pure (.applyUnitary 2 4 (PureComposedExamples.phaseSteps 0 right)),.pure (.join 3 4 5)]
    .unitary (zeroLeftMatrix left right)
def zeroLeft : Qirf.EngineeringPureComposed.Request :=
  ⟨unitComparison,PureComposedExamples.compareLeft,zeroLeftParent 0 0,zeroLeftParent 1 1⟩

private def zeroRightParent (left right : Nat) : LeafRequest :=
  literal [.pair,.bit,.unit] [.pair,.bit,.unit] ⟨0,[0],1⟩ ⟨5,[0],1⟩
    [.pure (.split 0 1 2 1),.pure (.applyUnitary 1 3 (PureComposedExamples.phaseSteps 0 left)),
      .pure (.applyUnitary 2 4 (unitSteps right)),.pure (.join 3 4 5)]
    .unitary (zeroLeftMatrix right left)
def zeroRight : Qirf.EngineeringPureComposed.Request :=
  ⟨PureComposedExamples.compareLeft,unitComparison,zeroRightParent 0 0,zeroRightParent 1 1⟩

private def zeroPairParent (left right : Nat) : LeafRequest :=
  literal [.pair,.unit,.unit] [.pair,.unit,.unit] ⟨0,[],0⟩ ⟨5,[],0⟩
    [.pure (.split 0 1 2 0),.pure (.applyUnitary 1 3 (unitSteps left)),
      .pure (.applyUnitary 2 4 (unitSteps right)),.pure (.join 3 4 5)]
    .unitary ⟨1,1,[Exact.Scalar.phase (left+right)]⟩
def zeroPair : Qirf.EngineeringPureComposed.Request :=
  ⟨unitComparison,unitComparison,zeroPairParent 0 0,zeroPairParent 1 1⟩
def exactZeroPair : Qirf.EngineeringPureComposed.Request :=
  ⟨unitComparison 0 ⟨0,0⟩,unitComparison 0 ⟨0,0⟩,zeroPairParent 0 0,zeroPairParent 0 0⟩

private def report (request : Qirf.EngineeringPureComposed.Request) : String × Option Coefficient × Nat :=
  let (answer,left) := (Qirf.EngineeringPureComposed.check request).run 2000000
  (match answer with | .ok _ => "ok" | .error error => reprStr error,
    match answer with | .ok checked => some checked.epsilon | .error _ => none,left)

#eval ("rectangular left 2x1 tensor right 2x2",report asymmetric)
#eval ("rectangular two nonzero budgets",report asymmetricTwoBudgets)
#eval ("rectangular left 2x2 tensor right 2x1",report asymmetricReverse)
#eval ("zero-width left Unit tensor Bit",report zeroLeft)
#eval ("zero-width right Bit tensor Unit",report zeroRight)
#eval ("both zero-width logical owners",report zeroPair)
#eval ("both zero-width exact epsilon zero",report exactZeroPair)
#eval ("rectangular ordered wires substitution refused",report {asymmetric with
  parentIdeal := {asymmetric.parentIdeal with output := ⟨7,[0,1],2⟩}})
#eval ("rectangular equal-width input tree substitution refused",report {asymmetric with
  parentIdeal := {asymmetric.parentIdeal with artifact := {asymmetric.parentIdeal.artifact with
    rootInterface := some ([.pair,.bit,.unit],[.pair,.bit,.bit])}}})
#eval ("rectangular equal-width output tree substitution refused",report {asymmetric with
  parentIdeal := {asymmetric.parentIdeal with artifact := {asymmetric.parentIdeal.artifact with
    rootInterface := some ([.pair,.unit,.bit],[.tuple 2,.bit,.bit])}}})
#eval ("rectangular actual parent axes swapped and typed consistently",report {asymmetric with
  parentIdeal := swappedAsymmetricParent 1 0})
#eval ("swapped asymmetric parent independently valid",
  ((Qirf.PureLeaf.check (swappedAsymmetricParent 1 0).artifact (swappedAsymmetricParent 1 0).order
    [.pair,.unit,.bit] [.pair,.bit,.bit] (swappedAsymmetricParent 1 0).input
    (swappedAsymmetricParent 1 0).output (swappedAsymmetricParent 1 0).required).run 2000000).1.isOk)
#eval ("zero-width parent Unit replaces Unit pair refused",report {zeroPair with
  parentIdeal := unitLeaf 2})
#eval ("zero-width component erased owner output refused",report {zeroPair with
  left := {zeroPair.left with ideal := {zeroPair.left.ideal with output := ⟨1,[],1⟩}}})
#eval ("zero-width component wires substitution refused",report {zeroLeft with
  left := {zeroLeft.left with ideal := {zeroLeft.left.ideal with input := ⟨0,[0],0⟩}}})

-- These bounded facts reduce the original checker in Lean's kernel.
theorem asymmetric_accepts : ((Qirf.EngineeringPureComposed.check asymmetric).run 2000000).1.isOk = true := by decide +kernel
theorem asymmetric_two_budgets_accepts : ((Qirf.EngineeringPureComposed.check asymmetricTwoBudgets).run 2000000).1.isOk = true := by decide +kernel
theorem asymmetric_reverse_accepts : ((Qirf.EngineeringPureComposed.check asymmetricReverse).run 2000000).1.isOk = true := by decide +kernel
theorem zero_left_accepts : ((Qirf.EngineeringPureComposed.check zeroLeft).run 2000000).1.isOk = true := by decide +kernel
theorem zero_right_accepts : ((Qirf.EngineeringPureComposed.check zeroRight).run 2000000).1.isOk = true := by decide +kernel
theorem zero_pair_accepts : ((Qirf.EngineeringPureComposed.check zeroPair).run 2000000).1.isOk = true := by decide +kernel
theorem exact_zero_pair_accepts : ((Qirf.EngineeringPureComposed.check exactZeroPair).run 2000000).1.isOk = true := by decide +kernel
theorem swapped_parent_accepts :
    ((Qirf.PureLeaf.check (swappedAsymmetricParent 1 0).artifact (swappedAsymmetricParent 1 0).order
      [.pair,.unit,.bit] [.pair,.bit,.bit] (swappedAsymmetricParent 1 0).input
      (swappedAsymmetricParent 1 0).output (swappedAsymmetricParent 1 0).required).run 2000000).1.isOk = true := by decide +kernel
theorem typed_axis_substitution_refuses :
    ((Qirf.EngineeringPureComposed.check {asymmetric with parentIdeal := swappedAsymmetricParent 1 0}).run 2000000).1.isOk = false := by decide +kernel

end PureComposedShapes
