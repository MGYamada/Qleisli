# Bounded zero-basis hierarchy adapter

The original four programs and all twelve first diagnostics are immutable. The observer was invoked through Python stdin; there is no saved pre-invocation driver file. Recorded argument arrays, hashes and full streams are the original observations. The first ordinary-project commands encounter the existing main-entry contract; later wrappers are separate translations.

## Existing source contract and gates

Reference coherent-basis specifies exact coefficient +1, complete input/output types and arbitrary retained references. Selected Raw already accepts the four sources with a separate original-step comparison. The hierarchy currently refuses every basis table at lower::hierarchy_eligibility. Existing native hierarchy structural nodes distinguish pack/unpack Unit and Bits0, and its initialize-unitary-readout transport explicitly counts fresh zero wires. Neither a source name nor a producer annotation supplies acceptance. Native reconstruction and the existing preparation replay remain required.

## Bounded implementation

Admit only original unary coherent tables whose input/output are Unit or Bits0 with table [0], or whose Unit/Bits0 input prepares exact Bit zero with table [0]. Other coherent tables retain the current refusal; this task does not claim general table synthesis. A distinct Bit-one branch would require a source-bound exact X interval, so it is deliberately left out of this first adapter.

For width-zero Unit/Bits0 transitions, emit a phase-+1 structural unpack of the exact input atom and pack of the exact output atom. Do not identify their types by width. Preserve unchanged caller owners through existing explicit frame/tensor routing.

For preparation, allocate one globally fresh physical Bit through the existing init0 preparation carrier. The corresponding pure interval consumes the original zero-width owner using its exact unpack node, tensors the fresh Bit identity, and renames the Bit to the exact source result owner. Retain the fresh internal Port in the source event; it is not a new source input. Its event is tied to the original table [0], exact Unit/Bits0 input, Bit output, original owner/path/location and actual serialized interval. Stable extraction moves this initialization before earlier disjoint pure events, preserving their original order, phase and full frame. A zero-width phase already attached to the source input must survive its unpack; preparation introduces no replacement phase convention.

Extend preparation replay with one explicit basis-preparation event: recheck the original source table/types/effect, fresh owner/axis, actual unpack/tensor/rename interval and complete frames. Preserve existing trace/call/axis/node/storage bounds. The preparation outputs and initialization records must still match every fresh physical Bit exactly. Pure width-zero steps receive the same exact interval comparison in instrument replay; unitary root source-step validation is a separate bounded adapter check before publication of a proposal, not a theorem.

## Review risks and validation

Check exact Unit versus Bits0 endpoints, table mutation, a native-valid scalar-phase replacement, owner/axis substitution, omitted preparation and duplicated fresh Bit. Validate with native hierarchy and independently intended exact small requests/finite matrices where existing APIs permit. Retain the one-reference scalar-phase source and compare original source-associated intervals, not sampled probabilities. Existing native validity is not source elaboration correctness or a general QS/PR/RS discharge. No new native opcode, schema, acceptance logic, proof, version, dependency or budget is proposed.
