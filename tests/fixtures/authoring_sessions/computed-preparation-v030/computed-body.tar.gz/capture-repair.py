import hashlib,json,subprocess
from pathlib import Path
root=Path('/Users/masa/git/Qleisli');out=Path(__file__).parent;attempt=out/'attempt-02';attempt.mkdir()
cli=root/'target/debug/qleisli';kernel=root/'lean-kernel/.lake/build/bin/qleisli-kernel'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def window():return {str(p.relative_to(root)):sha(p) for p in sorted((root/'src').rglob('*.rs'))+sorted((root/'stdlib/src').glob('*.qli'))+[root/'Cargo.toml']}
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True)
first=json.loads((out/'plan.json').read_text());plan={'kind':'minimal first-source diagnostic repair','repair':'rename parameterized quantum main declaration to subject; no body/contract change','driver_sha256':sha(Path(__file__)),'first_plan_sha256':sha(out/'plan.json'),'head_before':git('rev-parse','HEAD').strip(),'dirty_before':git('status','--short'),'sources_before':window(),'executables_before':{str(p):sha(p) for p in [cli,kernel]},'build_attestation':False,'cases':{}}
for name,old in first['cases'].items():
 target=attempt/name;target.mkdir();source=(out/name/'main.qli').read_text();assert source.count('pub unitary fn main(')==1;source=source.replace('pub unitary fn main(','pub unitary fn subject(')
 (target/'main.qli').write_text(source);(target/'Qargo.toml').write_bytes((out/name/'Qargo.toml').read_bytes())
 plan['cases'][name]={'prediction':old['prediction'],'original_source_sha256':old['source_sha256'],'source_sha256':sha(target/'main.qli'),'manifest_sha256':sha(target/'Qargo.toml')}
with (out/'repair-plan.json').open('x') as f:f.write(json.dumps(plan,indent=2)+'\n')
rows=[]
for name in first['cases']:
 argv=[str(cli),'check',str(attempt/name),'--lean-kernel='+str(kernel)];result=subprocess.run(argv,cwd=root,capture_output=True,timeout=60);row={'case':name,'argv':argv,'exit_code':result.returncode}
 for stream in ['stdout','stderr']:
  p=attempt/(name+'.'+stream+'.txt');p.write_bytes(getattr(result,stream));row[stream]={'path':str(p.relative_to(out)),'sha256':sha(p)}
 row['source_sha256_after']=sha(attempt/name/'main.qli');rows.append(row);print(json.dumps({'case':name,'exit':result.returncode}),flush=True)
record={'head_after':git('rev-parse','HEAD').strip(),'dirty_after':git('status','--short'),'sources_after':window(),'executables_after':{str(p):sha(p) for p in [cli,kernel]},'observations':rows,'build_attestation':False}
record['executables_stable']=record['executables_after']==plan['executables_before'];record['wip_sources_stable']=record['sources_after']==plan['sources_before'];record['original_sources_stable']=all(r['source_sha256_after']==plan['cases'][r['case']]['source_sha256'] for r in rows)
with (out/'repair-observations.json').open('x') as f:f.write(json.dumps(record,indent=2)+'\n')
assert record['executables_stable'] and record['original_sources_stable']
print(json.dumps({'packet':str(out),'wip_sources_stable':record['wip_sources_stable']}),flush=True)
