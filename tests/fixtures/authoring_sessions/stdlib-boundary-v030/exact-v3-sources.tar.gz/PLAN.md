# Version 2: independent exact request experiment (UNPERFORMED)

This is informed follow-up authoring after reading the 128 first observations.
It is not a blind benchmark. No build, CLI, API or native check was executed.
The first 32 cases/165 files and every first observation remain unchanged.

The current selected CLI can emit each unary open source root with
`emit-proposal --entry=main::entry --ir-profile=raw --module=... --output=...`.
Emission is untrusted. Then existing `verify-ir ARTIFACT --against=REQUEST
--lean-kernel=KERNEL --format=json` performs fresh native exact checking of
that actual QIRF against a separately authored phase8/permutation request.
There is no Raw `--request` option: selected `--request` selects hierarchy;
`--against` belongs to verify-ir. Do not reinterpret either option or retry a
failed check through a weaker request.

All requests were authored before execution. They specify complete exact
endomorphic Bit or ordered pair(Bit,Bit) type trees. Kernel QIRF requested
checking requires the original root_interface to equal both requested trees.
Source-bound requests additionally retain the exact logical source snapshot
(names/text/order), including all five captured ordinary bundled modules.
Artifact-only counterparts deliberately omit that extra identity requirement;
they are a distinct stated scope, never a fallback for a failed bound request.
Requests bind source bytes, not a proof of source-to-IR preservation.

Pack reference/control/SWAP into one Q<(Bit,Bit)> owner so the existing unary
finite request/leaf route applies. Source checks should separately validate
actual original source steps. A CLI native exact request success must report
request_checked=true; generic source_meaning_verified/source preservation
claims remain false. Record each original source, argv, raw stream, artifact,
request bytes, SHA256 and the actual unchanged CLI/kernel identity window.

The independent matrices are copied unchanged from the first frozen packet.
Exact-matrix files use existing qleisli.finite-matrix/zeta8-dyadic-v1 coefficients
(a+b sqrt(2)+i(c+d sqrt(2))). They are mathematical input, not certificates.
An optional existing API check is finite_leaf::check_serialized_unitary with
an independently specified UnitaryBoundary and those bytes under one bounded
Budget; it selects QLEISLI_KERNEL. Derive no expected matrix from the producer.
Actual port tokens/maps must be inspected and checked against the stated
ordered boundary before calling; do not silently copy a claimed boundary as
its own independent expectation. finite_meaning_target can supply the exact
matrix of an authored phase_by/permutation_by Meaning, but does not itself
prove any provider or SourceDefinition conforms.

Positive wire/resource gaps remain unperformed: compare actual input/output
wire maps (structural [1,0], physical [0,1]), zero extra physical wires for T,
explicit Unit pack/unpack history and actual emitted gate/synthesis work.
Matrix equality alone cannot distinguish structural routing from physical
SWAP or certify cost. CP's symmetric diagonal cannot detect exchanged owner
roles; ordered source replay/wire maps or a further noncommuting probe is
needed. The owned-reference case covers one extra qubit, not a general
arbitrary-reference theorem. No hardware, PR/quantitative RS, EXACT discharge,
new guarantee, compiler preservation, native implementation or fallback claim.

No extra qubits beyond two are authored. Existing unchanged bundled qft3 may
be encountered by project/finite checks; do not generate new maximum cases.
The fixed CP and public unused-generic supplement are NEW sources here;
first-source mistakes and first observed refusals are not repaired in place.
