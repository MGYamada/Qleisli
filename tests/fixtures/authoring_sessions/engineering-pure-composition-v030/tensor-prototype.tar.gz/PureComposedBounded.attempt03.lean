import PureComposedMath
import PureComposedExamples

/-! TP-31-PURE-COMPOSED-01, P1: bounded original-IR demonstration.
Replace after reviewed composed-protocol integration; preserve before removal.
No source/target preservation, resource authority or exact handle promotion.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace Qleisli.EngineeringPureComposed
open PureComposedExamples
open QleisliKernel.Qirf.EngineeringPureComposed

/-- The actual bounded positive has a complete checked original-body meaning
and the exact 7/8 composed budget; success is reduced by Lean's kernel. -/
theorem bounded_original_meaning : ∃ checked remaining,
    (check composed).run 2000000 = (.ok checked,remaining) ∧
      Meaning composed checked ∧ checked.epsilon = ⟨7,3⟩ := by
  have accepted := composed_accepts
  cases execution : (check composed).run 2000000 with
  | mk result remaining =>
    cases result with
    | error error =>
      rw [execution] at accepted
      change false = true at accepted
      cases accepted
    | ok checked =>
      have meaning := check_meaning composed checked 2000000 remaining execution
      have facts := check_postcondition composed checked 2000000 remaining execution
      have addition : QleisliKernel.Exact.Coefficient.add composed.left.epsilon
          composed.right.epsilon = .ok ⟨7,3⟩ := by decide +kernel
      have epsilon : checked.epsilon = ⟨7,3⟩ := Except.ok.inj (facts.epsilonAdd.symm.trans addition)
      exact ⟨checked,remaining,rfl,meaning,epsilon⟩

/-- The genuinely checked two-qubit parent retains 7/8 against every finite
external reference, despite the whole Frobenius witness refusing that budget. -/
theorem bounded_reference {R : Type} [Fintype R] :
    ‖Qleisli.EngineeringPureComposition.operator
      (Qleisli.EngineeringPureComposition.liftLeft (R := R)
        (Qleisli.EngineeringPureComposition.matrixAt 4 4 parentActual.required -
          Qleisli.EngineeringPureComposition.matrixAt 4 4 parentIdeal.required))‖ ≤ (7/8 : ℝ) := by
  obtain ⟨checked,remaining,execution,_,epsilon⟩ := bounded_original_meaning
  have bound := checked_reference_bound (R := R) composed checked 2000000 remaining execution
  rw [epsilon] at bound
  have budget : (Qleisli.Semantics.Exact.rational (⟨7,3⟩ : QleisliKernel.Semantics.Exact.Coefficient) : ℝ) =
      (7/8 : ℝ) := by norm_num [Qleisli.Semantics.Exact.rational]
  rw [budget] at bound
  exact bound

end Qleisli.EngineeringPureComposed
