import QleisliKernel.Finite

/-! Concrete pre-implementation algebra for #64/#195, using existing executable
R8 definitions. This study creates no production acceptance or source theorem.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/

namespace QleisliExperiment.FiniteADT64V2
open QleisliKernel.Semantics.Exact

-- Structural decidability for the standard result wrapper; no runtime override.
deriving instance DecidableEq for Except

set_option maxRecDepth 10000
set_option maxHeartbeats 5000000

def integerScalar (n : Int) : Scalar :=
  ⟨.integer n, .integer 0, .integer 0, .integer 0⟩

def integerMatrix (rows cols : Nat) (entries : List Int) : Matrix :=
  ⟨rows, cols, entries.map integerScalar⟩

def diagonal (values : List Scalar) : Matrix :=
  let n := values.length
  ⟨n,n,(List.range (n*n)).map fun k =>
    if k / n == k % n then values[k / n]?.getD Scalar.zero else Scalar.zero⟩

def embedding : Matrix := integerMatrix 4 3
  [1,0,0, 0,1,0, 0,0,1, 0,0,0]

def projection : Matrix := integerMatrix 3 4
  [1,0,0,0, 0,1,0,0, 0,0,1,0]

def reorderedEncoding : Matrix := integerMatrix 4 3
  [1,0,0, 0,0,1, 0,1,0, 0,0,0]

def logicalCycle : Matrix := integerMatrix 3 3
  [0,0,1, 1,0,0, 0,1,0]

def physicalCycle : Matrix := integerMatrix 4 4
  [0,0,1,0, 1,0,0,0, 0,1,0,0, 0,0,0,1]

def physicalIdentity : Matrix := diagonal (List.replicate 4 Scalar.one)
def logicalPhases : Matrix := diagonal
  [Scalar.one, integerScalar (-1), QleisliKernel.Exact.Scalar.phase 2]
def physicalPhases : Matrix := diagonal
  [Scalar.one, integerScalar (-1), QleisliKernel.Exact.Scalar.phase 2, Scalar.one]

def value {α : Type} (action : QleisliKernel.Exact.WorkM α) :
    Except QleisliKernel.Exact.Error α := (action.run 100000).1

/-- Failed computations never count as agreement. This is an experimental
equation, not a production acceptance function or a proposed semantic meaning. -/
def agrees (physical logical encoding : Matrix) : Bool :=
  match value (QleisliKernel.Exact.Matrix.composeWork physical encoding),
      value (QleisliKernel.Exact.Matrix.composeWork encoding logical) with
  | .ok actual, .ok required => actual == required
  | _, _ => false

theorem embedding_isometry :
    value (QleisliKernel.Exact.Matrix.isometryWork embedding) = .ok true := by decide

theorem logical_cycle_isometry :
    value (QleisliKernel.Exact.Matrix.isometryWork logicalCycle) = .ok true := by decide

theorem physical_cycle_isometry :
    value (QleisliKernel.Exact.Matrix.isometryWork physicalCycle) = .ok true := by decide

theorem cycle_binding : agrees physicalCycle logicalCycle embedding = true := by decide

theorem wrong_dependency_isometry :
    value (QleisliKernel.Exact.Matrix.isometryWork physicalIdentity) = .ok true := by decide

theorem wrong_dependency_refused :
    agrees physicalIdentity logicalCycle embedding = false := by decide

theorem reordered_encoding_isometry :
    value (QleisliKernel.Exact.Matrix.isometryWork reorderedEncoding) = .ok true := by decide

theorem wrong_axis_binding_refused :
    agrees physicalCycle logicalCycle reorderedEncoding = false := by decide

theorem physical_phase_isometry :
    value (QleisliKernel.Exact.Matrix.isometryWork physicalPhases) = .ok true := by decide

theorem phase_binding : agrees physicalPhases logicalPhases embedding = true := by decide

theorem lost_relative_phase_refused :
    agrees physicalIdentity logicalPhases embedding = false := by decide

theorem code_left_inverse :
    value (QleisliKernel.Exact.Matrix.composeWork projection embedding) =
      QleisliKernel.Exact.Matrix.identity 3 := by decide

theorem code_projection_is_not_full_identity :
    value (QleisliKernel.Exact.Matrix.composeWork embedding projection) ≠
      QleisliKernel.Exact.Matrix.identity 4 := by decide

theorem code_projection_is_not_whole_space_isometry :
    value (QleisliKernel.Exact.Matrix.isometryWork projection) = .ok false := by decide

def currentEncoding : QleisliKernel.Semantics.Finite.Encoding :=
  ⟨[.bits 2], [.bits 2], embedding⟩

/-- The current public finite basis has no three-element carrier constructor.
Its Bits<2> encoding correctly requires four logical columns. -/
theorem current_native_encoding_refuses_width_substitution :
    ((QleisliKernel.Finite.encodingRead currentEncoding).run 100000).1 =
      .error .invalid := by decide

#print axioms embedding_isometry
#print axioms logical_cycle_isometry
#print axioms physical_cycle_isometry
#print axioms cycle_binding
#print axioms wrong_dependency_isometry
#print axioms wrong_dependency_refused
#print axioms reordered_encoding_isometry
#print axioms wrong_axis_binding_refused
#print axioms physical_phase_isometry
#print axioms phase_binding
#print axioms lost_relative_phase_refused
#print axioms code_left_inverse
#print axioms code_projection_is_not_full_identity
#print axioms code_projection_is_not_whole_space_isometry
#print axioms current_native_encoding_refuses_width_substitution

end QleisliExperiment.FiniteADT64V2
