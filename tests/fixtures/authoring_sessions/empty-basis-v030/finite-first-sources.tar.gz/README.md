# First finite empty-register study

These eight cases were authored and frozen before new checks. Every source tree has a complete schema-2 edition-2026 manifest. Current sources use actual old explicit imports; desired drafts use bare genuine primitives and ordinary std::structure imports for proposed derived helpers. Desired drafts are uncompiled. Identical primitive-free desired/current sources remain separate records.

The only CLI is the immutable prior PR394 candidate copy; it is not built from the current dirty finite connection. Predictions distinguish common type/ownership errors, finite profile pollution, selected Raw support and separate requested hierarchy/Raw profiles. No repairs, retries, fallback, old recorded argv execution, exact Meaning request or source-preservation/PR/RS claim is allowed. Authored programs use at most one physical qubit; finite loading also retains unchanged small bundled roots. Every first source and actual diagnostic remains unchanged.
