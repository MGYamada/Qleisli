import QleisliKernel.Qirf.EngineeringPure

/-! Bounded manual ORIGINAL QIRF translations for the pure composed experiment.
These literal bodies are not emitted source IR and establish no source, target,
resource, capability, cleanup or constitutional preservation claim.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace PureComposedExamples
open QleisliKernel QleisliKernel.Semantics.Exact QleisliKernel.Semantics.Finite
open QleisliKernel.Semantics.Observation QleisliKernel.Qirf.EngineeringPure

def identityMatrix (dim : Nat) : Matrix :=
  ⟨dim,dim,(List.range (dim*dim)).map fun k =>
    if k / dim = k % dim then Scalar.one else Scalar.zero⟩

def phaseMatrix (bits axis exponent : Nat) : Matrix :=
  let dim := 2^bits
  ⟨dim,dim,(List.range (dim*dim)).map fun k =>
    if k / dim = k % dim then
      if bit (k / dim) axis = 1 then Exact.Scalar.phase exponent else Scalar.one
    else Scalar.zero⟩

def body (bits : Nat) (steps : List Step) : Program :=
  ⟨[⟨0,List.range bits,bits⟩],[],[.pure (.applyUnitary 0 1 steps)],[1],[],.unitary⟩

def original (basis : Basis) (steps : List Step) : Qirf.Artifact :=
  ⟨#[body (width basis) steps],#[],#[],0,some (basis,basis)⟩

def phaseSteps (axis exponent : Nat) : List Step :=
  [⟨[],.monomial [axis] [0,1] [0,exponent]⟩]

def leaf (basis : Basis) (steps : List Step) (required : Matrix) : LeafRequest :=
  ⟨original basis steps,#[0],⟨0,List.range (width basis),width basis⟩,
    ⟨1,List.range (width basis),width basis⟩,required⟩

def compareLeft : Qirf.EngineeringPure.Request :=
  ⟨[.bit],[.bit],leaf [.bit] [] (identityMatrix 2),
    leaf [.bit] (phaseSteps 0 1) (phaseMatrix 1 0 1),⟨7,3⟩⟩

def compareRight : Qirf.EngineeringPure.Request :=
  ⟨[.bit],[.bit],leaf [.bit] [] (identityMatrix 2),
    leaf [.bit] [] (identityMatrix 2),⟨0,0⟩⟩

def pairBasis : Basis := [.pair,.bit,.bit]
def parentActual : LeafRequest := leaf pairBasis [] (identityMatrix 4)
def parentIdeal : LeafRequest := leaf pairBasis (phaseSteps 0 1) (phaseMatrix 2 0 1)
def wholeFrobenius : Qirf.EngineeringPure.Request :=
  ⟨pairBasis,pairBasis,parentActual,parentIdeal,⟨7,3⟩⟩

def report {α : Type} (result : Except Finite.Error α × Nat) : String × Nat :=
  (match result.1 with | .ok _ => "ok" | .error error => reprStr error,result.2)

def runLeaf (request : Qirf.EngineeringPure.Request) (work : Nat := 2000000) :=
  report ((Qirf.EngineeringPure.check request).run work)

#eval ("left I versus T epsilon 7/8", runLeaf compareLeft)
#eval ("right I versus I epsilon 0", runLeaf compareRight)
#eval ("whole I tensor I versus T tensor I Frobenius epsilon 7/8", runLeaf wholeFrobenius)
#eval ("parent actual exact leaf", report ((Qirf.PureLeaf.check parentActual.artifact
  parentActual.order pairBasis pairBasis parentActual.input parentActual.output
  parentActual.required).run 2000000))
#eval ("parent ideal exact leaf", report ((Qirf.PureLeaf.check parentIdeal.artifact
  parentIdeal.order pairBasis pairBasis parentIdeal.input parentIdeal.output
  parentIdeal.required).run 2000000))

end PureComposedExamples
