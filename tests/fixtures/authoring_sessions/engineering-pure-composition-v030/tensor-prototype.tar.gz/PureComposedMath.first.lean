import Qleisli.EngineeringPureComposition
import Qleisli.ExactMatrix

/-! Temporary ordered tensor refinement. Engineering-only: no accepted handle,
source preservation, controlled access, cleanup or resource promotion.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace Qleisli.EngineeringPureComposed
open scoped BigOperators
open Qleisli.EngineeringPureComposition

noncomputable def coordinates {I J : Type} [Fintype I] [Fintype J]
    (e : I ≃ J) : EuclideanSpace ℂ I ≃ₗᵢ[ℂ] EuclideanSpace ℂ J :=
  LinearIsometryEquiv.piLpCongrLeft 2 ℂ ℂ e

@[simp] theorem coordinates_apply {I J : Type} [Fintype I] [Fintype J]
    (e : I ≃ J) (v : EuclideanSpace ℂ I) (j : J) :
    coordinates e v j = v (e.symm j) := rfl

@[simp] theorem coordinates_symm_apply {I J : Type} [Fintype I] [Fintype J]
    (e : I ≃ J) (v : EuclideanSpace ℂ J) (i : I) :
    (coordinates e).symm v i = v (e i) := rfl

/-- Coordinate transport is an exact permutation of the Euclidean operator. -/
theorem reindex_operator {I I' O O' : Type}
    [Fintype I] [Fintype I'] [Fintype O] [Fintype O']
    (input : I ≃ I') (output : O ≃ O') (matrix : Matrix O' I' ℂ) :
    operator (fun row col => matrix (output row) (input col)) =
      (coordinates output).symm.toLinearIsometry.toContinuousLinearMap.comp
        ((operator matrix).comp (coordinates input).toLinearIsometry.toContinuousLinearMap) := by
  ext vector row
  simp only [operator_apply, ContinuousLinearMap.comp_apply,
    LinearIsometry.coe_toContinuousLinearMap, LinearIsometryEquiv.coe_toLinearIsometry,
    coordinates_apply, coordinates_symm_apply]
  exact Fintype.sum_equiv input _ _ (fun col => by simp)

theorem reindex_norm {I I' O O' : Type}
    [Fintype I] [Fintype I'] [Fintype O] [Fintype O']
    (input : I ≃ I') (output : O ≃ O') (matrix : Matrix O' I' ℂ) :
    ‖operator (fun row col => matrix (output row) (input col))‖ = ‖operator matrix‖ := by
  rw [reindex_operator, LinearIsometry.norm_toContinuousLinearMap_comp,
    ContinuousLinearMap.opNorm_comp_linearIsometryEquiv]

/-- Exact.Matrix.tensor places the first component in the low coordinate. -/
def lowEquiv (m n : Nat) : Fin m × Fin n ≃ Fin (m*n) :=
  (Equiv.prodComm (Fin m) (Fin n)).trans
    ((finProdFinEquiv : Fin n × Fin m ≃ Fin (n*m)).trans
      (finCongr (Nat.mul_comm n m)))

@[simp] theorem lowEquiv_val (m n : Nat) (p : Fin m × Fin n) :
    (lowEquiv m n p).val = p.1.val + m*p.2.val := by
  simp [lowEquiv, finProdFinEquiv]

/-- The actual bounded exact tensor result is identified entry by entry;
no producer summary, width-only identification or phase quotient is used. -/
theorem exact_tensor_matrix
    (x y z : QleisliKernel.Semantics.Exact.Matrix) (work left : Nat)
    (ok : QleisliKernel.Exact.Matrix.tensor x y work = (.ok z,left)) :
    (fun row : Fin x.rows × Fin y.rows => fun col : Fin x.cols × Fin y.cols =>
      Qleisli.Semantics.Exact.entry z (lowEquiv x.rows y.rows row)
        (lowEquiv x.cols y.cols col)) =
      tensor (matrixAt x.rows x.cols x) (matrixAt y.rows y.cols y) := by
  ext row col
  simp only [lowEquiv_val, tensor, matrixAt]
  exact Qleisli.Exact.tensor_low_coordinate x y z work left ok _ _ _ _
    row.1.isLt row.2.isLt col.1.isLt col.2.isLt

end Qleisli.EngineeringPureComposed
