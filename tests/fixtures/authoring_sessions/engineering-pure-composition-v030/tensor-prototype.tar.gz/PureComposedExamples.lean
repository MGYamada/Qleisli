import PureComposedKernel
import PureComposedExamplesV1

/-! First bounded executions of the temporary composed engineering checker.
All artifacts below are manual original IR, separate from the frozen .qli
diagnostics. Successful checks remain engineering-only, including epsilon zero.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace PureComposedExamples
open QleisliKernel QleisliKernel.Semantics.Exact QleisliKernel.Semantics.Finite
open QleisliKernel.Semantics.Observation QleisliKernel.Qirf.EngineeringPure
open QleisliKernel.Qirf.EngineeringPureComposed

def composed : Qirf.EngineeringPureComposed.Request :=
  ⟨compareLeft,compareRight,parentActual,parentIdeal⟩

def runComposed (request : Qirf.EngineeringPureComposed.Request)
    (work : Nat := 2000000) := report ((Qirf.EngineeringPureComposed.check request).run work)

def dependencyArtifact : Qirf.Artifact :=
  ⟨#[body 1 (phaseSteps 0 1),body 1 [⟨[],.contract [0] 0 false⟩]],
    #[⟨[.bit],0,.phase8 [0,1],"manual::t","manual::t_spec",[]⟩],
    #[],1,some ([.bit],[.bit])⟩

def dependencyIdeal : LeafRequest :=
  {compareLeft.ideal with artifact := dependencyArtifact,order := #[0,2,1]}

def dependencyComposed : Qirf.EngineeringPureComposed.Request :=
  {composed with left := {compareLeft with ideal := dependencyIdeal}}

def staleDependency : LeafRequest :=
  {dependencyIdeal with artifact := {dependencyArtifact with
    programs := #[body 1 (phaseSteps 0 7),body 1 [⟨[],.contract [0] 0 false⟩]]}}

def wrongDependency : LeafRequest :=
  {dependencyIdeal with artifact := {dependencyArtifact with
    programs := #[body 1 (phaseSteps 0 1),body 1 [⟨[],.contract [0] 1 false⟩]]}}

def hiddenObservation : LeafRequest :=
  {compareLeft.actual with artifact :=
    ⟨#[⟨[⟨0,[0],1⟩],[],[.measure 0 0,.pure (.init0 1 1)],[1],[],.unitary⟩],
      #[],#[],0,some ([.bit],[.bit])⟩,output := ⟨1,[1],1⟩}

def invalidCoefficient : Matrix :=
  ⟨2,2,[⟨⟨2^127,0⟩,.integer 0,.integer 0,.integer 0⟩,
    Scalar.zero,Scalar.zero,Scalar.one]⟩

#eval ("composed tensor epsilon 7/8", runComposed composed)
#eval ("composed with original dependency epsilon 7/8", runComposed dependencyComposed)
#eval ("composed epsilon zero still engineering", runComposed
  {composed with left := compareRight,parentIdeal := parentActual})
#eval ("valid wrong parent phase refused", runComposed {composed with
  parentIdeal := leaf pairBasis (phaseSteps 0 7) (phaseMatrix 2 0 7)})
#eval ("valid wrong parent axis refused", runComposed {composed with
  parentIdeal := leaf pairBasis (phaseSteps 1 1) (phaseMatrix 2 1 1)})
#eval ("valid changed actual parent refused", runComposed {composed with
  parentActual := leaf pairBasis (phaseSteps 0 4) (phaseMatrix 2 0 4)})
#eval ("stale parent requested matrix refused", runComposed {composed with
  parentIdeal := {parentIdeal with required := identityMatrix 4}})
#eval ("stale component body refused", runComposed {composed with
  left := {compareLeft with ideal := {compareLeft.ideal with
    artifact := original [.bit] (phaseSteps 0 7)}}})
#eval ("stale original dependency refused", runComposed {dependencyComposed with
  left := {compareLeft with ideal := staleDependency}})
#eval ("wrong original dependency index refused", runComposed {dependencyComposed with
  left := {compareLeft with ideal := wrongDependency}})
#eval ("equal-width component type mismatch refused", runComposed {composed with
  left := {compareLeft with ideal := leaf [.bits 1] (phaseSteps 0 1) (phaseMatrix 1 0 1)}})
#eval ("equal-width full parent type mismatch refused", runComposed {composed with
  parentIdeal := leaf [.bits 2] (phaseSteps 0 1) (phaseMatrix 2 0 1)})
#eval ("ordered parent wires changed refused", runComposed {composed with
  parentIdeal := {parentIdeal with output := ⟨1,[1,0],2⟩}})
#eval ("missing component root witness refused", runComposed {composed with
  left := {compareLeft with ideal := {compareLeft.ideal with order := #[]}}})
#eval ("extra component root witness refused", runComposed {composed with
  left := {compareLeft with ideal := {compareLeft.ideal with order := #[0,0]}}})
#eval ("missing parent root witness refused", runComposed {composed with
  parentIdeal := {parentIdeal with order := #[]}})
#eval ("extra parent root witness refused", runComposed {composed with
  parentIdeal := {parentIdeal with order := #[0,0]}})
#eval ("stale component epsilon refused", runComposed {composed with
  left := {compareLeft with epsilon := ⟨0,0⟩}})
#eval ("hidden observation false pure label refused", runComposed {composed with
  left := {compareLeft with actual := hiddenObservation}})
#eval ("invalid requested coefficient refused", runComposed {composed with
  left := {compareLeft with actual := {compareLeft.actual with required := invalidCoefficient}}})
#eval ("zero work refused", runComposed composed 0)
#eval ("over absolute work cap refused", runComposed composed 10000001)

#eval ("arithmetic coefficient capacity refused", runComposed {composed with
  left := {compareLeft with epsilon := ⟨2^64,0⟩}})
#eval ("exact shared work boundary succeeds", runComposed composed 3022)
#eval ("one below shared work boundary refuses", runComposed composed 3021)

-- Lean's kernel reduces the actual checker on these literal original bodies.
-- These are bounded executable facts, not producer summaries or source proofs.
theorem composed_accepts : ((Qirf.EngineeringPureComposed.check composed).run 2000000).1.isOk = true := by decide +kernel
theorem dependency_composed_accepts : ((Qirf.EngineeringPureComposed.check dependencyComposed).run 2000000).1.isOk = true := by decide +kernel
theorem shared_work_exact_boundary : (runComposed composed 3022) = ("ok",0) := by decide +kernel
theorem shared_work_below_boundary : ((Qirf.EngineeringPureComposed.check composed).run 3021).1.isOk = false := by decide +kernel
theorem whole_frobenius_refuses : ((Qirf.EngineeringPure.check wholeFrobenius).run 2000000).1.isOk = false := by decide +kernel

end PureComposedExamples
