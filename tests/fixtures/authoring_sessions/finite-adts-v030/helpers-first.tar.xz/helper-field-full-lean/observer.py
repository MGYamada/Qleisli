import gzip, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
R=Path('/Users/masa/git/Qleisli'); Q=Path('/Users/masa/git/qlirgo')
O=Path('/private/tmp/qleisli-helper-resume-20261021/helper-field-full-lean'); O.mkdir()
K=R/'lean-kernel/.lake/build/bin/qleisli-kernel'; REG='lean/schema-registry.json'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def state(root):
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'files':{n:digest(root/n) if (root/n).is_file() else 'missing' for n in sorted(set(filter(None,names)))}}
def snapshot():return {'root':state(R),'qlirgo':state(Q),'kernel':digest(K)}
before=snapshot(); (O/'before.json').write_text(json.dumps(before,indent=2)+'\n')
(O/'observer.py').write_bytes(Path(__file__).read_bytes())
for name in before['root']['files']:
 if name.endswith(('.lean','.rs')) and ('sourcetypes' in name.lower() or 'sourcenatural' in name.lower() or 'sourceaffine' in name.lower() or name in ['lean-kernel/Tests.lean','lean-kernel/Protocol/Carrier.lean','src/interchange/native/carrier/tests.rs']):
  p=O/'sources'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/name).read_bytes())
F='tests/fixtures/constitution_v030/initial-guarantees'
C='tests/fixtures/constitution_v030/initial-guarantees-continuity'
stages=[('registry',R,['/opt/homebrew/bin/python3','scripts/check_schema_registry.py','--write','--report',str(O/'registry.json')],900,None),('kernel-tests',R/'lean-kernel',['/opt/homebrew/bin/lake','env','lean','-DwarningAsError=true','Tests.lean'],900,None),('review',R/'lean',['/opt/homebrew/bin/lake','env','lean','-DwarningAsError=true','../'+F+'/Review.lean'],180,F+'/review-types.stdout.txt'),('binding',R/'lean',['/opt/homebrew/bin/lake','env','lean','-DwarningAsError=true','../'+F+'/CurrentBinding.lean'],180,F+'/current-binding.stdout.txt'),('basis',R/'lean',['/opt/homebrew/bin/lake','env','lean','-DwarningAsError=true','../'+C+'/BasisTransportReview.lean'],180,C+'/basis-transport.stdout.txt'),('raw',R/'lean',['/opt/homebrew/bin/lake','env','lean','-DwarningAsError=true','../'+C+'/RawTransportReview.lean'],180,C+'/raw-transport.stdout.txt'),('extract',R/'lean',['/opt/homebrew/bin/lake','env','lean','-DwarningAsError=true','../'+C+'/RawExtract.lean'],300,C+'/current-expressions.json.gz'),('main-replay',R/'lean-kernel',['/opt/homebrew/bin/lake','env','leanchecker','--fresh','Main'],900,F+'/native-main-replay.stdout.txt')]
(O/'plan.json').write_text(json.dumps([{'name':n,'cwd':str(c),'argv':a,'timeout_seconds':t,'expected_output':e} for n,c,a,t,e in stages],indent=2)+'\n')
env=os.environ.copy();env['PATH']='/opt/homebrew/bin:'+env['PATH'];records=[];comparisons=[];ok=True
for name,cwd,argv,limit,expected in stages:
 if not ok:records.append({'name':name,'executed':False});continue
 print('START '+name,flush=True);start=time.monotonic();timeout=False
 with (O/(name+'.stdout')).open('wb') as out,(O/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
  (O/'live.json').write_text(json.dumps({'stage':name,'pid':p.pid,'limit_seconds':limit})+'\n')
  try:code=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code=p.returncode
 row={'name':name,'executed':True,'argv':argv,'cwd':str(cwd),'exit_code':code,'timeout':timeout,'seconds':time.monotonic()-start,'stdout_sha256':digest(O/(name+'.stdout')),'stderr_sha256':digest(O/(name+'.stderr'))};records.append(row);ok=code==0 and not timeout
 if expected and ok:
  reference=gzip.decompress((R/expected).read_bytes()) if expected.endswith('.gz') else (R/expected).read_bytes()
  same=(O/(name+'.stdout')).read_bytes()==reference and (O/(name+'.stderr')).stat().st_size==0
  comparisons.append({'name':name,'reference':expected,'identical_recorded_output':same});ok=ok and same
 print(json.dumps(row),flush=True)
 if not ok:
  for suffix in ['stdout','stderr']:
   with (O/(name+'.'+suffix)).open('rb') as f:f.seek(max(0,(O/(name+'.'+suffix)).stat().st_size-3000));print(f.read(3000).decode(errors='replace'),flush=True)
after=snapshot();changed=[n for n in sorted(set(before['root']['files'])|set(after['root']['files'])) if before['root']['files'].get(n)!=after['root']['files'].get(n)]
windows=before['root']['head']==after['root']['head'] and changed==[REG] and before['qlirgo']==after['qlirgo']
report={'format':'qleisli.helper-field-fresh-validation','version':1,'before':before,'after':after,'commands':records,'output_comparisons':comparisons,'changed_source_files':changed,'source_windows_unchanged_except_registry':windows,'pass':ok and windows and len(comparisons)==6}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['pass','source_windows_unchanged_except_registry','changed_source_files']}),flush=True);sys.exit(0 if report['pass'] else 1)
