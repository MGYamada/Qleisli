"""Fresh, bounded Lean study observer. Saved source/commands remain inert."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/Users/masa/git/Qleisli')
QARGO = Path('/Users/masa/git/qargo')
HERE = Path(__file__).resolve().parent
OUT = HERE / 'observation-02'
OUT.mkdir()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tree(root):
    names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=root).decode().split('\0')
    return {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(),
        'status': subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root).decode(),
        'files': {name: sha((root / name).read_bytes()) if (root / name).is_file() else 'missing'
                  for name in sorted(set(filter(None, names)))},
    }

def snapshot():
    return {
        'root': tree(ROOT), 'qargo': tree(QARGO),
        'native_sha256': sha((ROOT / 'lean-kernel/.lake/build/bin/qleisli-kernel').read_bytes()),
        'project_imports': {str(file.relative_to(ROOT)): sha(file.read_bytes())
                            for file in sorted((ROOT / 'lean-kernel/.lake/build/lib/lean').rglob('*.olean'))},
        'study': {name: sha((HERE / name).read_bytes()) for name in ['plan-v2.json', 'FiniteTagStudy-v2.lean', 'observe-v2.py']},
    }

before = snapshot()
(OUT / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
for name in ['plan-v2.json', 'FiniteTagStudy-v2.lean', 'observe-v2.py']:
    (OUT / (name + '.txt')).write_bytes((HERE / name).read_bytes())

commands = []
failure = None
try:
    lake = shutil.which('lake')
    if lake is None:
        raise RuntimeError('lake is unavailable')
    for label, arguments in [
        ('version', ['env', 'lean', '--version']),
        ('proof', ['env', 'lean', '-DwarningAsError=true', str(HERE / 'FiniteTagStudy-v2.lean')]),
    ]:
        argv = [lake, *arguments]
        started = time.monotonic()
        timed = False
        try:
            result = subprocess.run(argv, cwd=ROOT / 'lean-kernel', env=os.environ.copy(), capture_output=True, timeout=240)
            code, stdout, stderr = result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired as error:
            code, stdout, stderr, timed = None, error.stdout or b'', error.stderr or b'', True
        (OUT / (label + '.stdout')).write_bytes(stdout)
        (OUT / (label + '.stderr')).write_bytes(stderr)
        row = {'label': label, 'argv': argv, 'cwd': str(ROOT / 'lean-kernel'), 'exit_code': code,
               'timeout': timed, 'seconds': time.monotonic() - started}
        commands.append(row)
        print(json.dumps(row), flush=True)
        if code != 0 or timed:
            raise RuntimeError(label + ' failed: ' + stdout.decode(errors='replace')[-5000:] + stderr.decode(errors='replace')[-2000:])
        if label == 'version' and b'4.30.0' not in stdout:
            raise RuntimeError('the observed Lean version is not 4.30.0')
        if label == 'proof':
            lines = [line for line in stdout.decode().splitlines() if line.startswith("'QleisliExperiment.FiniteADT64V2.")]
            if len(lines) != 15:
                raise RuntimeError('expected fifteen actual theorem axiom reports')
            for line in lines:
                if 'does not depend on any axioms' in line:
                    continue
                if 'depends on axioms: [' not in line:
                    raise RuntimeError('unknown axiom output: ' + line)
                used = set(line.split('depends on axioms: [', 1)[1].removesuffix(']').split(', '))
                if not used <= {'propext', 'Classical.choice', 'Quot.sound'}:
                    raise RuntimeError('nonstandard/project axiom: ' + line)
except Exception as error:
    failure = str(error)
    print(failure, flush=True)

after = snapshot()
report = {'before': before, 'after': after, 'source_unchanged': before == after,
          'commands': commands, 'failure': failure,
          'scope': 'Fresh elaboration of fifteen concrete R8/encoding facts against observed compiled imports; no project edits or acceptance handle. Not a full import replay, generic ADT/qmatch/source-preservation proof, human specification review or issue completion.'}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': str(OUT / 'report.json'), 'source_unchanged': before == after, 'failure': failure}), flush=True)
raise SystemExit(0 if failure is None and before == after else 1)
