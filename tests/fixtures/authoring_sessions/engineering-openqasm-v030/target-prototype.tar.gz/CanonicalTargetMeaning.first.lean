import CanonicalTargetExamples
import Qleisli.NativeEngineeringInstrument

/-! TEMP TP-31-TARGET-QASM-01 (P1), actual decoder/checker refinement.
This does not adopt an external target reference, certify source export or
construct constitutional exact-correspondence, cleanup or resource evidence.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace CanonicalTargetMeaning
open QleisliKernel
open CanonicalTarget CanonicalTargetExamples

/-- Both fresh body meanings, exact Kraus completeness, full ordered result
projection and the complete-adjoint bound belong to the decoded target bytes.
The Meaning.bound field quantifies every finite reference and observable. -/
theorem check_meaning (bytes : ByteArray) (epsilon : Semantics.Exact.Coefficient)
    (majorants : List Semantics.Exact.Coefficient) (retained : Retained) (work left : Nat)
    (ok : (CanonicalTarget.check bytes epsilon majorants).run work = (.ok retained,left)) :
    decode bytes = .ok retained.decoded ∧ retained.decoded.original = bytes ∧
      ∃ projection, Qleisli.NativeEngineeringInstrument.Meaning
        (request retained.decoded epsilon majorants) retained.checked projection := by
  have binding := check_bound _ _ _ _ _ _ ok
  exact ⟨binding.decoded,decode_original _ _ binding.decoded,
    Qleisli.NativeEngineeringInstrument.check_meaning _ _ _ _ binding.executed⟩

/-- The literal target emitted in this study has the declared epsilon1 bound;
this theorem consumes its kernel-reduced actual checking success. -/
theorem actual_target_meaning :
    ∃ retained left projection,
      (CanonicalTarget.check actualBytes one [half,half]).run 2000000 = (.ok retained,left) ∧
        retained.decoded.original = actualBytes ∧
        Qleisli.NativeEngineeringInstrument.Meaning
          (request retained.decoded one [half,half]) retained.checked projection := by
  cases result : (CanonicalTarget.check actualBytes one [half,half]).run 2000000 with
  | mk answer left =>
    cases answer with
    | error error => simp [result] at actual_accepts
    | ok retained =>
      obtain ⟨_,original,projection,meaning⟩ := check_meaning _ _ _ _ _ _ result
      exact ⟨retained,left,projection,result,original,meaning⟩

end CanonicalTargetMeaning
