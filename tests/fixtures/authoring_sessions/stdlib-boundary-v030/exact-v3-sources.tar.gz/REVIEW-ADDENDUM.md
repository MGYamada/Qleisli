# Static review addendum, before any execution

The original version-2 authoring freeze remains unchanged. Its full-source-
snapshot positive plan overestimated what unrefined selected Raw emission
retains: Proposal::from_raw starts an empty Encoder source table; these bodies
have no retained FunctionEvidence snapshots. That stronger request would
therefore refuse source identity before reaching the intended matrix test.
No execution exposed this; source inspection did.

Use command-plan-v2.1.json as the primary predeclared experiment. It selects
the already authored artifact-only request FROM THE OUTSET, and separately
checks the original source steps. This is not retry/fallback behavior. Keep
any deliberately submitted full-snapshot request as a separately predicted
source-identity negative. Exact requested native artifact equations remain
distinct from a source-to-IR preservation theorem or source certification.

The independent R8 matrix files, source programs, typed requests, initial
hypotheses and first v2 freeze are unchanged. No commands have been run.
