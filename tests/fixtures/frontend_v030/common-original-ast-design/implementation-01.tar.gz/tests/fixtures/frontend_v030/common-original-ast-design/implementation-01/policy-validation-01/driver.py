#!/usr/bin/env python3
"""Fixed ordinary policy checks; root freezes only terminal, reviewed inputs.
Copyright 2026 Masahiko G. Yamada. SPDX-License-Identifier: Apache-2.0.
"""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
ROOT = Path('/Users/masa/git/Qleisli')
HERE = Path(__file__).resolve().parent
UNIT = HERE.parent
STUDY = ROOT / 'tests/fixtures/authoring_sessions/common-original-ast-v030'
VALIDATION = UNIT / 'validation'
CAPTURE = UNIT / 'original-source-capture-01'
FROZEN = HERE / 'reviewed-inputs.json'
MDBOOK = Path('/private/tmp/qleisli-mdbook-0.5.4-bin/mdbook')
CLI = Path('/private/tmp/qleisli-bounded-validation-target/debug/qleisli')
NATIVE = ROOT / 'lean-kernel/.lake/build/bin/qleisli-kernel'
NATIVE_SHA = '39effde0f152a2c926fcea3a7f99fc2f25f9de65906be2b8c527508353c90c85'
BASE = 'faa5cfb5e7ea1cf3b39a43b80f7f2345e89197c2'
STREAM_LIMIT = 1 << 20
COMMAND_SECONDS = 180
STAGES = ('cargo-version', 'rustc-version', 'format', 'check-all-targets',
          'shared-type-tests', 'focused-integration-tests',
          'native-small-arithmetic-tests', 'clippy-all-targets', 'rebuilt-cli')
EXPECTED_REGRESSIONS = {
    '03.book-regression': 12, '05.authoring-regression': 7,
    '07.edition-regression': 11, '09.docs-regression': 36,
    '12.inventory-regression': 17, '14.coverage-regression': 14,
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1 << 20), b''):
            digest.update(part)
    return digest.hexdigest()


def record(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError('Selected input is not an ordinary file: ' + str(path))
    return {'bytes': path.stat().st_size, 'sha256': sha(path),
            'mode': path.stat().st_mode & 0o777}


def save(folder, name, value):
    with (folder / name).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def load(path):
    # These maps/results are data only. Their argv can never select a command.
    return json.loads(path.read_text())


def safe_file(folder, name):
    path = Path(name)
    if path.is_absolute() or '..' in path.parts:
        raise ValueError('Identity path is not packet/root relative: ' + name)
    target = folder / path
    if not target.resolve(strict=True).is_relative_to(folder.resolve()):
        raise ValueError('Identity path escapes its root: ' + name)
    record(target)
    return target


def require_rows(folder, rows):
    for name, expected in rows.items():
        actual = record(safe_file(folder, name))
        expected = {'sha256': expected} if isinstance(expected, str) else expected
        for key in ('sha256', 'bytes', 'mode'):
            if key in expected and actual[key] != expected[key]:
                raise ValueError('Recorded identity changed: ' + str(folder / name))


def terminal_rust(mode, attempt, expected_sha):
    folder = VALIDATION / (mode + '-' + attempt)
    path = folder / 'results.json'
    if sha(path) != expected_sha:
        raise ValueError('Explicit terminal Rust record hash differs: ' + mode)
    result = load(path)
    before, after = load(folder / 'inputs-before.json'), load(folder / 'inputs-after.json')
    if (result['status'] != 'passed' or result['mode'] != mode or
            result['attempt'] != attempt or result['remaining_stages_not_run'] != 0 or
            not result['source_inputs_unchanged'] or not result['cli_rebuild_completed'] or
            before != after or [r['label'] for r in result['records']] != list(STAGES)):
        raise ValueError('Rust packet is not the actual complete successful bounded run: ' + mode)
    digest = hashlib.sha256(json.dumps(before['files'], sort_keys=True,
                                      separators=(',', ':')).encode()).hexdigest()
    if before['sha256'] != digest:
        raise ValueError('Rust source-map digest differs: ' + mode)
    tests = []
    for row in result['records']:
        if (row['exit_code'] != 0 or row['launch_error'] is not None or row['timed_out'] or
                row['postcondition_error'] is not None or not row['identities_unchanged'] or
                row['source_input_digest_after'] != digest or row['native_sha256_after'] != NATIVE_SHA):
            raise ValueError('Rust stage is not terminal success: ' + mode + '/' + row['label'])
        for kind in ('stdout', 'stderr'):
            require_rows(folder, {row[kind]['path']: row[kind]})
        tests.extend(row['actual_test_results'])
    if not tests or any(r['status'] != 'ok' or r['failed'] != 0 for r in tests):
        raise ValueError('No complete genuine bounded Rust test results: ' + mode)
    expected_version = '1.85.0' if mode == 'msrv' else '1.98.1'
    for label, tool in (('cargo-version', 'cargo'), ('rustc-version', 'rustc')):
        row = next(r for r in result['records'] if r['label'] == label)
        if not re.match(tool + ' ' + re.escape(expected_version) + r'(?:\s|$)',
                        (folder / row['stdout']['path']).read_text()):
            raise ValueError('Actual Rust toolchain version differs: ' + mode)
    # Docs and accounting metadata may be reviewed after Rust validation. Bind
    # all actual production Rust plus the recorded executable source/build data;
    # do not pretend this partial map attests every compiler/environment input.
    executable_inputs = {name: value for name, value in before['files'].items()
                         if name.endswith(('.rs', '.qli', '.toml')) or name == 'Cargo.lock'}
    require_rows(ROOT, executable_inputs)
    current_src = {str(p.relative_to(ROOT)) for p in (ROOT / 'src').rglob('*.rs')}
    if not current_src.issubset(executable_inputs):
        raise ValueError('A current production Rust file is absent from the terminal map')
    return {'path': str(path.relative_to(ROOT)), 'sha256': expected_sha,
            'mode': mode, 'attempt': attempt, 'cli_sha256': result['cli_sha256_after'],
            'source_map_sha256': sha(folder / 'inputs-after.json'),
            'actual_test_counts': {key: sum(r[key] for r in tests)
                                   for key in ('passed', 'failed', 'ignored')},
            'scope': 'Separate root-run bounded stages; no commands replayed by policy.'}


def terminal_capture(expected_sha):
    folder = CAPTURE / 'observations'
    file_map_path = folder / 'files.json'
    if sha(file_map_path) != expected_sha:
        raise ValueError('Explicit terminal original-source capture map hash differs')
    file_map = load(file_map_path)
    if file_map['self_excluded'] != 'files.json':
        raise ValueError('Capture map self exclusion differs')
    require_rows(folder, file_map['files'])
    if set(file_map['files']) | {'files.json'} != {p.name for p in folder.iterdir()}:
        raise ValueError('Capture packet member inventory differs')
    summary, final = load(folder / 'summary.json'), load(folder / 'identity.final.json')
    frozen = load(CAPTURE / 'prospective-inputs.json')
    if (len(summary['rows']) != 72 or summary['actual_observation_count'] != 72 or
            not final['all_declared_inputs_unchanged'] or final['identity'] != frozen['identity'] or
            (folder / 'incomplete.json').exists()):
        raise ValueError('Original-source capture is not complete and unchanged')
    observations = []
    for row in summary['rows']:
        event_path = safe_file(CAPTURE, row['observation'])
        if event_path.parent != folder:
            raise ValueError('Observation is outside the fixed capture output')
        event = load(event_path)
        cap = event['client_capture']
        if (not cap['spawned'] or cap['reason'] is not None or cap['error'] is not None or
                cap['stdout_limited'] or cap['stderr_limited'] or
                cap['returncode'] != row['exit_code'] or event['exit_code'] != row['exit_code'] or
                event['native_journal_parse_error'] is not None):
            raise ValueError('Original-source capture has operational uncertainty')
        for raw in event['raw'].values():
            require_rows(folder, {raw['path']: raw})
        journal = event['native_journal']
        require_rows(folder, {journal['path']: journal})
        count = len((folder / journal['path']).read_bytes().splitlines())
        if count != row['native_forwarded_attempts'] or count != event['native_forwarded_attempts']:
            raise ValueError('Original-source journal row count differs')
        observations.append((row['exit_code'], count))
    if (sum(code == 0 for code, _ in observations) != summary['actual_successes'] or
            sum(code != 0 for code, _ in observations) != summary['actual_nonzero_exits'] or
            sum(count for _, count in observations) != summary['native_forwarded_attempts']):
        raise ValueError('Original-source aggregate observations differ')
    # Original FIRST files and historical before observations remain protected.
    for name, value in frozen['identity']['original_tree'].items():
        require_rows(ROOT, {name: value})
    if sha(CLI) != frozen['identity']['cli_sha256']:
        raise ValueError('Current CLI differs from the actual completed capture')
    return {'path': str(file_map_path.relative_to(ROOT)), 'sha256': expected_sha,
            'summary_sha256': sha(folder / 'summary.json'),
            'actual_observations': 72,
            'successes': summary['actual_successes'], 'nonzero_exits': summary['actual_nonzero_exits'],
            'pre_execv_forwarded_attempts': summary['native_forwarded_attempts'],
            'scope': 'Actual checks and pre-execv journal rows, not independent native start/exit or preservation.'}


def prerequisites(config):
    if sys.version_info < (3, 11) or sha(NATIVE) != NATIVE_SHA:
        raise ValueError('Python 3.11+ and the reviewed native bytes are required')
    rust = {mode: terminal_rust(mode, config[mode]['attempt'], config[mode]['sha256'])
            for mode in ('latest', 'msrv')}
    if sha(CLI) != rust['msrv']['cli_sha256']:
        raise ValueError('Current CLI differs from the completed MSRV rebuild')
    capture = terminal_capture(config['capture_files_sha256'])
    return {'rust': rust, 'original_source_capture': capture}


def input_files():
    inventory = load(ROOT / 'tests/fixtures/verification_v022/inventory.json')
    names = [row['path'] for row in inventory['sources']]
    if len(names) != len(set(names)):
        raise ValueError('Active inventory source paths are duplicated')
    paths = {safe_file(ROOT, name) for name in names}
    for folder, pattern in ((ROOT / 'src', '*.rs'), (ROOT / 'scripts', '*.py'),
                            (ROOT / 'docs', '*'), (ROOT / 'governance', '*'),
                            (ROOT / '.github', '*'), (ROOT / 'stdlib', '*'),
                            (ROOT / 'corpus', '*'), (STUDY, '*'), (UNIT, '*')):
        for p in folder.rglob(pattern):
            if p.is_file() and not p.is_symlink() and '.lake' not in p.parts and HERE not in p.parents:
                paths.add(p)
    paths.update(p for p in (ROOT / 'lean-kernel').rglob('*.lean') if '.lake' not in p.parts)
    paths.update((ROOT / 'tests').glob('*.rs'))
    paths.update((ROOT / 'tests/fixtures/authoring_sessions').glob('*/session.json'))
    paths.update(ROOT / name for name in (
        'AGENTS.md', 'CLAUDE.md', 'README.md', 'ROADMAP.md', 'TRUSTBOUNDARY.md',
        'CONSTITUTION.md', 'GOVERNANCE.md', 'CHANGELOG.md', 'Cargo.toml', 'Cargo.lock',
        'tests/fixtures/authoring_sessions/README.md',
        'tests/fixtures/verification_v022/inventory.json',
        'tests/fixtures/verification_v029/coverage.json',
        'lean-kernel/lean-toolchain', 'lean-kernel/lakefile.toml', 'lean-kernel/lake-manifest.json'))
    paths.update((Path(__file__), HERE / 'README.md'))
    # Proposal archives/relocations and *.md.txt copies are bound as current
    # bytes, not checked as obsolete live paths from historical member maps.
    return {str(p.relative_to(ROOT)): record(p) for p in sorted(paths)}


def binaries():
    return {str(p): record(p) for p in (MDBOOK, CLI, NATIVE)}


def freeze(config):
    separate = prerequisites(config)
    before, selected = input_files(), binaries()
    if before != input_files() or selected != binaries():
        raise ValueError('Inputs changed during prospective freeze')
    save(HERE, FROZEN.name, {
        'format': 'qleisli.original-ast-policy-reviewed-inputs', 'version': 1,
        'recorded_utc': now(), 'files': before, 'selected_binaries': selected,
        'config': config, 'separate_terminal_root_packets': separate,
        'inventory_source_count': len(load(ROOT / 'tests/fixtures/verification_v022/inventory.json')['sources']),
        'declared_incomplete_closure': True,
        'excluded': ['this input map', 'policy attempts', 'owned temporary rendered book',
                     'unlisted external runtime/environment and unrelated fixture closure'],
        'commands_executed': False})
    print('Frozen input map SHA-256: ' + sha(FROZEN), flush=True)
    return 0


def kill_group(process, sig):
    try:
        os.killpg(process.pid, sig)
    except ProcessLookupError:
        pass


def run(out, name, argv):
    started, begin = now(), time.monotonic()
    raw_paths = {kind: out / (name + '.' + kind + '.txt') for kind in ('stdout', 'stderr')}
    retained = {kind: 0 for kind in raw_paths}
    seen = {kind: 0 for kind in raw_paths}
    limited = {kind: False for kind in raw_paths}
    timed_out = False
    launch_error = None
    process = None
    cleanup_incomplete = False
    handles = {kind: path.open('xb') for kind, path in raw_paths.items()}
    selector = selectors.DefaultSelector()
    try:
        process = subprocess.Popen(argv, cwd=ROOT, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                                   stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        for kind in ('stdout', 'stderr'):
            pipe = getattr(process, kind)
            os.set_blocking(pipe.fileno(), False)
            selector.register(pipe, selectors.EVENT_READ, kind)
        abort_at = None
        while selector.get_map() or process.poll() is None:
            elapsed = time.monotonic() - begin
            if elapsed >= COMMAND_SECONDS and abort_at is None:
                timed_out = True
                abort_at = time.monotonic()
                kill_group(process, signal.SIGTERM)
            if abort_at is not None and time.monotonic() - abort_at >= 2:
                kill_group(process, signal.SIGKILL)
                if time.monotonic() - abort_at >= 4:
                    cleanup_incomplete = bool(selector.get_map()) or process.poll() is None
                    break
            for key, _ in selector.select(0.05):
                chunk = os.read(key.fileobj.fileno(), 65536)
                if not chunk:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                kind = key.data
                seen[kind] += len(chunk)
                kept = chunk[:max(0, STREAM_LIMIT - retained[kind])]
                handles[kind].write(kept)
                retained[kind] += len(kept)
                if seen[kind] > STREAM_LIMIT:
                    limited[kind] = True
                    if abort_at is None:
                        abort_at = time.monotonic()
                        kill_group(process, signal.SIGTERM)
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            cleanup_incomplete = True
            kill_group(process, signal.SIGKILL)
    except OSError as error:
        launch_error = repr(error)
        if process is not None:
            kill_group(process, signal.SIGKILL)
    finally:
        for key in list(selector.get_map().values()):
            key.fileobj.close()
        selector.close()
        for handle in handles.values():
            handle.close()
    row = {'id': name, 'argv': argv, 'cwd': str(ROOT), 'started_at_utc': started,
           'completed_at_utc': now(), 'seconds': time.monotonic() - begin,
           'exit_code': process.returncode if process is not None else None,
           'launch_error': launch_error, 'timed_out': timed_out,
           'output_limited': limited, 'stream_bytes_seen': seen,
           'cleanup_incomplete': cleanup_incomplete,
           'limits': {'command_seconds': COMMAND_SECONDS, 'bytes_per_stream': STREAM_LIMIT,
                      'parallel_commands': 2},
           'stdout': {'path': raw_paths['stdout'].name, **record(raw_paths['stdout'])},
           'stderr': {'path': raw_paths['stderr'].name, **record(raw_paths['stderr'])}}
    save(out, name + '.json', row)
    print(name + ': actual exit ' + str(row['exit_code']), flush=True)
    return row


def complete(row):
    return (row['exit_code'] == 0 and row['launch_error'] is None and not row['timed_out'] and
            not any(row['output_limited'].values()) and not row['cleanup_incomplete'])


def finish(out, result):
    save(out, 'results.json', result)
    save(out, 'files.json', {'files': {p.name: record(p) for p in sorted(out.iterdir()) if p.is_file()},
                            'self_excluded': 'files.json'})
    print(json.dumps(result, indent=2), flush=True)
    return 0 if result['status'] == 'ordinary-policy-and-docs-checks-passed' else 1


def execute(attempt, expected_sha):
    out = HERE / attempt
    out.mkdir(exist_ok=False)
    (out / 'executed-driver.py.txt').open('xb').write(Path(__file__).read_bytes())
    try:
        if sha(FROZEN) != expected_sha:
            raise ValueError('Caller-reviewed policy input map differs')
        frozen = load(FROZEN)
        separate = prerequisites(frozen['config'])
        before, selected = input_files(), binaries()
        if (before != frozen['files'] or selected != frozen['selected_binaries'] or
                separate != frozen['separate_terminal_root_packets']):
            raise ValueError('Current input/binary/terminal-record identities changed after freeze')
        save(out, 'identity.before.json', {'files': before, 'selected_binaries': selected,
             'input_map_sha256': expected_sha, 'separate_terminal_root_packets': separate,
             'python_executable': sys.executable, 'python_version': sys.version})
    except (OSError, ValueError, KeyError, TypeError) as error:
        return finish(out, {'status': 'startup-rejected', 'error': repr(error),
                            'actual_command_count': 0, 'raw_failures_preserved': True})
    records = []
    try:
        records.append(run(out, '00.mdbook-version', [str(MDBOOK), '--version']))
        pinned = (complete(records[0]) and
                  (out / '00.mdbook-version.stdout.txt').read_text().strip() == 'mdbook v0.5.4')
        rendered = None
        if pinned:
            temp = Path(tempfile.mkdtemp(prefix='qleisli-original-ast-policy-book-', dir='/private/tmp'))
            try:
                book = temp / 'book'
                records.append(run(out, '01.mdbook-build', [str(MDBOOK), 'build', 'docs', '--dest-dir', str(book)]))
                if complete(records[-1]):
                    records.append(run(out, '02.rendered-book',
                                       [sys.executable, 'scripts/check_book.py', '--root', str(book)]))
                files = {str(p.relative_to(book)): record(p) for p in sorted(book.rglob('*')) if p.is_file()}
                rendered = {'files': files, 'total_bytes': sum(r['bytes'] for r in files.values()),
                            'output_root': str(book),
                            'scope': 'Rendered HTML/print/assets and local links; external URLs not fetched.',
                            'cleanup': 'Only this owned temporary tree, after output hash map and raw logs saved.'}
                save(out, 'rendered-files.json', rendered)
            finally:
                shutil.rmtree(temp)
        # Literal commands are authored here, never sourced from any record.
        commands = (
            ('03.book-regression', [sys.executable, 'scripts/test_check_book.py']),
            ('04.authoring', [sys.executable, 'scripts/check_authoring_sessions.py']),
            ('05.authoring-regression', [sys.executable, 'scripts/test_check_authoring_sessions.py']),
            ('06.editions', [sys.executable, 'scripts/check_editions.py']),
            ('07.edition-regression', [sys.executable, 'scripts/test_check_editions.py']),
            ('08.docs', [sys.executable, 'scripts/check_docs.py']),
            ('09.docs-regression', [sys.executable, 'scripts/test_check_docs.py']),
            ('10.constitution', [sys.executable, 'scripts/check_constitution.py', '--base-ref', BASE]),
            ('11.inventory', [sys.executable, 'scripts/check_verification_inventory.py']),
            ('12.inventory-regression', [sys.executable, 'scripts/test_check_verification_inventory.py']),
            ('13.coverage', [sys.executable, 'scripts/check_production_coverage.py']),
            ('14.coverage-regression', [sys.executable, 'scripts/test_check_production_coverage.py']),
            ('15.schema-source-only', [sys.executable, 'scripts/check_schema_registry.py', '--source-only']),
            ('16.corpus-provenance-only', [sys.executable, 'scripts/check_input_corpus.py']),
        )
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            records.extend(pool.map(lambda item: run(out, *item), commands))
        after, final_binaries = input_files(), binaries()
        mismatches = {name: {'before': before.get(name), 'after': after.get(name)}
                      for name in before.keys() | after.keys() if before.get(name) != after.get(name)}
        save(out, 'identity.after.json', {'files': after, 'selected_binaries': final_binaries,
                                        'mismatches': mismatches})
        save(out, 'commands.json', {'commands': records, 'recorded_commands_executed': False})
        counts = {}
        for row in records:
            text = (out / row['stderr']['path']).read_text(errors='replace')
            found = re.search(r'Ran (\d+) tests in ', text)
            if complete(row) and found and text.rstrip().endswith('OK'):
                counts[row['id']] = int(found[1])
        book_counts = None
        if (out / '02.rendered-book.stdout.txt').exists():
            found = re.search(r'rendered book: (\d+) HTML files, (\d+) local links, (\d+) anchors checked',
                              (out / '02.rendered-book.stdout.txt').read_text())
            if found:
                book_counts = dict(zip(('html_files', 'local_links', 'anchors'), map(int, found.groups())))
        passed = (pinned and len(records) == 17 and all(complete(r) for r in records) and
                  counts == EXPECTED_REGRESSIONS and book_counts is not None and not mismatches and
                  selected == final_binaries and sha(FROZEN) == expected_sha and
                  prerequisites(frozen['config']) == separate)
        return finish(out, {
            'status': 'ordinary-policy-and-docs-checks-passed' if passed else 'checks-incomplete-or-failed',
            'actual_command_count': len(records), 'actual_regression_counts': counts,
            'actual_regression_total': sum(counts.values()), 'expected_regressions_are_assertions': True,
            'actual_rendered_book_counts': book_counts,
            'generated_bytes': rendered['total_bytes'] if rendered else None,
            'selected_input_count': len(before), 'mismatches': mismatches,
            'inventory_source_count': frozen['inventory_source_count'],
            'input_map_sha256': expected_sha, 'separate_terminal_root_packets': separate,
            'pinned_mdbook_verified': pinned, 'raw_failures_preserved': True,
            'scope': 'Ordinary source-judgment implementation documentation and policy checks only.',
            'not_run': ['Rust/Lean builds, CLI/native replay', 'maximum or exhaustive corpus execution',
                        'fresh Lean proof replay', 'full CI or release-readiness'],
            'narrow_checks': {'schema': 'source identity only; no fresh theorem validity',
                              'corpus': 'provenance only; no binary or semantic probes'},
            'no_claim': ['source preservation', 'mathematical discharge', 'new guarantee/adoption',
                         'full common-frontend/emitter completion', 'generic-family proof',
                         'canonical generic std/QFT exposure', 'Issue closure', 'release approval']})
    except Exception as error:
        retained = sorted(p.name for p in out.glob('*.json')
                          if re.fullmatch(r'[0-9]{2}[.].+[.]json', p.name))
        return finish(out, {'status': 'wrapper-aborted', 'error': repr(error),
                            'retained_record_count': len(retained),
                            'retained_command_record_files': retained,
                            'actual_launched_command_count': None,
                            'actual_launched_command_count_status': 'unknown',
                            'count_scope': 'Parallel workers may have launched commands before pool.map raised; retained record files do not establish total launches or completion.',
                            'raw_failures_preserved': True,
                            'scope': 'Unexpected wrapper failure; retained records do not assert a complete run.'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest='mode', required=True)
    p = modes.add_parser('freeze')
    for mode in ('latest', 'msrv'):
        p.add_argument('--' + mode + '-attempt', required=True)
        p.add_argument('--' + mode + '-results-sha256', required=True)
    p.add_argument('--capture-files-sha256', required=True)
    p = modes.add_parser('run')
    p.add_argument('attempt')
    p.add_argument('--inputs-sha256', required=True)
    args = parser.parse_args()
    if sys.version_info < (3, 11):
        parser.error('Python 3.11+ required')
    if args.mode == 'freeze':
        config = {}
        for mode in ('latest', 'msrv'):
            attempt, digest = getattr(args, mode + '_attempt'), getattr(args, mode + '_results_sha256')
            if not re.fullmatch(r'attempt-[0-9]{2}', attempt) or not re.fullmatch(r'[a-f0-9]{64}', digest):
                parser.error('Fixed attempt-NN and explicit actual result SHA-256 required')
            config[mode] = {'attempt': attempt, 'sha256': digest}
        if not re.fullmatch(r'[a-f0-9]{64}', args.capture_files_sha256):
            parser.error('Explicit actual terminal capture-map SHA-256 required')
        config['capture_files_sha256'] = args.capture_files_sha256
        return freeze(config)
    if not re.fullmatch(r'attempt-[0-9]{2}', args.attempt) or not re.fullmatch(r'[a-f0-9]{64}', args.inputs_sha256):
        parser.error('New attempt-NN and caller-reviewed input SHA-256 required')
    return execute(args.attempt, args.inputs_sha256)


if __name__ == '__main__':
    raise SystemExit(main())
