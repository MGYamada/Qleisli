import CanonicalTarget
namespace CanonicalTargetExamples
open QleisliKernel QleisliKernel.Finite QleisliKernel.Semantics.Exact
open CanonicalTarget
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000

def actualText : String := "OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nc[0] = measure q[0];\n"
def idealText : String := "OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nh q[0];\nc[0] = measure q[0];\n"
def actualBytes := actualText.toUTF8
def idealBytes := idealText.toUTF8
def half : Coefficient := ⟨1,1⟩
def quarter : Coefficient := ⟨1,2⟩
def one : Coefficient := ⟨1,0⟩
def report (bytes : ByteArray) (epsilon : Coefficient := one)
    (majorants : List Coefficient := [half,half]) : String × Nat :=
  let (result,left) := (CanonicalTarget.check bytes epsilon majorants).run 2000000
  (match result with | .ok _ => "ok" | .error error => reprStr error,2000000-left)
#eval ("actual emitted deterministic target epsilon1",report actualBytes)
#eval ("smaller total budget epsilon1/2",report actualBytes half)
#eval ("false per-cell quarter witnesses",report actualBytes one [quarter,quarter])
#eval ("ideal emitted target exactzero engineering",report idealBytes ⟨0,0⟩ [⟨0,0⟩,⟨0,0⟩])
#eval ("missing majorant",report actualBytes one [half])
#eval ("extra majorant",report actualBytes one [half,half,half])
#eval ("negative total",report actualBytes ⟨-1,0⟩)
#eval ("noncanonical half",report actualBytes ⟨2,2⟩)

def rejectedTexts : List (String × String) := [
("header","OPENQASM 3.1;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nc[0] = measure q[0];\n"),
("include","OPENQASM 3.0;\ninclude \"other.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nc[0] = measure q[0];\n"),
("qubits","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[2] q;\nbit[1] c;\nreset q;\nc[0] = measure q[0];\n"),
("results","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[2] c;\nreset q;\nc[0] = measure q[0];\n"),
("reset missing","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nc[0] = measure q[0];\n"),
("reset noncanonical","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q[0];\nc[0] = measure q[0];\n"),
("gate after measurement","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nc[0] = measure q[0];\nh q[0];\n"),
("duplicate measurement","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nc[0] = measure q[0];\nc[0] = measure q[0];\n"),
("wrong readout wire","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nc[0] = measure q[1];\n"),
("wrong result slot","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nc[1] = measure q[0];\n"),
("unknown rotation","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nrx(0.1) q[0];\nc[0] = measure q[0];\n"),
("comment","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q; // hello\nc[0] = measure q[0];\n"),
("trailing garbage","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nc[0] = measure q[0];\ngarbage\n"),
("newline missing","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nc[0] = measure q[0];"),
("gate capacity","OPENQASM 3.0;\ninclude \"stdgates.inc\";\nqubit[1] q;\nbit[1] c;\nreset q;\nh q[0];\nh q[0];\nh q[0];\nh q[0];\nh q[0];\nh q[0];\nh q[0];\nh q[0];\nh q[0];\nc[0] = measure q[0];\n"),
("byte capacity","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")]
#eval rejectedTexts.map (fun (label,text) => (label,(decode text.toUTF8).isOk))
theorem rejected_texts : rejectedTexts.all (fun entry => !(decode entry.2.toUTF8).isOk) = true := by decide +kernel
theorem malformed_utf8 : (decode ⟨#[255]⟩).isOk = false := by decide +kernel
theorem decode_actual : (decode actualBytes).isOk = true := by decide +kernel
theorem decode_ideal : (decode idealBytes).isOk = true := by decide +kernel
theorem actual_accepts : ((CanonicalTarget.check actualBytes one [half,half]).run 2000000).1.isOk = true := by decide +kernel
theorem smaller_refuses : ((CanonicalTarget.check actualBytes half [half,half]).run 2000000).1.isOk = false := by decide +kernel
theorem false_cells_refuse : ((CanonicalTarget.check actualBytes one [quarter,quarter]).run 2000000).1.isOk = false := by decide +kernel
theorem ideal_zero_accepts : ((CanonicalTarget.check idealBytes ⟨0,0⟩ [⟨0,0⟩,⟨0,0⟩]).run 2000000).1.isOk = true := by decide +kernel

def gaps : WorkM (List Scalar) := do
  let retained ← CanonicalTarget.check actualBytes one [half,half]
  [false,true].mapM fun label => do
    let actual ← Raw.InstrumentEquality.coefficient retained.checked.actualHistories [label] 0 0 0 0
    let expected ← Raw.InstrumentEquality.coefficient retained.checked.expectedHistories [label] 0 0 0 0
    let negative ← lift (arithmetic (Exact.Scalar.neg expected))
    lift (arithmetic (Exact.Scalar.add actual negative))
#eval reprStr (gaps.run 2000000).1
theorem exact_choi_gaps : ((gaps.run 2000000).1.map (fun values => values ==
    [⟨half,⟨0,0⟩,⟨0,0⟩,⟨0,0⟩⟩,⟨⟨-1,1⟩,⟨0,0⟩,⟨0,0⟩,⟨0,0⟩⟩])).toOption = some true := by decide +kernel

#eval (["h","x","y","z","s","sdg","t","tdg"].map fun gate =>
  (gate,report ((actualText.replace "c[0] =" (gate ++ " q[0];\nc[0] =")).toUTF8)))
end CanonicalTargetExamples
