"""Independent exact Q(sqrt(2)) calculation; no binary or archived driver calls."""
from fractions import Fraction as F
import json

def multiply(x, y):
    return x[0] * y[0] + 2 * x[1] * y[1], x[0] * y[1] + x[1] * y[0]

actual = [(F(1), F(0)), (F(0), F(0))]
ideal = [(F(0), F(1, 2)), (F(0), F(1, 2))]
actual_probabilities = [multiply(a, a) for a in actual]
ideal_probabilities = [multiply(a, a) for a in ideal]
assert all(a[1] == 0 for a in actual_probabilities + ideal_probabilities)
gaps = [a[0] - b[0] for a, b in zip(actual_probabilities, ideal_probabilities)]
assert gaps == [F(1, 2), F(-1, 2)]
bound = sum(abs(a) for a in gaps)
assert bound == 1 and bound > F(1, 2)
print(json.dumps({'actual': [str(a[0]) for a in actual_probabilities],
                  'ideal': [str(a[0]) for a in ideal_probabilities],
                  'choi_gaps': [str(a) for a in gaps], 'l1_bound': str(bound)}))
