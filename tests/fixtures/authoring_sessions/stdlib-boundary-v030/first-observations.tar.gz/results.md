# First observations for #369 / #167

128 source checks: 40 accepted, 88 refused. No source repairs.

| Source | Route | Accepted | Refused |
| --- | --- | ---: | ---: |
| desired | finite | 4 | 28 |
| desired | selected-raw | 4 | 28 |
| current-translation | finite | 11 | 21 |
| current-translation | selected-raw | 21 | 11 |

The original sources and expectations remain unchanged. Complete raw streams, fresh argv and exits are under checks/. The source/CLI/native identity window is bound by context-before.json and context-after-checks.json. Later root builds do not change this completed-window record.

All finite declarations plus unchanged bundled qft3<=3qubits; explicitly allowed by root before these checks.

## Concrete observations

- Six current ordinary generic-id type specializations pass selected Raw and all six refuse finite Basis materialization. Unit/Bits<0> and Bit/Bits<1> remain distinct; the deliberate equal-width mismatch refuses both paths.
- A valid unused generic refuses finite. Its selected first source has a private main and therefore refuses host visibility; that mistaken prediction is retained, not repaired. The unused missing-Adjointable generic still refuses both common paths.
- The pinned generic CP[1,3] passes selected Raw and refuses finite Nat parameters. The separately fixed ordinary CP also passes selected Raw but refuses finite static-argument profile.
- Ordinary T built from controlling current phase_eighth on Q<Unit> passes finite and selected Raw. Nested control and one owned reference also pass both. Selected adjoint and powers0/8 pass; finite transformations stop at the static unitary subset.
- Wrong global T, erased T phase and wrong global CP reach real fixed-Meaning contract refusal in both paths. Inverse T reaches that refusal only in selected Raw; finite stops earlier at profile eligibility.
- Ordinary local/imported h identity functions pass; lexical and spent local h call specimens refuse without builtin fallback. Bare desired builtin names and new std paths are currently unavailable, while the deliberately unchanged legacy std::quantum import still passes.
- The coherent-lift preparation candidate passes finite and refuses selected runtime projection; the existing init0 control passes both. This separates expressibility from preservation of current source/profile support.
- Current structural permute_axes and physical swap pass source/native checks, but this capture did not inspect emitted wire maps or actual synthesis work.

## Limits

- Positive source checks establish reported native validity and source-step replay only; source_meaning_verified is false. The independent positive T/CP/SWAP matrices were frozen but not submitted as new positive native requests.
- Bad global/inverse/erased T and CP global-scalar requests use separately authored fixed phase_by Meanings; their actual contract refusals are recorded, with finite inverse earlier unsupported.
- Actual emitted output-wire maps, zero additional physical wires, gate/synthesis counts and target preservation were not inspected/certified by these check-only calls.
- No general arbitrary-reference proof, PR/quantitativeRS/EXACT discharge, fallback route, genericQFT completion, algorithm/model benchmark or new guarantee is claimed.

The command-only check --help usage refusal is preserved separately and excluded from source case totals. No alternate retry, repaired source, native fallback or build was used by this observer.
