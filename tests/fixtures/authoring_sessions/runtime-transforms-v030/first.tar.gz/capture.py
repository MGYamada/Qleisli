import hashlib
import json
from pathlib import Path
import subprocess
root = Path('/Users/masa/git/Qleisli')
out = Path(__file__).parent
cli = root / 'target/debug/qleisli'
kernel = root / 'lean-kernel/.lake/build/bin/qleisli-kernel'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
cases = {'generic_classical': 'use std::classical::{empty_bits,prepend_bit};classical fn identity[const A:Basis](a:A)->A{a}pub unitary fn main()->Bits<1>{identity[type(Bits<1>)](prepend_bit[0](1,empty_bits()))}', 'inactive_self': 'use std::quantum::init0;use std::observe::measure_z;unitary fn stop[const n:Nat](q:Q<Bit>)->Q<Bit>{if static n>=1 {stop[0](q)} else {q}}pub observe fn main()->(Bit,Bit){(measure_z(stop[0](init0())),measure_z(stop[1](init0())))}', 'specialized_group_control': 'use std::quantum::{init0,x,t,unit,finish};use std::observe::measure_z;\nunitary fn action[const n:Nat](a:Q<Bit>,b:Q<Bit>)->(Q<Bit>,Q<Bit>){let a=qfor static i in 0..n carry a=a{yield x(a);};(a,b)}\nunitary fn with_unit[const n:Nat](q:Q<Bit>,u:Q<Unit>)->(Q<Bit>,Q<Unit>){let q=qfor static i in 0..n carry q=q{yield x(q);};(q,u)}\npub observe fn main()->(Bit,Bit,Bit){let(c,(a,b))=controlled(action[1])(x(init0()),(init0(),x(init0())));(measure_z(c),measure_z(a),measure_z(b))}', 'group_unit_inverse': 'use std::quantum::{init0,x,t,unit,finish};use std::observe::measure_z;\nunitary fn action[const n:Nat](a:Q<Bit>,b:Q<Bit>)->(Q<Bit>,Q<Bit>){let a=qfor static i in 0..n carry a=a{yield x(a);};(a,b)}\nunitary fn with_unit[const n:Nat](q:Q<Bit>,u:Q<Unit>)->(Q<Bit>,Q<Unit>){let q=qfor static i in 0..n carry q=q{yield x(q);};(q,u)}\npub observe fn main()->Bit{let(q,u)=adjoint(with_unit[1])(init0(),unit(()));finish(u);measure_z(q)}', 'symbolic_phase_inverse': 'use std::quantum::{init0,h,t};use std::observe::measure_z;unitary fn flip(q:Q<Bit>)->Q<Bit>{h(power(t,4)(h(q)))}unitary fn run[const n:Nat](q:Q<Bit>)->Q<Bit>{power(flip,n)(q)}unitary fn phase[const n:Nat](q:Q<Bit>)->Q<Bit>{power(t,n)(q)}pub observe fn main()->(Bit,Bit){(measure_z(run[2](init0())),measure_z(h(adjoint(phase[1])(t(h(init0()))))))}', 'specialized_group_0': 'use std::quantum::{init0,x,t,unit,finish};use std::observe::measure_z;\nunitary fn action[const n:Nat](a:Q<Bit>,b:Q<Bit>)->(Q<Bit>,Q<Bit>){let a=qfor static i in 0..n carry a=a{yield x(a);};(a,b)}\nunitary fn with_unit[const n:Nat](q:Q<Bit>,u:Q<Unit>)->(Q<Bit>,Q<Unit>){let q=qfor static i in 0..n carry q=q{yield x(q);};(q,u)}\npub observe fn main()->(Bit,Bit){let(a,b)=power(action[1],2)(init0(),x(init0()));(measure_z(a),measure_z(b))}', 'specialized_group_1': 'use std::quantum::{init0,x,t,unit,finish};use std::observe::measure_z;\nunitary fn action[const n:Nat](a:Q<Bit>,b:Q<Bit>)->(Q<Bit>,Q<Bit>){let a=qfor static i in 0..n carry a=a{yield x(a);};(a,b)}\nunitary fn with_unit[const n:Nat](q:Q<Bit>,u:Q<Unit>)->(Q<Bit>,Q<Unit>){let q=qfor static i in 0..n carry q=q{yield x(q);};(q,u)}\npub observe fn main()->(Bit,Bit){let(a,b)=adjoint(action[1])(init0(),x(init0()));(measure_z(a),measure_z(b))}', 'specialized_group_2': 'use std::quantum::{init0,x,t,unit,finish};use std::observe::measure_z;\nunitary fn action[const n:Nat](a:Q<Bit>,b:Q<Bit>)->(Q<Bit>,Q<Bit>){let a=qfor static i in 0..n carry a=a{yield x(a);};(a,b)}\nunitary fn with_unit[const n:Nat](q:Q<Bit>,u:Q<Unit>)->(Q<Bit>,Q<Unit>){let q=qfor static i in 0..n carry q=q{yield x(q);};(q,u)}\npub observe fn main()->(Bit,Bit){let(a,b)=power(action[1],0)(init0(),x(init0()));(measure_z(a),measure_z(b))}'}
plan = {'kind': 'bounded generic runtime transforms; zero/one/two/three axes only', 'predictions': {'generic_classical': 'Old finite source profile expected to refuse; future integrated behavior remains unvalidated.', 'inactive_self': 'Old finite source profile expected to refuse; future integrated behavior remains unvalidated.', 'specialized_group_control': 'Old finite source profile expected to refuse; future integrated behavior remains unvalidated.', 'group_unit_inverse': 'Old finite source profile expected to refuse; future integrated behavior remains unvalidated.', 'symbolic_phase_inverse': 'Old finite source profile expected to refuse; future integrated behavior remains unvalidated.', 'specialized_group_0': 'Old finite source profile expected to refuse; future integrated behavior remains unvalidated.', 'specialized_group_1': 'Old finite source profile expected to refuse; future integrated behavior remains unvalidated.', 'specialized_group_2': 'Old finite source profile expected to refuse; future integrated behavior remains unvalidated.'}, 'head_before': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'dirty_before': subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True), 'driver_sha256': sha(Path(__file__)), 'executables_before': {str(p): sha(p) for p in [cli, kernel]}, 'build_attestation': False, 'source_window': 'WIP source and observed executable have distinct identities; adapter edits are not bound to this old CLI.', 'execution': 'not run', 'cases': {}}
for name, source in cases.items():
    target = out / name
    target.mkdir()
    (target / 'main.qli').write_text(source + '\n')
    (target / 'Qargo.toml').write_text('schema-version = 2\n\n[qrate]\nedition = "2026"\n')
    plan['cases'][name] = {'source_sha256': sha(target / 'main.qli'), 'manifest_sha256': sha(target / 'Qargo.toml')}
with (out / 'plan.json').open('x') as f:
    f.write(json.dumps(plan, indent=2) + '\n')
observations = []
for name in cases:
    argv = [str(cli), 'check', str(out / name), '--lean-kernel=' + str(kernel)]
    result = subprocess.run(argv, cwd=root, capture_output=True)
    row = {'case': name, 'argv': argv, 'exit_code': result.returncode}
    for stream in ['stdout', 'stderr']:
        target = out / (name + '.' + stream + '.txt')
        with target.open('xb') as f:
            f.write(getattr(result, stream))
        row[stream] = {'path': target.name, 'sha256': sha(target)}
    row['source_sha256_after'] = sha(out / name / 'main.qli')
    observations.append(row)
record = {'head_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'dirty_after': subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True), 'executables_after': {str(p): sha(p) for p in [cli, kernel]}, 'observations': observations, 'scope': 'Actual original diagnostics only; downstream predictions and source/runtime/target preservation are unvalidated.'}
record['executables_stable'] = record['executables_after'] == plan['executables_before']
record['source_bytes_stable'] = all((r['source_sha256_after'] == plan['cases'][r['case']]['source_sha256'] for r in observations))
with (out / 'observations.json').open('x') as f:
    f.write(json.dumps(record, indent=2) + '\n')
assert record['executables_stable'] and record['source_bytes_stable']
print(json.dumps({'outcomes': [(r['case'], r['exit_code']) for r in observations], 'executables': record['executables_after']}, indent=2))
