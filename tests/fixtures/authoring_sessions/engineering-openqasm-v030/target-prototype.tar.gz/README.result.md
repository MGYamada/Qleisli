# Temporary canonical target-byte study — TP-31-TARGET-QASM-01 (P1)

This is a bounded experiment toward #31 criterion 5, not production target
integration or Issue completion. Replace it after concrete specification review,
independent review and production integration; retain the first sources and
actual diagnostics before removing the temporary copies. #31/#163 remain open.

The current normal Rust CLI SHA-256 is
`d85e520f79d83405ea783357a2e7d8159fad2b4a779caa677da1364df0beeca0`;
the selected kernel is
`7e43c6863ad459a5adcb16d1e36021357bb21b516531d59e6e36cf0ee1db4c70`.
No binary was rebuilt by this study. All fourteen fresh CLI commands are
captured with complete output. The first two attempted programs mistakenly
named their open functions `main`; check and export both refused the open entry.
The separate `open-functions/` source has the intended public `ideal` and
`actual` functions from `Q<Unit>` to `Bit`; it passes ordinary check and export
refuses the missing closed entry. Separate `closed/` projects explicitly call
`operation(unit(()))`, pass, and produce actual canonical target bytes. Source
checks and numerical simulations do not prove export preservation.

`actual.qasm` is the real exported deterministic zero-readout target; its
SHA-256 is `d572ba6e06085ff4aa621d922548dacdb1a2fe7cd80d1338b57c1e1bc30bfe28`.
`ideal.qasm` is the real exported H/uniform-readout target; its SHA-256 is
`81e17d63050c15e172fc76a940009253cedee2e79f50f00443dab9bb2e37a845`.
Both have the literal OpenQASM 3.0 header, `stdgates.inc` declaration, one quantum
and classical register, explicit reset and ordered terminal measurement.
The exporter is a CLOSED terminal instrument. It is not an arbitrary-input
pure operation or a coherent component.

`CanonicalTarget.lean` is Mathlib-free. Its independent pure ASCII-byte reader
retains the literal ByteArray and recognizes only the fixed canonical one-qubit
terminal profile `openqasm3-canonical-one-qubit-terminal-r8-v1`: at most eight
h/x/y/z/s/sdg/t/tdg gate lines, then exactly `c[0] = measure q[0];` and the final
newline. It accepts at most 1024 target bytes. It loads no include file. All
other statements, includes, gate forms, operands, extra readouts and gates after
readout refuse. These temporary limits do not change any production limit.

The decoder constructs the actual original graph itself, preserving an explicit
zero-width logical input owner and consuming it with unpackUnit before zero
preparation. This Unit adapter is explicit because the ordinary foreign importer
produces a genuinely closed graph with no input owner, whereas the existing
instrument contract requires one owner. It creates no false open-input claim.
The independent ideal is a literal original H/readout graph, separately labeled
manual IR. One conceptual retained invocation uses the existing actual
EngineeringInstrument checker on both originals, complete Unit/Bit signatures,
Kraus completeness, all public labels and histories, dyadic majorants and the
literal bound. The returned data bind target profile, metric, budget and original
bytes; they are neither an accepted handle nor a native transport receipt.

`decode_original` proves literal target-byte retention. The logical input,
explicit owner consumption and terminal result have general proofs.
`check_bound` extracts the actual fresh original-graph checking execution.
`CanonicalTargetMeaning.check_meaning` connects that same decoded invocation to
the existing full instrument Meaning, including complete-adjoint bounds for every
finite reference and observable. `actual_target_meaning` consumes the actual
kernel-reduced successful execution; it does not assume a producer success flag.
There is no source/export-preservation theorem or independently adopted target
reference in this study.

The actual deterministic target versus manual uniform ideal has exact ordered
Choi differences +1/2 and -1/2. Two unsquared 1/2 majorants and epsilon1 pass
with 1045 shared work; epsilon1/2 refuses. False quarter-cell witnesses refuse.
The identical H target/ideal at epsilon0 passes with 1084 work and retains the
same engineering-only status. Missing/extra majorants, negative/noncanonical
budgets refuse. Sixteen syntax/capacity mutations and a malformed byte refuse;
all eight admitted single-qubit gates separately decode and check. Nine named
bounded facts are reduced by Lean's kernel, including the exact Choi differences;
the remaining #eval observations are runtime evidence, separately retained.
The exact rational Q(sqrt2) host oracle agrees and is separate from Lean proof
and the captured floating simulation outputs.

`CanonicalGatePhases.lean` independently reconstructs each admitted gate on an
OPEN Bit owner before any instrument quotient and checks all eight literal
complex matrices. H has its signed lower-right entry; Y is [[0,-i],[i,0]];
S/SDG are diag(1,±i), and T/TDG are diag(1,zeta8^(±1)). Kernel-decided facts reject
-Y's wrong global phase and swapped S/SDG and T/TDG directions. Thus the terminal
CP metric cannot silently redefine the exact gate meanings. These matrices use
the declared mathematical standard-library meaning as a specification
assumption, not hardware behavior. The primary reference consulted was the
[OpenQASM standard library](https://openqasm.com/language/standard_library.html),
which marks these gates as available in 3.0. The tool could not fetch the separate
versioned 3.0 URL. No external prose or implementation was imported or adopted.

Final decoder, bounded examples, exact gate checks and mathematical refinement
compile with warningAsError. Audit output records twenty theorem declarations;
only standard Lean axioms are permitted. First sources and every failed attempt
remain separate: name ambiguity, unused source-table rejection, the opaque UTF-8
primitive's kernel-reduction obstruction, and elaboration/proof repairs are not
success evidence. The byte reader replaced the runtime UTF-8 dependency; the
original failures were not overwritten or reclassified.

No tracked source, registry, production binary, build target, dependency,
fixture, guarantee record or admission was changed. All287 current source-map
hashes still match production closure
`143e4495399af77e7f480251dfb56d78b71364be2705445cefb318af3cc3da46`.
This identity check is not a fresh production proof replay. Broader
QS/PR/RS/EXACT obligations and the two admitted scoped QS guarantees retain their
recorded meanings and status. Production native/API/QDV1 integration, source and
emitted-target preservation, synthesis evidence, broader targets, composed
certificates and target resource claims remain separate. Engineering epsilon0
cannot authorize exact correspondence, coherent control, inverse, cleanup or
constitutional PR/RS.
