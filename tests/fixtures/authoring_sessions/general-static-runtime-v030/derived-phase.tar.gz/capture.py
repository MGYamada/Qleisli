import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/Users/masa/git/Qleisli')
out = Path(__file__).parent
cli = root/'target/debug/qleisli'
kernel = root/'lean-kernel/.lake/build/bin/qleisli-kernel'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
final = '''unitary fn scalar_eighth(u:Q<Unit>)->Q<Unit>{global_phase_eighth(u)}
pub unitary fn derived_t(q:Q<Bit>)->Q<Bit>{
    let(q,u)=controlled(scalar_eighth)(q,unit(()));finish(u);q
}
'''
legacy = '''use std::quantum::{phase_eighth,unit,finish};
unitary fn scalar_eighth(u:Q<Unit>)->Q<Unit>{phase_eighth(u)}
unitary fn derived_t(q:Q<Bit>)->Q<Bit>{
    let(q,u)=controlled(scalar_eighth)(q,unit(()));finish(u);q
}
'''
contract = '''classical fn t_phase(b:Bit)->(Bit,(Bit,Bit)){(b,(0,0))}
meaning TMeaning:Bit=phase_by(t_phase);
unitary fn apply_t[const U:Op<Bit,TMeaning>](q:Q<Bit>)->Q<Bit>
requires Applicable(U){U(q)}
pub unitary fn checked(q:Q<Bit>)->Q<Bit>{apply_t[checked_op(derived_t,TMeaning)](q)}
'''
wrong = '''use std::quantum::phase_eighth;
unitary fn derived_t(q:Q<Bit>)->Q<Bit>{phase_eighth(q)}
'''
cases = {'final_unqualified':final,
         'legacy_exact_t':legacy+contract,
         'global_scalar_is_not_t':wrong+contract}
predictions = {'final_unqualified':'Current CLI should refuse missing language-owned global_phase_eighth; final cutover must accept.',
               'legacy_exact_t':'Exact requested TMeaning should accept without an additional physical wire.',
               'global_scalar_is_not_t':'Exact TMeaning must reject scalar zeta I on Bit; it is a valid Unitary with a different meaning.'}
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
executables = {str(p):sha(p) for p in [cli,kernel]}
plan = {'kind':'informed zero-width/one-bit derived-T source study; not a blind benchmark',
        'predictions':predictions,'execution':'not run','head_before':head,
        'dirty_before':subprocess.check_output(['git','status','--short'],cwd=root,text=True),
        'executables_before':executables,'build_attestation':False,
        'source_window':'Concurrent unrelated WIP may change; observed HEAD/dirty state does not bind CLI build inputs.',
        'driver_sha256':sha(Path(__file__)),'cases':{}}
for name,text in cases.items():
    p=out/name;p.mkdir()
    (p/'main.qli').write_text(text)
    (p/'Qargo.toml').write_text('schema-version = 2\n\n[qrate]\nedition = "2026"\n')
    plan['cases'][name]={'source_sha256':sha(p/'main.qli'),'manifest_sha256':sha(p/'Qargo.toml')}
with (out/'plan.json').open('x') as f:f.write(json.dumps(plan,indent=2)+'\n')
observations=[]
for name in cases:
    p=out/name;argv=[str(cli),'check',str(p),'--lean-kernel='+str(kernel)]
    result=subprocess.run(argv,cwd=root,capture_output=True)
    row={'case':name,'argv':argv,'exit_code':result.returncode}
    for stream in ['stdout','stderr']:
        target=out/(name+'.'+stream+'.txt')
        with target.open('xb') as f:f.write(getattr(result,stream))
        row[stream]={'path':target.name,'sha256':sha(target)}
    row['source_sha256_after']=sha(p/'main.qli')
    observations.append(row)
after={str(p):sha(p) for p in [cli,kernel]}
record={'head_after':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'dirty_after':subprocess.check_output(['git','status','--short'],cwd=root,text=True),
        'executables_after':after,'executables_stable':executables==after,
        'source_bytes_stable':all(r['source_sha256_after']==plan['cases'][r['case']]['source_sha256'] for r in observations),
        'observations':observations,'scope':'Actual original diagnostics; no source/native/runtime preservation or general resource theorem.'}
with (out/'observations.json').open('x') as f:f.write(json.dumps(record,indent=2)+'\n')
assert record['executables_stable'] and record['source_bytes_stable']
print(json.dumps({'outcomes':[(r['case'],r['exit_code']) for r in observations],
                  'executables':after},indent=2))
