# Primitive/derived cutover first sources: #369 / #167

This is an informed authoring packet, frozen before any Qleisli invocation.
No algorithm or model benchmark, passing check, native decision, source-preservation
proof, exactness certificate, target-resource proof or new constitutional guarantee
is claimed. The source author inspected both Issues, the implementation map at
/private/tmp/qleisli-stdlib-migration-map-7cs4jqsv/implementation-map.md,
the existing authoring-session index and the selected-consumer review.

Each case keeps a desired cutover program and a separately authored current
translation. Neither has been run. Some current translations are intentionally
unsupported (generic finite materialization, coherent lift in selected projection)
or negative (false exact Meaning, local noncallability, primitive providers).
Predictions in cases.json are hypotheses, not observations. A first actual refusal
must be retained rather than repairing either frozen source in place. Source repairs,
command/manifest repairs and repeated observations require separate new snapshots.

Desired library candidates are ordinary .qli designs, not injected std modules or
adopted implementation. Desired std::gate::id and controlled_phase expect future
ordinary source integration. The generic controlled-phase candidate is deliberately
pinned to j=1,k=3, so this packet does not establish the complete former j/k domain.
The current fixed translation tests that one operation separately from generic support.

All programs use at most two physical program qubits. Q<Unit> and Q<Bits<0>> retain
distinct logical zero-width owners. The two-owner T probe allows entangled inputs
but is only a one-owned-reference bounded case. CP's diagonal is symmetric under
control/target exchange, so ordered source ports and wire maps remain independent
obligations. The exact matrices were written independently, before emission; they
are mathematical requests, not native protocol files or producer-derived evidence.
No floating approximation or engineering epsilon, including zero, substitutes for
exact phase, effect, access, cleanup, QS, PR or quantitative RS duties.

The proposed primitive-name precedence is a design hypothesis: lexical bindings,
local source declarations and explicit imports retain their existing authority before
bare primitive fallback. Consumed/noncallable locals never trigger fallback. No new
name-resolution adoption is claimed here. Legacy std::quantum imports are retained
as deliberately unchanged future refusal cases; current acceptance would not be an
implementation failure before the adopted cutover is implemented.

The T body is always the ordinary controlled-scalar wrapper. Its current translation
uses phase_eighth for the exact global scalar and never substitutes sealed t.
Physical SWAP's preserved source has three CNOT applications; emitted synthesis/gate
work after derivation must be inspected, not assumed. Structural permute_axes changes
wire coordinates without a physical SWAP. Equal operator matrices do not equate
wire maps, physical realizations or resource obligations.

Execution is pending root authorization after #355 validation and selection of an
unchanging audited CLI/native checker. No CLI path, hash, executed argv or result is
invented. A future observer must independently select/capture CLI and native identities,
record context before/after, issue fresh commands for these frozen projects, and retain
all real stdout/stderr/status, phase/owner/axis counterexamples and profile limitations.
No frozen historical source, repository fixture/map, Issue or corpus source was edited.
