# Generic/dormant first study: audited original observations

All fourteen fresh literal check commands completed once: three accepted, eleven refused, zero timeouts. Every original prediction matched, including the explicitly uncertain C harmless-main acceptance. No sources, plans, driver, predictions, streams, records or original summary were changed during this audit.

| Case | Finite check | Selected Raw check |
| --- | --- | --- |
| A: generic id, exact Unit/Bit/Bits0/full trees, forwarding alias and local shadow | unsupported: static argument profile | accepted |
| B: generic separate-A/B structural reversal | unsupported: static argument profile | accepted |
| C: harmless main with dormant generic false Meaning requests | unsupported: opaque Basis parameters | accepted, selected-specialization only |
| D: direct closed false X-versus-Z Meaning under adjoint/zero power | contract refusal | contract refusal |
| E: small Nat helper then intermediate-u32 overflow, fixed one-Bit data | unsupported: static Nat parameters | limit: concrete natural arithmetic exceeds u32 or has negative subtraction |
| F: imported public Observe provider whose implementation body is H | common effect refusal | common effect refusal |

Both separately predeclared C controls selected the actual original helper with A=Unit. unused_binding refused the original main::hold::U Meaning request; unused_zero refused the original main::unused_zero step-0 request. D's finite control refused the exact equation; its selected control refused the actual original Meaning request. No control was added after seeing a result.

All three acceptances explicitly report native-validity, request_origin=none, request_checked=false, source_steps_checked=true, source_meaning_verified=false, source_preservation_verified=false, and checked-produced-ir authority. Their source-check scope is all-supplied-module-declarations; native-check scope is selected-specialization. The kernel JSON identity is unpinned. Thus C's accepted harmless main is not evidence that dormant unmaterialized generic requests were semantically checked or discharged. Explicitly selecting the helpers exposes their false Meaning. Finite early profile refusals do not validate later obligations.

Every before/after window and initial/final window binds the same canonical input inventory digest 02460b6b65f67015dbd1e81cdc59eefe6b6573b20630b643979ca57c24829a63: 18,971 repository tracked files, all 20 frozen first-source packet files and both exact executable files (18,993 total). Captured HEAD is a70211706db3928bc0e172bd57458a1127c57cd1, tree 77e66e7890d770ea9c1d37cc81d19c5c7fde6608, with empty Git status throughout. The final audit independently recomputed the canonical inventory digest, verified every captured file's actual bytes/mode, and checked all 173 authoring production/config bindings against it.

The only CLI was /private/tmp/qleisli-empty-basis-validation-F4CYs1Kt/normal-qleisli, SHA-256 d6d285819917aa3d1167c3efc73d7f81ec684b5ee89ce7ed37c8660997070e64. It is explicitly a prior runtime build copy; clean observed a702117 is not a clean commit-to-binary build attestation. The kernel was /Users/masa/git/Qleisli/lean-kernel/.lake/build/bin/qleisli-kernel, SHA-256 54c9d60b80f67217abd95c8fe6ec1c06aa262e142d5e6db30f46a20cb90faf07. External exact byte bindings do not turn the CLI's unpinned identity field into an enforced pin.

Per-command records preserve exact argv, exit code, raw stdout/stderr, before/after UTC windows and the original seconds field. The seconds field includes the command and the post-command complete input-inventory/metadata capture, as the original driver's code shows; it must not be reported as isolated CLI-only execution time. No separate subprocess-only duration was captured. All recorded intervals are finite, positive and ordered, and every stderr stream is empty.

The source freeze remains d9a76a5c4a3951485f9f5c687172395c9d2b230fd20ecab243048400d088690a (19 listed files / 62,872 bytes; all 20 files including freeze / 66,507 bytes). Original summary.json remains SHA-256 34ad5557ccfd2bd15a534d58ea22e340125e7b225b40cd35c3b977e3cef5a899. Original observations.json remains SHA-256 8e6e5acdd1eaa28ea46896b2dad9b7f27717391809d5ce3c8010578cc153c8ea. The original driver remains SHA-256 d7c11811adcf78073cd10f7b7d5ef7baea24ec19f96fd7fe99762d9b90858b53 and was inspected strictly as data, never imported or executed during audit.

The new audit.json preserves a complete inventory of all 47 pre-audit observation files and the audit assertions/results. capture-freeze.json binds every observation file except itself after these additions. There is no unfinished capture. This is an informed bounded study with at most two authored concrete physical qubits, not a source-meaning/preservation theorem, arbitrary-reference proof, PR/RS/EXACT discharge, guarantee admission or Issue/feature completion. Existing protected/pending scopes and exclusions remain unchanged. The audit performed no CLI/native/Cargo/build/run/emission, repository write or GitHub action.
