from pathlib import Path
import hashlib,json,subprocess
repo=Path('/Users/masa/git/Qleisli');out=Path(__file__).parent
cli=repo/'target/debug/qleisli';kernel=repo/'lean-kernel/.lake/build/bin/qleisli-kernel'
cases={
'prepare_zero':'use std::quantum::unit;use std::observe::measure_z;isometry fn prepare_zero()->Q<Bit>{basis unit(()) as () {0}}pub observe fn main()->Bit{measure_z(prepare_zero())}',
'make_empty':'use std::quantum::{unit,finish};use std::classical::empty_bits;unitary fn make_empty()->Q<Bits<0>>{basis unit(()) as () {empty_bits()}}pub unitary fn main()->Unit{finish(basis make_empty() as label {()})}',
'consume_empty':'use std::quantum::finish;use std::registers::empty;unitary fn consume_empty(q:Q<Bits<0>>)->Unit{finish(basis q as label {()})}pub unitary fn main()->Unit{consume_empty(empty())}',
'phase_reference':'use std::quantum::{phase_eighth,unit,init0,h};use std::observe::measure_z;isometry fn action(r:Q<Bit>,u:Q<Unit>)->(Q<Bit>,Q<Bit>){(r,basis phase_eighth(u) as () {0})}pub observe fn main()->(Bit,Bit){let(r,q)=action(h(init0()),unit(()));(measure_z(r),measure_z(q))}'
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,source in cases.items():
 d=out/name;d.mkdir();(d/'main.qli').write_text(source+'\n');(d/'Qargo.toml').write_text('schema-version = 2\n\n[qrate]\nedition = "2026"\n')
plan={'kind':'separate ordinary-main wrapper translations; first sources unchanged','driver_sha256':sha(Path(__file__)),'executables_before':{str(p):sha(p) for p in [cli,kernel]},'build_attestation':False,'prediction':'These wrappers should satisfy ordinary main entry shape; checking outcome and all downstream semantics remain unvalidated before the call.','cases':{name:{'source_sha256':sha(out/name/'main.qli'),'manifest_sha256':sha(out/name/'Qargo.toml')} for name in cases}}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rows=[]
for name in cases:
 argv=[str(cli),'check',str(out/name),'--lean-kernel='+str(kernel)];result=subprocess.run(argv,cwd=repo,capture_output=True);row={'case':name,'argv':argv,'exit_code':result.returncode}
 for stream in ['stdout','stderr']:
  p=out/(name+'.'+stream+'.txt');p.write_bytes(getattr(result,stream));row[stream]={'path':p.name,'sha256':sha(p)}
 row['source_sha256_after']=sha(out/name/'main.qli');rows.append(row)
record={'observations':rows,'executables_after':{str(p):sha(p) for p in [cli,kernel]},'scope':'Actual wrapper check results only; no execution/build attestation/preservation claim.'};record['executables_stable']=record['executables_after']==plan['executables_before'];record['sources_stable']=all(r['source_sha256_after']==plan['cases'][r['case']]['source_sha256'] for r in rows)
(out/'observations.json').write_text(json.dumps(record,indent=2)+'\n');assert record['executables_stable'] and record['sources_stable'];print(json.dumps([(r['case'],r['exit_code']) for r in rows]))
