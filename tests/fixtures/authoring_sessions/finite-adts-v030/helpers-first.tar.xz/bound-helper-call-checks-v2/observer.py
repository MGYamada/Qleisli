import hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
R=Path('/Users/masa/git/Qleisli');Q=Path('/Users/masa/git/qlirgo');P=Path('/private/tmp/qleisli-helper-resume-20261021')
label=sys.argv[1];argv=json.loads(sys.argv[2]);cwd=R/sys.argv[3] if len(sys.argv)>3 else R;O=P/label;O.mkdir()
K=R/'lean-kernel/.lake/build/bin/qleisli-kernel'
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def state(root):
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=root).decode(),'files':{n:digest(root/n) if (root/n).is_file() else 'missing' for n in sorted(set(filter(None,names)))}}
def snapshot():return {'root':state(R),'qlirgo':state(Q),'kernel':digest(K),'external_inputs':{a:digest(Path(a)) for a in argv if a.startswith('/') and Path(a).is_file()}}
(O/'observer.py').write_bytes(Path(__file__).read_bytes());before=snapshot();(O/'before.json').write_text(json.dumps(before,indent=2)+'\n')
for name in before['root']['files']:
 if name.endswith('.lean') and ('sourcetypes' in name.lower() or 'sourcenatural' in name.lower() or 'sourceaffine' in name.lower() or name=='lean-kernel/Tests.lean'):
  target=O/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/name).read_bytes())
env=os.environ.copy();env['PATH']='/opt/homebrew/bin:'+env['PATH'];start=time.monotonic();timeout=False
with (O/'stdout').open('wb') as out,(O/'stderr').open('wb') as err:
 process=subprocess.Popen(argv,cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
 (O/'live.json').write_text(json.dumps({'pid':process.pid,'argv':argv,'limit_seconds':180})+'\n')
 try:code=process.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
  code=process.returncode
after=snapshot();same=before==after;report={'label':label,'argv':argv,'cwd':str(cwd),'before':before,'after':after,'source_and_kernel_unchanged':same,'exit_code':code,'timeout':timeout,'seconds':time.monotonic()-start,'pass':code==0 and same and not timeout}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['label','exit_code','timeout','seconds','source_and_kernel_unchanged','pass']}),flush=True)
for name in ['stdout','stderr']:
 with (O/name).open('rb') as stream:
  stream.seek(max(0,(O/name).stat().st_size-4000));print(stream.read(4000).decode(errors='replace'))
sys.exit(0 if report['pass'] else 1)
