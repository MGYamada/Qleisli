//! Common untrusted source type identity, independent of lowering and evidence.
//!
//! A size parameter is an implementation representation (symbolic or closed),
//! not a source Basis parameter. Ordinary `Bit` and `Q<Bit>` share the same basis
//! tree; their ownership differs only at Q. Both source profiles classify the
//! canonical types here and enforce their existing lowering restrictions separately.
use std::convert::Infallible;
use std::fmt;

/// Concrete or symbolic exact type tree. Construction remains frontend-private.
#[derive(Clone, Debug)]
pub struct Type<N> {
    pub(super) kind: Kind<N>,
}

#[derive(Clone, Debug)]
pub(super) enum Kind<N> {
    Unit,
    Bit,
    Bits(N),
    Parameter(TypeParameter),
    Q(Box<Type<N>>),
    Tuple(Vec<Type<N>>),
}

/// Opaque Basis identity from the common lexical resolver. The discarded
/// preflight projection has no key; checked types always have one.
#[derive(Clone, Debug)]
pub(super) struct TypeParameter {
    pub key: Option<super::resolve::locals::BinderKey>,
    pub name: String,
    pub span: super::ast::Span,
}

/// Evaluation category is not a second ordinary finite type universe.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Stage {
    Basis,
    Runtime,
}

/// Profile-specific size resolution, diagnostics and existing work accounting.
/// The constructor/ownership rules themselves are shared by both consumers.
pub(super) trait SourceTypeContext {
    type Size;
    type Error;
    fn resolve_size(&mut self, size: &super::ast::Natural) -> Result<Self::Size, Self::Error>;
    fn resolve_basis(&mut self, name: &super::ast::Ident) -> Result<Type<Self::Size>, Self::Error>;
    fn quantum_basis_error(&mut self, span: super::ast::Span) -> Self::Error;
    fn checked_node(
        &mut self,
        source: &super::ast::Type,
        stage: Stage,
        ty: &Type<Self::Size>,
    ) -> Result<(), Self::Error>;
}

/// Classify the one source type universe without selecting a backend or
/// inserting a physical/structural conversion. Children are checked first in
/// source order, preserving each consumer's bounded accounting and locations.
pub(super) fn classify_source<C: SourceTypeContext>(
    source: &super::ast::Type,
    stage: Stage,
    context: &mut C,
) -> Result<Type<C::Size>, C::Error> {
    use super::ast::TypeKind;
    let ty = match &source.kind {
        TypeKind::Unit => Type::unit(),
        TypeKind::Bit => Type::bit(),
        TypeKind::Bits(size) => Type::bits(context.resolve_size(size)?),
        TypeKind::Named(name) => context.resolve_basis(name)?,
        TypeKind::Q(basis) => {
            if stage == Stage::Basis {
                return Err(context.quantum_basis_error(source.span));
            }
            Type::quantum(classify_source(basis, Stage::Basis, context)?)
        }
        TypeKind::Tuple(fields) => Type::tuple(
            fields
                .iter()
                .map(|field| classify_source(field, stage, context))
                .collect::<Result<_, _>>()?,
        ),
    };
    context.checked_node(source, stage, &ty)?;
    Ok(ty)
}

#[derive(Default, Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct TreeSize {
    pub nodes: usize,
    pub depth: usize,
}

impl<N> Type<N> {
    /// Resolve sizes without changing any constructor or owner boundary.
    pub(super) fn map_sizes<M, E>(
        &self,
        resolve: &mut impl FnMut(&N) -> Result<M, E>,
    ) -> Result<Type<M>, E> {
        self.map_parts(resolve, &mut |parameter| {
            Ok(Type::parameter(parameter.clone()))
        })
    }
    /// Substitute sizes and opaque bases while retaining every surrounding
    /// constructor, owner boundary, tuple arity and source order.
    pub(super) fn map_parts<M, E>(
        &self,
        resolve: &mut impl FnMut(&N) -> Result<M, E>,
        bases: &mut impl FnMut(&TypeParameter) -> Result<Type<M>, E>,
    ) -> Result<Type<M>, E> {
        Ok(match &self.kind {
            Kind::Unit => Type::unit(),
            Kind::Bit => Type::bit(),
            Kind::Bits(size) => Type::bits(resolve(size)?),
            Kind::Parameter(parameter) => bases(parameter)?,
            Kind::Q(basis) => Type::quantum(basis.map_parts(resolve, bases)?),
            Kind::Tuple(fields) => Type::tuple(
                fields
                    .iter()
                    .map(|field| field.map_parts(resolve, bases))
                    .collect::<Result<_, _>>()?,
            ),
        })
    }
    pub(super) fn parameter(parameter: TypeParameter) -> Self {
        Self {
            kind: Kind::Parameter(parameter),
        }
    }
    pub(super) fn unit() -> Self {
        Self { kind: Kind::Unit }
    }
    pub(super) fn bit() -> Self {
        Self { kind: Kind::Bit }
    }
    pub(super) fn bits(size: N) -> Self {
        Self {
            kind: Kind::Bits(size),
        }
    }
    pub(super) fn quantum(basis: Self) -> Self {
        debug_assert!(basis.is_basis(), "Q requires a finite ordinary basis tree");
        Self {
            kind: Kind::Q(Box::new(basis)),
        }
    }
    pub(super) fn tuple(fields: Vec<Self>) -> Self {
        Self {
            kind: Kind::Tuple(fields),
        }
    }
    pub(super) fn pair(a: Self, b: Self) -> Self {
        Self::tuple(vec![a, b])
    }
    pub(super) fn tuple_fields(&self) -> Option<&[Self]> {
        match &self.kind {
            Kind::Tuple(fields) => Some(fields),
            _ => None,
        }
    }
    /// Match one destructuring node; consumers recursively bind its children.
    /// The empty pattern matches only ordinary Unit, never an empty tuple or
    /// any quantum owner. Nonempty patterns preserve immediate tuple arity.
    pub(super) fn pattern_fields(&self, arity: usize) -> Option<&[Self]> {
        match &self.kind {
            Kind::Unit if arity == 0 => Some(&[]),
            Kind::Tuple(fields) if arity != 0 && fields.len() == arity => Some(fields),
            _ => None,
        }
    }
    pub(super) fn into_pair(self) -> Option<Vec<Self>> {
        match self.kind {
            Kind::Tuple(fields) if fields.len() == 2 => Some(fields),
            _ => None,
        }
    }
    /// Borrow the exact ordinary basis tree of one quantum owner. This is a
    /// type view, not an ordinary value or an implicit owner split.
    pub fn quantum_basis(&self) -> Option<&Self> {
        match &self.kind {
            Kind::Q(basis) => Some(basis),
            _ => None,
        }
    }
    /// Bounded retained type storage. The Q wrapper shares its owner's cell;
    /// every node inside its basis still counts, even when it has zero width.
    pub(super) fn storage_size(&self, nodes: usize, depth: usize) -> Option<TreeSize> {
        let mut size = TreeSize::default();
        let mut pending = vec![(self, 1)];
        while let Some((ty, level)) = pending.pop() {
            if level > depth {
                return None;
            }
            if let Kind::Q(basis) = &ty.kind {
                pending.push((basis, level));
                continue;
            }
            size.nodes = size.nodes.checked_add(1)?;
            size.depth = size.depth.max(level);
            if size.nodes > nodes {
                return None;
            }
            if let Kind::Tuple(fields) = &ty.kind {
                if fields.len() > 64
                    || size
                        .nodes
                        .checked_add(pending.len())?
                        .checked_add(fields.len())?
                        > nodes
                {
                    return None;
                }
                pending.extend(fields.iter().rev().map(|field| (field, level + 1)));
            }
        }
        Some(size)
    }
    pub(super) fn is_quantum_owner(&self) -> bool {
        matches!(self.kind, Kind::Q(_))
    }
    pub(super) fn is_basis(&self) -> bool {
        !self.linear()
    }
    pub(super) fn linear(&self) -> bool {
        let mut pending = vec![self];
        while let Some(ty) = pending.pop() {
            match &ty.kind {
                Kind::Q(_) => return true,
                Kind::Tuple(fields) => pending.extend(fields),
                _ => {}
            }
        }
        false
    }
    /// The existing sized provider profile requires a nonempty tree of owners.
    pub(super) fn quantum_group(&self) -> bool {
        let mut pending = vec![self];
        while let Some(ty) = pending.pop() {
            match &ty.kind {
                Kind::Q(_) => {}
                Kind::Tuple(fields) if !fields.is_empty() => pending.extend(fields),
                _ => return false,
            }
        }
        true
    }
    /// Full source-type representation, including Q and its basis subtree.
    pub(super) fn tree_size(&self) -> TreeSize {
        self.size(false)
    }
    /// Preserve the existing sized profile's value-cell budget: one owner is
    /// one cell, independently of the added explicit Q representation node.
    /// This is accounting, never type equality or quantum-owner elimination.
    pub(super) fn owner_shape_size(&self) -> TreeSize {
        self.size(true)
    }
    fn size(&self, owners_atomic: bool) -> TreeSize {
        let mut size = TreeSize::default();
        let mut pending = vec![(self, 1)];
        while let Some((ty, depth)) = pending.pop() {
            size.nodes += 1;
            size.depth = size.depth.max(depth);
            match &ty.kind {
                Kind::Q(inner) if !owners_atomic => pending.push((inner, depth + 1)),
                Kind::Tuple(fields) => pending.extend(fields.iter().map(|f| (f, depth + 1))),
                _ => {}
            }
        }
        size
    }
    /// Compare tags, immediate arity, order and nesting; delegate only static
    /// size equality. A mismatch must not suppress errors in later sibling size
    /// obligations: the sized checker previously checked every paired sibling.
    pub(super) fn equivalent_by<E>(
        &self,
        other: &Self,
        sizes: &mut impl FnMut(&N, &N) -> Result<bool, E>,
    ) -> Result<bool, E> {
        self.equivalent_by_budgeted(other, sizes, &mut |_| Ok(()))
    }

    /// Account for actual paired traversal and temporary stack entries before
    /// work. Keep the complete sibling traversal and its size-error order.
    pub(super) fn equivalent_by_budgeted<E>(
        &self,
        other: &Self,
        sizes: &mut impl FnMut(&N, &N) -> Result<bool, E>,
        charge: &mut impl FnMut(usize) -> Result<(), E>,
    ) -> Result<bool, E> {
        let mut equal = true;
        charge(1)?;
        let mut pending = vec![(self, other)];
        while let Some((a, b)) = pending.pop() {
            charge(1)?;
            match (&a.kind, &b.kind) {
                (Kind::Unit, Kind::Unit) | (Kind::Bit, Kind::Bit) => {}
                (Kind::Bits(a), Kind::Bits(b)) => equal &= sizes(a, b)?,
                (Kind::Parameter(a), Kind::Parameter(b)) => {
                    equal &= match (&a.key, &b.key) {
                        (Some(a), Some(b)) => a == b,
                        (None, None) => a.name == b.name,
                        _ => false,
                    };
                }
                (Kind::Q(a), Kind::Q(b)) => {
                    charge(1)?;
                    pending.push((a, b));
                }
                (Kind::Tuple(a), Kind::Tuple(b)) if a.len() == b.len() => {
                    charge(a.len())?;
                    pending.extend(a.iter().zip(b).rev())
                }
                _ => equal = false,
            }
        }
        Ok(equal)
    }
    pub(super) fn display(&self, stage: Stage) -> DisplayType<'_, N> {
        DisplayType(self, stage)
    }
    pub(super) fn sized_debug(&self) -> SizedDebug<'_, N> {
        SizedDebug(self)
    }
}

impl<N: PartialEq> PartialEq for Type<N> {
    fn eq(&self, other: &Self) -> bool {
        self.equivalent_by(other, &mut |a, b| Ok::<_, Infallible>(a == b))
            .unwrap()
    }
}
impl<N: Eq> Eq for Type<N> {}

/// Canonical source rendering; evaluation stage does not rename ordinary types.
pub(super) struct DisplayType<'a, N>(&'a Type<N>, Stage);
impl<N: fmt::Display> fmt::Display for DisplayType<'_, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        enum Part<'a, N> {
            Type(&'a Type<N>, Stage),
            Text(&'static str),
        }
        let mut pending = vec![Part::Type(self.0, self.1)];
        while let Some(part) = pending.pop() {
            match part {
                Part::Text(s) => f.write_str(s)?,
                Part::Type(ty, stage) => match &ty.kind {
                    Kind::Unit => f.write_str("Unit")?,
                    Kind::Bit => f.write_str("Bit")?,
                    Kind::Bits(n) => write!(f, "Bits<{n}>")?,
                    Kind::Parameter(parameter) => f.write_str(&parameter.name)?,
                    Kind::Q(inner) => {
                        f.write_str("Q<")?;
                        pending.extend([Part::Text(">"), Part::Type(inner, Stage::Basis)]);
                    }
                    Kind::Tuple(fields) => {
                        f.write_str("(")?;
                        pending.push(Part::Text(")"));
                        for (i, field) in fields.iter().enumerate().rev() {
                            pending.push(Part::Type(field, stage));
                            if i > 0 {
                                pending.push(Part::Text(","));
                            }
                        }
                    }
                },
            }
        }
        Ok(())
    }
}

/// Diagnostic adapter for the current sized checker's printed type names.
/// It cannot participate in equality, ownership, signature selection or caches.
pub(super) struct SizedDebug<'a, N>(&'a Type<N>);
impl<N: fmt::Debug> fmt::Debug for SizedDebug<'_, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match &self.0.kind {
            Kind::Unit => f.write_str("Unit"),
            Kind::Bit => f.write_str("Bit"),
            Kind::Bits(n) => f.debug_tuple("Bits").field(n).finish(),
            Kind::Parameter(parameter) => f.debug_tuple("Basis").field(&parameter.name).finish(),
            Kind::Q(inner) => f.debug_tuple("Q").field(&inner.sized_debug()).finish(),
            Kind::Tuple(fields) => {
                struct Fields<'a, N>(&'a [Type<N>]);
                impl<N: fmt::Debug> fmt::Debug for Fields<'_, N> {
                    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                        f.debug_list()
                            .entries(self.0.iter().map(Type::sized_debug))
                            .finish()
                    }
                }
                f.debug_tuple("Tuple").field(&Fields(fields)).finish()
            }
        }
    }
}

impl Type<u32> {
    /// Checked physical width of an ordinary finite basis tree. Q is not a
    /// basis constructor; callers must explicitly select an owner's basis.
    pub(super) fn basis_width(&self) -> Option<u32> {
        let mut total = 0u32;
        let mut pending = vec![self];
        while let Some(ty) = pending.pop() {
            match &ty.kind {
                Kind::Unit => {}
                Kind::Bit => total = total.checked_add(1)?,
                Kind::Bits(n) => total = total.checked_add(*n)?,
                Kind::Tuple(fields) => pending.extend(fields.iter().rev()),
                Kind::Q(_) | Kind::Parameter(_) => return None,
            }
        }
        Some(total)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    type T = Type<u32>;

    #[test]
    fn equal_width_does_not_identify_type_or_owner_trees() {
        for (a, b) in [
            (T::bit(), T::bits(1)),
            (T::unit(), T::bits(0)),
            (T::unit(), T::tuple(vec![])),
            (T::pair(T::unit(), T::bit()), T::pair(T::bit(), T::unit())),
            (
                T::pair(T::pair(T::bit(), T::bit()), T::bit()),
                T::pair(T::bit(), T::pair(T::bit(), T::bit())),
            ),
            (
                T::tuple(vec![T::bit(), T::bit(), T::bit()]),
                T::pair(T::pair(T::bit(), T::bit()), T::bit()),
            ),
            (
                T::quantum(T::pair(T::bit(), T::bit())),
                T::pair(T::quantum(T::bit()), T::quantum(T::bit())),
            ),
            (T::bit(), T::quantum(T::bit())),
        ] {
            assert_eq!(a, a.clone());
            assert_ne!(a, b);
            assert_ne!(b, a);
        }
    }

    #[test]
    fn linearity_retains_zero_width_owners_inside_mixed_products() {
        for owner in [T::quantum(T::unit()), T::quantum(T::bits(0))] {
            assert!(owner.linear());
            assert!(owner.quantum_group());
            assert!(T::pair(T::bit(), owner.clone()).linear());
            assert!(!T::pair(T::bit(), owner).quantum_group());
        }
        assert!(!T::tuple(vec![]).quantum_group());
        assert!(!T::pair(T::unit(), T::bits(0)).linear());
    }

    #[test]
    fn size_obligations_keep_order_and_errors_after_a_sibling_mismatch() {
        let a = T::tuple(vec![T::bit(), T::bits(3), T::quantum(T::bits(7))]);
        let b = T::tuple(vec![T::unit(), T::bits(4), T::quantum(T::bits(8))]);
        let mut visited = Vec::new();
        let result = a.equivalent_by(&b, &mut |a, b| {
            visited.push((*a, *b));
            if *a == 7 {
                Err("bounded size solver failed")
            } else {
                Ok(false)
            }
        });
        assert_eq!(result, Err("bounded size solver failed"));
        assert_eq!(visited, [(3, 4), (7, 8)]);
        // A mismatched constructor must never ask width arithmetic to equate it.
        assert!(
            !T::bit()
                .equivalent_by(&T::bits(1), &mut |_, _| -> Result<bool, ()> {
                    panic!("constructor mismatch must not invoke the size solver")
                })
                .unwrap()
        );
    }

    #[test]
    fn size_solver_cannot_equate_different_tuple_or_quantum_shapes() {
        let a = T::quantum(T::bits(7));
        let b = T::quantum(T::bits(8));
        let same_size = &mut |_: &u32, _: &u32| Ok::<_, ()>(true);
        assert!(a.equivalent_by(&b, same_size).unwrap());
        assert!(!a.equivalent_by(&T::bits(7), same_size).unwrap());
        assert!(
            !T::pair(a, b.clone())
                .equivalent_by(&T::tuple(vec![b]), same_size)
                .unwrap()
        );
    }
}
