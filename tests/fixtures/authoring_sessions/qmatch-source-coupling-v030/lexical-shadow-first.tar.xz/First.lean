import QleisliKernel.SourceTypes.QuantumSequence
import QleisliKernel.SourceTypes.QuantumArms
namespace ArmShadowFirst
open QleisliKernel QleisliKernel.SourceTypes

def consumed_local : String := "unitary fn turn(q:Q<Bit>)->Q<Bit>{q}\npub unitary fn route(turn:Q<Bit>,s:Q<Bit>)->(Q<Bit>,Q<Bit>){\n  let q=turn;\n  qmatch(s,q){0=>turn,1=>turn}\n}\n"
def qualified_control : String := "unitary fn turn(q:Q<Bit>)->Q<Bit>{q}\npub unitary fn route(turn:Q<Bit>,s:Q<Bit>)->(Q<Bit>,Q<Bit>){\n  let q=turn;\n  qmatch(s,q){0=>main::turn,1=>main::turn}\n}\n"
def unshadowed_control : String := "unitary fn turn(q:Q<Bit>)->Q<Bit>{q}\npub unitary fn route(input:Q<Bit>,s:Q<Bit>)->(Q<Bit>,Q<Bit>){\n  let q=input;\n  qmatch(s,q){0=>turn,1=>turn}\n}\n"

def offset (source : String) : Nat :=
  (((lexLocated source).toOption.getD []).find? (·.text == "qmatch")).map (·.span.startByte) |>.getD 0

def sequence (source : String) : Bool :=
  ((QuantumSequence.read #[("main",source)] "main" "route").run 10000000).1.isOk

def armTargets (source : String) : Option (List (String × String)) :=
  ((QuantumArms.read #[("main",source)] "main" "route" (offset source) [.bit] [.bit]).run 10000000).1.toOption.map fun table =>
    table.arms.map fun arm => (arm.operation.resolution.moduleName,arm.operation.resolution.declaration.name)

#guard sequence consumed_local
#guard armTargets consumed_local = some [("main","turn"),("main","turn")]
#eval (sequence consumed_local,armTargets consumed_local)
#guard sequence qualified_control
#guard armTargets qualified_control = some [("main","turn"),("main","turn")]
#eval (sequence qualified_control,armTargets qualified_control)
#guard sequence unshadowed_control
#guard armTargets unshadowed_control = some [("main","turn"),("main","turn")]
#eval (sequence unshadowed_control,armTargets unshadowed_control)

#print axioms QleisliKernel.SourceTypes.QuantumArms.readArm
end ArmShadowFirst
