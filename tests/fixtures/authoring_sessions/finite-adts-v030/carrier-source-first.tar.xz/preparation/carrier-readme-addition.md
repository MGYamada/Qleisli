<!-- PROPOSAL ONLY. Append after independently validating the new archive;
replace the four @...@ values from its actual index/archive/validation. -->

The [carrier source history](carrier-source-first.tar.xz),
[index](carrier-source-index.json) and [retention record](carrier-source-validation.json)
retain @RECORDS@ inert records / @EXPANDED_BYTES@ expanded bytes /
@ARCHIVE_BYTES@ stored archive bytes. The original first `.qli` projects,
source snapshots, actual diagnostics and scripts remain unchanged. Repeated
repository inventories are represented by their exact canonical counts and
hashes; each compact observation retains the full local report's byte count
and SHA-256. Those full reports and omitted duplicate inventories remain
outside the repository without deletion. Source snapshots are deduplicated by
complete bytes and hash, with each original record mapped to its object.

The first direct nominal programs retain their transport refusals, and the
explicit `type(Tri)` experiment retains its original missing-static-binder
diagnostic. Later common planning preserves the original lexical type use,
canonical nominal identity and declaration-rooted field sizes. The new bounded
check-only carrier route checks independently supplied logical equations and
native source rows before replaying retained source steps. It supplies no
ordinary executable accepted program or source-preservation theorem. Public
effects, exact body/port bindings, owner rules and existing unsupported gates
remain explicit.

The interrupted normal Rust observer remains failed. Its actually successful
prefix and a separate successful completion cover the normal plan on the same
Root, companion and checker bytes; sequential MSRV 1.85 completes its own full
plan on that state. Each records 363 frontend, 33 integration and 23 native
tests, seven actual CLI cases and 176 companion tests, with zero ignored or
conditional native skips. Normal strict lint and format checks pass. These
reports precede the later Lean-only integration and are retained with their
own source windows; they are not silently relabelled as checks of later bytes.

The 13 new source-row checker propositions pass in their isolated observation
and are integrated under a separate namespace. The prior failed full-suite
proof/reduction/resource attempts remain failed; the source-only serial split
candidate and guarded evidence-refresh plans remain unexecuted candidates.
The original census of 475 simple-colon examples remains unchanged beside the
separate correction to 476 total examples. Four canonical registry attempts
stop at the 2 GiB owned-process-group RSS ceiling without completing the
canonical audit. The six protected comparisons also have a failed aggregate:
five stop at that ceiling, while the separate fresh `Main` replay exits zero
with identical empty output streams. No full 476-example success, successful
canonical registry run or protected evidence refresh is claimed here.

The actual workspace `bin/qargo`, `bin/qlippy`, `bin/qlifmt` and `bin/qlidoc`
pass the unchanged live companion runtime verifier with the intended
Qleisli/std sources. Binary bytes, sizes and modes, the checker, companion
sources and four preexisting dirty files stay unchanged. The observer peaks
at 90,352 KiB and invokes no Cargo or Rustdoc. This is a developer runtime
observation, not a binary/source attestation or release authorization.

The deferred Carrier header candidate, its restored-original metadata, the
13-proposition namespace integration record and prepared refresh plans are
retained as inert bytes. Fixed passive tests verify original failures, source
object/report identities, distinct Rust windows, failed proof boundaries and
the staged runtime snapshots without executing archived code. Packaging and
passive-reader results must be recorded separately after they actually run.
No maximum quantum case is added. All 8 #64 criteria, ordinary nominal
execution, match/qmatch, source-function preservation, hosted CI/review and
the broader constitutional obligations remain open. No #39/#63 expansion,
new guarantee, publication or release follows from this history.
