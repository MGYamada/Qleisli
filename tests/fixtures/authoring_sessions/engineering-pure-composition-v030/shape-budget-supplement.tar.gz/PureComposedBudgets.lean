import PureComposedKernel
import PureComposedExamplesV1

/-! TP-31-PURE-COMPOSED-SHAPES-02, P1: supplemental bounded budget study.
Replace after reviewed composed-protocol integration; preserve before removal.
All roots are manual original QIRF, not emitted source or target preservation.
These tests create only internal engineering data, even for epsilon zero; they
supply no accepted handle, capability, cleanup or quantitative resource claim.
The square-capacity restrictions are checked before composed epsilon addition.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace PureComposedBudgets
open QleisliKernel QleisliKernel.Semantics.Exact QleisliKernel.Semantics.Finite
open QleisliKernel.Semantics.Observation QleisliKernel.Qirf.EngineeringPure
open QleisliKernel.Qirf.EngineeringPureComposed PureComposedExamples

/-- Independent literal two-axis diagonal: both low and high bits acquire T. -/
def doubleTMatrix : Matrix :=
  ⟨4,4,(List.range 16).map fun k =>
    if k / 4 = k % 4 then Exact.Scalar.phase (bit (k / 4) 0 + bit (k / 4) 1)
    else Scalar.zero⟩

def twoNonzero : Qirf.EngineeringPureComposed.Request :=
  ⟨compareLeft,compareLeft,parentActual,
    leaf pairBasis (phaseSteps 0 1 ++ phaseSteps 1 1) doubleTMatrix⟩

/-- The unchanged original identity roots isolate actual budget arithmetic. -/
def identityBudgets (left right : Coefficient) : Qirf.EngineeringPureComposed.Request :=
  ⟨{compareRight with epsilon := left},{compareRight with epsilon := right},
    parentActual,parentActual⟩

def budgetResult (request : Qirf.EngineeringPureComposed.Request)
    (work : Nat := 2000000) : Except Finite.Error (Coefficient × Nat) :=
  match (Qirf.EngineeringPureComposed.check request).run work with
  | (.ok checked,left) => .ok (checked.epsilon,left)
  | (.error error,_) => .error error

def errorIs {α : Type} (result : Except Finite.Error α) (expected : Finite.Error) : Bool :=
  match result with | .error error => error == expected | .ok _ => false

def maximumSquareNumerator : Int := 13043817825332782212

def largestAligned : Qirf.EngineeringPureComposed.Request :=
  identityBudgets ⟨maximumSquareNumerator,0⟩ ⟨maximumSquareNumerator - 1,63⟩

def budgetCases : List (String × Except Finite.Error (Coefficient × Nat)) :=
  [("two genuine I/T gaps: 7/8 + 7/8 = 7/4",budgetResult twoNonzero),
   ("canonical normalization: 1/2 + 1/2 = 1",budgetResult (identityBudgets ⟨1,1⟩ ⟨1,1⟩)),
   ("mixed exponents: 3/8 + 1/2 = 7/8",budgetResult (identityBudgets ⟨3,3⟩ ⟨1,1⟩)),
   ("boundary alignment: 2^63 + 1/2^63",budgetResult (identityBudgets ⟨2^63,0⟩ ⟨1,63⟩)),
   ("largest successful square numerator, exponent gap63",budgetResult largestAligned),
   ("square numerator above maximum refuses in left component",budgetResult
     (identityBudgets ⟨maximumSquareNumerator + 1,0⟩ ⟨0,0⟩)),
   ("square exponent128 refuses in component",budgetResult (identityBudgets ⟨1,64⟩ ⟨0,0⟩)),
   ("noncanonical nonzero epsilon refuses",budgetResult (identityBudgets ⟨2,2⟩ ⟨1,1⟩)),
   ("noncanonical zero epsilon refuses",budgetResult (identityBudgets ⟨0,1⟩ ⟨0,0⟩)),
   ("negative epsilon refuses",budgetResult (identityBudgets ⟨-1,1⟩ ⟨0,0⟩)),
   ("epsilon beyond admitted exponent126 refuses",budgetResult (identityBudgets ⟨1,127⟩ ⟨0,0⟩))]

#eval budgetCases
#eval ("direct add only: valid operands with numerator sum overflow",
  Exact.Coefficient.valid (⟨2^126,0⟩ : Coefficient),
  Exact.Coefficient.add ⟨2^126,0⟩ ⟨2^126,0⟩)
#eval ("direct add only: valid operands with exponent alignment overflow",
  Exact.Coefficient.valid (⟨1,126⟩ : Coefficient),
  Exact.Coefficient.add ⟨2,0⟩ ⟨1,126⟩)
#eval ("left component square capacity refusal is before composed addition",
  runLeaf {compareRight with epsilon := ⟨maximumSquareNumerator + 1,0⟩},
  runLeaf {compareRight with epsilon := ⟨1,64⟩})

/-- The actual original two-gap parent uses the exact normalized summed budget. -/
theorem two_nonzero_budget :
    (budgetResult twoNonzero).toOption.map Prod.fst = some ⟨7,2⟩ := by decide +kernel

theorem normalized_halves_budget :
    (budgetResult (identityBudgets ⟨1,1⟩ ⟨1,1⟩)).toOption.map Prod.fst = some ⟨1,0⟩ := by decide +kernel

theorem mixed_exponent_budget :
    (budgetResult (identityBudgets ⟨3,3⟩ ⟨1,1⟩)).toOption.map Prod.fst = some ⟨7,3⟩ := by decide +kernel

theorem largest_alignment_budget :
    (budgetResult largestAligned).toOption.map Prod.fst =
      some ⟨maximumSquareNumerator * 2^63 + maximumSquareNumerator - 1,63⟩ := by decide +kernel

theorem noncanonical_refusal :
    errorIs (budgetResult (identityBudgets ⟨2,2⟩ ⟨1,1⟩)) .invalid = true := by decide +kernel

theorem component_numerator_capacity_refusal :
    errorIs (budgetResult (identityBudgets ⟨maximumSquareNumerator + 1,0⟩ ⟨0,0⟩))
      (.arithmetic .arithmeticCapacity) = true := by decide +kernel

theorem component_exponent_capacity_refusal :
    errorIs (budgetResult (identityBudgets ⟨1,64⟩ ⟨0,0⟩)) (.arithmetic .arithmeticCapacity) = true := by decide +kernel

theorem direct_add_overflow :
    (match Exact.Coefficient.add ⟨2^126,0⟩ ⟨2^126,0⟩ with
      | .error .arithmeticCapacity => true | _ => false) = true := by decide +kernel

/-- Coarse numerical bound used in the separate reachability analysis. -/
theorem coarse_addition_numerator_bound :
    ((3 * 2^62 - 1) * (2^63 + 1) : Int) < 2^127 := by decide +kernel

end PureComposedBudgets
