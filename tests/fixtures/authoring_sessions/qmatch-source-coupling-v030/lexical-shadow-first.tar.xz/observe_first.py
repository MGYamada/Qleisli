"""Preserve one fresh Rust/Lean source-component comparison; no production edits."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import time

base = Path(__file__).parent
repo = Path('/private/tmp/qleisli-ordinary-closed-fix')
compiler = Path('/Users/masa/git/Qleisli/target/debug/qleisli')
kernel = repo / 'lean-kernel/.lake/build/bin/qleisli-kernel'
out = base / 'observations-first'
out.mkdir(exist_ok=False)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    inputs = sorted(base.glob('*/main.qli')) + sorted(base.glob('*/Qargo.toml'))
    inputs += [base / 'First.lean', base / 'plan.json', Path(__file__)]
    production = [repo / p for p in [
        'src/frontend/check/body/special.rs', 'src/frontend/check/body.rs',
        'src/frontend/check/body/quantum_matching.rs', 'src/frontend/resolve/locals.rs',
        'lean-kernel/QleisliKernel/SourceTypes/QuantumArms.lean',
        'lean-kernel/QleisliKernel/SourceTypes/QuantumSequence.lean',
        'lean-kernel/.lake/build/lib/lean/QleisliKernel/SourceTypes/QuantumArms.olean',
        'lean-kernel/.lake/build/lib/lean/QleisliKernel/SourceTypes/QuantumSequence.olean']]
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
            'inputs': {str(p.relative_to(base)): digest(p) for p in inputs},
            'production': {str(p.relative_to(repo)): digest(p) for p in production},
            'compiler_sha256': digest(compiler), 'kernel_sha256': digest(kernel)}

before = snapshot()
(out / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
commands = []
for case in ['consumed-local', 'qualified-control', 'unshadowed-control']:
    commands.append((case, [str(compiler), 'check', '--entry=main::route',
        '--module=main=' + str(base / case / 'main.qli'), '--ir-profile=raw',
        '--lean-kernel=' + str(kernel), '--format=json'], repo))
commands.append(('lean-components',
    ['/Users/masa/.elan/toolchains/leanprover--lean4---v4.30.0/bin/lake', 'env', 'lean',
     '-DwarningAsError=true', str(base / 'First.lean')], repo / 'lean-kernel'))
results = []
for label, argv, cwd in commands:
    started = time.monotonic()
    with (out / (label + '.stdout')).open('xb') as stdout, (out / (label + '.stderr')).open('xb') as stderr:
        run = subprocess.run(argv, cwd=cwd, env={**os.environ, 'LEAN_NUM_THREADS': '1'},
                             stdout=stdout, stderr=stderr, timeout=120)
    item = dict(label=label, argv=argv, cwd=str(cwd), exit_code=run.returncode,
                seconds=time.monotonic()-started,
                stdout_sha256=digest(out / (label + '.stdout')),
                stderr_sha256=digest(out / (label + '.stderr')))
    results.append(item)
after = snapshot()
report = dict(before=before, after=after, stable=before == after, commands=results,
              child_peak_rss_bytes=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
              scope='Actual existing CLI observations and current Lean source components only. '
                    'No fresh Rust build, full native adversarial packet, or binary-source theorem claimed.')
(out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'stable': report['stable'], 'peak': report['child_peak_rss_bytes'],
                  'commands': [{'label': r['label'], 'exit_code': r['exit_code'], 'seconds': r['seconds']}
                               for r in results]}, indent=2))
for label, _, _ in commands:
    print(label + ': ' + (out / (label + '.stdout')).read_text()[:3000])
    error = (out / (label + '.stderr')).read_text()
    if error: print(error[:1500])
