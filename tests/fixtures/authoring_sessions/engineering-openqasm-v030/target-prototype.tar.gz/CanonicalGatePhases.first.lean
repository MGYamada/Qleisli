import CanonicalTarget

/-! Exact one-qubit standard-gate matrices, before terminal observation.
TEMP TP-31-TARGET-QASM-01 (P1). Mathematical standard-library meanings are
an explicit specification assumption, not an include-loader/hardware claim.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace CanonicalGatePhases
open QleisliKernel QleisliKernel.Semantics.Exact CanonicalTarget
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000

def gates : List CanonicalTarget.Gate := [.h,.x,.y,.z,.s,.sdg,.t,.tdg]

def expected : CanonicalTarget.Gate → Matrix
  | .h =>
    let rootHalf : Scalar := ⟨⟨0,0⟩,⟨1,1⟩,⟨0,0⟩,⟨0,0⟩⟩
    let negativeRootHalf : Scalar := ⟨⟨0,0⟩,⟨-1,1⟩,⟨0,0⟩,⟨0,0⟩⟩
    ⟨2,2,[rootHalf,rootHalf,rootHalf,negativeRootHalf]⟩
  | .x => ⟨2,2,[Scalar.zero,Scalar.one,Scalar.one,Scalar.zero]⟩
  | .y => ⟨2,2,[Scalar.zero,Exact.Scalar.phase 6,Exact.Scalar.phase 2,Scalar.zero]⟩
  | .z => ⟨2,2,[Scalar.one,Scalar.zero,Scalar.zero,Exact.Scalar.phase 4]⟩
  | .s => ⟨2,2,[Scalar.one,Scalar.zero,Scalar.zero,Exact.Scalar.phase 2]⟩
  | .sdg => ⟨2,2,[Scalar.one,Scalar.zero,Scalar.zero,Exact.Scalar.phase 6]⟩
  | .t => ⟨2,2,[Scalar.one,Scalar.zero,Scalar.zero,Exact.Scalar.phase 1]⟩
  | .tdg => ⟨2,2,[Scalar.one,Scalar.zero,Scalar.zero,Exact.Scalar.phase 7]⟩

def original (g : CanonicalTarget.Gate) : Semantics.Observation.Program :=
  ⟨[⟨0,[0],1⟩],[],[gateOp g 0 1],[1],[],.unitary⟩

def reconstructed (g : CanonicalTarget.Gate) : Except Finite.Error Matrix :=
  ((Raw.BranchFunction.reconstruct [] (original g)).run 2000000).1

def matches (g : CanonicalTarget.Gate) : Bool :=
  match reconstructed g with
  | .error _ => false
  | .ok actual => actual == expected g

#eval gates.map (fun g => (reprStr g,matches g,reprStr (reconstructed g)))

theorem all_gate_matrices : gates.all matches = true := by decide +kernel

/-- Negating Y has the same standalone CP map but the wrong exact phase.
This literal comparison is made before the observing-instrument metric. -/
def wrongGlobalY : Matrix :=
  ⟨2,2,[Scalar.zero,Exact.Scalar.phase 2,Exact.Scalar.phase 6,Scalar.zero]⟩

theorem wrong_y_phase_refused :
    ((reconstructed .y).map (fun matrix => matrix == wrongGlobalY)).toOption = some false := by decide +kernel

theorem wrong_s_direction_refused :
    ((reconstructed .s).map (fun matrix => matrix == expected .sdg)).toOption = some false := by decide +kernel

theorem wrong_t_direction_refused :
    ((reconstructed .t).map (fun matrix => matrix == expected .tdg)).toOption = some false := by decide +kernel

end CanonicalGatePhases
