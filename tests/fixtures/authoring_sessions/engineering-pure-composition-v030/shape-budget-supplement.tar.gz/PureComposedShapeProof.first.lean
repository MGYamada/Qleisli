import PureComposedMath
import PureComposedShapes

/-! TP-31-PURE-COMPOSED-SHAPES-02, P1: reuse the frozen general refinement on
actual rectangular and zero-width executions. Replace after reviewed production
integration; retain first source and diagnostics. No source/target preservation,
accepted handle, controlled access, cleanup or target resource authority.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace Qleisli.EngineeringPureComposed.ShapeChecks
open QleisliKernel.Qirf.EngineeringPureComposed
open Qleisli.EngineeringPureComposition
open PureComposedShapes

/-- A kernel-decided success supplies the actual successful execution used by
the frozen original-body refinement, rather than an unrelated predicate. -/
theorem original_meaning (request : Request) (work : Nat)
    (accepted : ((check request).run work).1.isOk = true) :
    ∃ checked remaining, (check request).run work = (.ok checked,remaining) ∧
      Qleisli.EngineeringPureComposed.Meaning request checked := by
  cases execution : (check request).run work with
  | mk result remaining =>
    cases result with
    | error error =>
      rw [execution] at accepted
      change false = true at accepted
      cases accepted
    | ok checked =>
      exact ⟨checked,remaining,rfl,Qleisli.EngineeringPureComposed.check_meaning _ _ _ _ execution⟩

noncomputable def parentGap {R : Type} [Fintype R] (request : Request) :=
  operator (liftLeft (R := R)
    (matrixAt request.parentActual.required.rows request.parentActual.required.cols request.parentActual.required -
      matrixAt request.parentActual.required.rows request.parentActual.required.cols request.parentIdeal.required))

/-- Exact summed-budget data are independently checked, and the literal parent
operator acts on arbitrary finite external references. -/
theorem reference_bound {R : Type} [Fintype R] (request : Request) (work : Nat)
    (epsilon : QleisliKernel.Semantics.Exact.Coefficient)
    (accepted : ((check request).run work).1.isOk = true)
    (addition : QleisliKernel.Exact.Coefficient.add request.left.epsilon request.right.epsilon = .ok epsilon) :
    ‖parentGap (R := R) request‖ ≤ (Qleisli.Semantics.Exact.rational epsilon : ℝ) := by
  obtain ⟨checked,remaining,execution,_⟩ := original_meaning request work accepted
  have facts := check_postcondition _ _ _ _ execution
  have same : checked.epsilon = epsilon := Except.ok.inj (facts.epsilonAdd.symm.trans addition)
  have bound := Qleisli.EngineeringPureComposed.checked_reference_bound (R := R) _ _ _ _ execution
  rw [same] at bound
  exact bound

theorem asymmetric_reference {R : Type} [Fintype R] :
    ‖parentGap (R := R) asymmetric‖ ≤ (7/8 : ℝ) := by
  have bound := reference_bound (R := R) asymmetric 2000000 ⟨7,3⟩ asymmetric_accepts (by decide +kernel)
  have budget : (Qleisli.Semantics.Exact.rational (⟨7,3⟩ : QleisliKernel.Semantics.Exact.Coefficient) : ℝ) =
      (7/8 : ℝ) := by norm_num [Qleisli.Semantics.Exact.rational]
  simpa only [budget] using bound

theorem asymmetric_two_reference {R : Type} [Fintype R] :
    ‖parentGap (R := R) asymmetricTwoBudgets‖ ≤ (7/4 : ℝ) := by
  have bound := reference_bound (R := R) asymmetricTwoBudgets 2000000 ⟨7,2⟩ asymmetric_two_budgets_accepts (by decide +kernel)
  have budget : (Qleisli.Semantics.Exact.rational (⟨7,2⟩ : QleisliKernel.Semantics.Exact.Coefficient) : ℝ) =
      (7/4 : ℝ) := by norm_num [Qleisli.Semantics.Exact.rational]
  simpa only [budget] using bound

theorem asymmetric_reverse_reference {R : Type} [Fintype R] :
    ‖parentGap (R := R) asymmetricReverse‖ ≤ (7/4 : ℝ) := by
  have bound := reference_bound (R := R) asymmetricReverse 2000000 ⟨7,2⟩ asymmetric_reverse_accepts (by decide +kernel)
  have budget : (Qleisli.Semantics.Exact.rational (⟨7,2⟩ : QleisliKernel.Semantics.Exact.Coefficient) : ℝ) =
      (7/4 : ℝ) := by norm_num [Qleisli.Semantics.Exact.rational]
  simpa only [budget] using bound

theorem zero_pair_reference {R : Type} [Fintype R] :
    ‖parentGap (R := R) zeroPair‖ ≤ (7/4 : ℝ) := by
  have bound := reference_bound (R := R) zeroPair 2000000 ⟨7,2⟩ zero_pair_accepts (by decide +kernel)
  have budget : (Qleisli.Semantics.Exact.rational (⟨7,2⟩ : QleisliKernel.Semantics.Exact.Coefficient) : ℝ) =
      (7/4 : ℝ) := by norm_num [Qleisli.Semantics.Exact.rational]
  simpa only [budget] using bound

theorem exact_zero_pair_reference {R : Type} [Fintype R] :
    ‖parentGap (R := R) exactZeroPair‖ ≤ (0 : ℝ) := by
  have bound := reference_bound (R := R) exactZeroPair 2000000 ⟨0,0⟩ exact_zero_pair_accepts (by decide +kernel)
  have budget : (Qleisli.Semantics.Exact.rational (⟨0,0⟩ : QleisliKernel.Semantics.Exact.Coefficient) : ℝ) =
      (0 : ℝ) := by norm_num [Qleisli.Semantics.Exact.rational]
  simpa only [budget] using bound

end Qleisli.EngineeringPureComposed.ShapeChecks
