#!/usr/bin/env python3
"""Fresh, reviewed fourteen-command capture. Never runs historical commands."""
import hashlib, json, os, stat, subprocess, time
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path("/Users/masa/git/Qleisli")
PACKET = Path("/private/tmp/qleisli-generic-dormant-first-wvsss6jb")
OUT = Path(__file__).resolve().parent
CLI = Path("/private/tmp/qleisli-empty-basis-validation-F4CYs1Kt/normal-qleisli")
KERNEL = ROOT / "lean-kernel/.lake/build/bin/qleisli-kernel"
EXPECTED = {
 str(CLI): "d6d285819917aa3d1167c3efc73d7f81ec684b5ee89ce7ed37c8660997070e64",
 str(KERNEL): "54c9d60b80f67217abd95c8fe6ec1c06aa262e142d5e6db30f46a20cb90faf07",
 str(PACKET / "plan.json"): "dc964bb285afb103e175d950b3e9d34376881f738b91be50ec5b233c022ae518",
 str(PACKET / "freeze.json"): "d9a76a5c4a3951485f9f5c687172395c9d2b230fd20ecab243048400d088690a",
}
def sha(data): return hashlib.sha256(data).hexdigest()
def save(path, value):
 path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
def git(*args):
 return subprocess.check_output(["git", *args], cwd=ROOT)
def record(path):
 s = path.lstat()
 if not stat.S_ISREG(s.st_mode): raise RuntimeError(f"nonregular input: {path}")
 b = path.read_bytes()
 return {"sha256":sha(b),"bytes":len(b),"mode":stat.S_IMODE(s.st_mode)}
def inventory():
 # Re-read every actual tracked input and every frozen packet input each window.
 files = {}
 for raw in git("ls-files","-z").split(b"\0"):
  if raw:
   name = os.fsdecode(raw)
   files["repository/" + name] = record(ROOT / name)
 for p in sorted(PACKET.rglob("*")):
  if p.is_file(): files["first/" + str(p.relative_to(PACKET))] = record(p)
 for name in EXPECTED:
  if not name.startswith(str(PACKET)):
   files["executable/" + name] = record(Path(name))
 for name, expected in EXPECTED.items():
  if sha(Path(name).read_bytes()) != expected: raise RuntimeError(f"changed pinned input: {name}")
 raw = json.dumps(files, sort_keys=True, separators=(",",":")).encode()
 digest = sha(raw)
 dest = OUT / ("inputs-" + digest + ".json")
 if not dest.exists(): dest.write_bytes(raw + b"\n")
 return {"utc":datetime.now(timezone.utc).isoformat(),"sha256":digest,
         "inventory":dest.name,"files":len(files),"head":git("rev-parse","HEAD").decode().strip(),
         "tree":git("rev-parse","HEAD^{tree}").decode().strip(),
         "status":git("status","--porcelain=v1").decode()}
plan = json.loads((PACKET / "plan.json").read_text())
assert plan["planned_checks"] == len(plan["commands"]) == 14
assert plan["planned_runs"] == plan["planned_emissions"] == 0
assert not (OUT / "started.json").exists(), "capture cannot be repeated"
initial = inventory()
assert initial["status"] == "", initial
save(OUT / "started.json", {"utc":datetime.now(timezone.utc).isoformat(),
 "driver":record(Path(__file__)),"plan":EXPECTED[str(PACKET / "plan.json")],
 "initial":initial,
 "cli_provenance":"Prior runtime build copy; current observed HEAD is not a clean build attestation.",
 "scope":"Fourteen fresh literal checks only; no repairs/retries/fallbacks/runs/emissions."})
rows = []
for number, item in enumerate(plan["commands"]):
 argv = item["argv"]
 assert argv[:3] == [str(CLI),"--format=json","check"]
 assert argv[-1] == "--lean-kernel=" + str(KERNEL)
 assert item["cwd"] == str(ROOT)
 before = inventory()
 if before["sha256"] != initial["sha256"]: raise RuntimeError("inputs changed before command")
 start = time.monotonic()
 timeout = False
 try:
  child = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
  stdout, stderr, exit_code = child.stdout, child.stderr, child.returncode
 except subprocess.TimeoutExpired as exc:
  stdout, stderr, exit_code, timeout = exc.stdout or b"", exc.stderr or b"", None, True
 (OUT / f"{number:02}.stdout").write_bytes(stdout)
 (OUT / f"{number:02}.stderr").write_bytes(stderr)
 after = inventory()
 decoded = None
 try: decoded = json.loads(stdout)
 except (ValueError, UnicodeError): pass
 codes = [d.get("code") for d in decoded.get("diagnostics",[])] if isinstance(decoded,dict) else []
 row = {"number":number,"id":item["id"],"argv":argv,"cwd":str(ROOT),
 "exit_code":exit_code,"timeout":timeout,"seconds":time.monotonic()-start,
 "stdout":record(OUT / f"{number:02}.stdout"),"stderr":record(OUT / f"{number:02}.stderr"),
 "diagnostic_codes":codes,"prediction":item["prediction"],"before":before,"after":after,
 "source_window_stable":before["sha256"]==after["sha256"]}
 rows.append(row)
 save(OUT / f"{number:02}.json",row)
 save(OUT / "observations.json",rows)
 print(json.dumps({"number":number,"id":item["id"],"exit":exit_code,
                   "codes":codes,"stable":row["source_window_stable"]}), flush=True)
 if after["sha256"] != initial["sha256"]: raise RuntimeError("input changed; no further command")
 if timeout: raise RuntimeError("timeout preserved; no retry")
save(OUT / "summary.json", {"complete":len(rows)==14,"observations":len(rows),
 "accepted":sum(r["exit_code"]==0 for r in rows),
 "refused":sum(r["exit_code"]!=0 for r in rows),
 "all_windows_stable":all(r["source_window_stable"] for r in rows),
 "initial":initial,"final":inventory(),
 "claim_limit":"Observed source checking/native selected scope only; no source Meaning/preservation, target/resource or guarantee discharge."})

