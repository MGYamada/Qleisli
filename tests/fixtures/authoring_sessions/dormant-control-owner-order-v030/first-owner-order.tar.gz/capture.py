import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/Users/masa/git/Qleisli')
work = Path(__file__).parent
out = work / 'controls-mixed-owner-baseline'
out.mkdir()
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
cli = root / 'target/debug/qleisli'
kernel = root / 'lean-kernel/.lake/build/bin/qleisli-kernel'
ids = {str(p): sha(p) for p in [cli, kernel]}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
driver = out / 'capture.py'
driver.write_bytes(Path(__file__).read_bytes())
plan = {'kind': 'informed one-bit whole-owner study', 'before_control_cli': True,
        'predictions': {'empty_ctrl': 'accept; exact zero-width owner remains present',
                        'bit_ctrl': 'must refuse; X changes the sole physical Ctrl axis'},
        'limits': 'one physical qubit; no maximum-size case; no run/sampling',
        'cli_build_attestation': False,
        'provenance': 'Existing separately identified CLI; observed Git HEAD is not a binary build attestation. Concurrent checkout integration may change Git/source state.',
        'head_before': head, 'executables_before': ids,
        'driver_sha256': sha(driver)}
(out / 'plan.json').write_text(json.dumps(plan, indent=2)+'\n')
results = []
for case, original in [('empty_ctrl', 'controls-mixed-owner-first.qli'),
                       ('bit_ctrl', 'controls-mixed-owner-counterexample-first.qli')]:
    project = out / case
    project.mkdir()
    source = work / original
    (project / 'main.qli').write_bytes(source.read_bytes())
    (project / 'Qargo.toml').write_text('schema-version = 2\n\n[qrate]\nedition = "2026"\n')
    argv = [str(cli), 'check', str(project), '--lean-kernel='+str(kernel)]
    p = subprocess.run(argv, cwd=root, capture_output=True)
    (out / (case+'.stdout.txt')).write_bytes(p.stdout)
    (out / (case+'.stderr.txt')).write_bytes(p.stderr)
    results.append({'case': case, 'argv': argv, 'exit_code': p.returncode,
                    'source_sha256': sha(project/'main.qli'),
                    'stdout_sha256': sha(out/(case+'.stdout.txt')),
                    'stderr_sha256': sha(out/(case+'.stderr.txt'))})
after = {str(p): sha(p) for p in [cli,kernel]}
result = {'observations': results, 'head_after': subprocess.check_output(
          ['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
          'executables_after': after, 'executables_stable': ids==after}
(out / 'observations.json').write_text(json.dumps(result,indent=2)+'\n')
assert ids == after, 'executable changed during first observations'
print(json.dumps(result,indent=2))
