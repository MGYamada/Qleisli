# Informed stdlib exact follow-up v2: real first observations

16 cases; 38 fresh manual invocations. No retries/fallback. All original packets, previous observations, runtime source closure, HEAD, immutable CLI and explicit kernel stayed byte-stable before/after every invocation.

The v2 packet contains an authoring defect: common/ has no schema-2 Qargo.toml. Ten cases using derived-current.qli or generic-cp-current.qli fail edition/project validation at emission and separate source checking. No verification command was run without its required artifact. No positive exact T/CP conclusion follows.

Six artifacts were emitted and their separate source checks accepted. Independent preauthored artifact-only exact native requests accepted structural-permute-packed and physical-swap-packed, and refused t-wrong-global, t-erased-phase, cp-wrong-whole-scalar and swap-wrong-identity. The generic native refusal message does not expose a finer equation diagnostic.

Actual structural artifact contains split+join and output wire map [1,0]. Actual physical SWAP contains split+3 cnot+join and output wire map [0,1]. Both have the exact requested SWAP action, with different emitted wire operations. These are descriptions of these actual artifacts, not certified target synthesis/resource bounds.

The derived T/CP artifacts never emitted, so no explicit Unit pack/unpack/extra-wire evidence or controlled/reference positive equation was obtained. Accepted source-step JSON reports native-validity, source_steps_checked=true, source_meaning_verified=false and source_preservation_verified=false. verify-ir accepts the two artifact equations with request_checked=true, source_preservation_verified=false. CLI/kernel byte hashes are externally pinned; native JSON checker_identity says unpinned.

No source-to-IR preservation, arbitrary-reference theorem, hardware, PR/RS, EXACT guarantee or general compiler/resource proof is claimed. All authored programs are at most two qubits. The unchanged bundled QFT3 allowance was not needed for these selected-only invocations.

See all-observations.json, structured-results.json, artifact-inspections.json, context-before.json/context-after.json and per-invocation raw stdout/stderr/argv/identity records.
