"""Observe preserved original-source packets against the actual native checker."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import time
import tomllib

base = Path(__file__).parent
repo = Path('/private/tmp/qleisli-ordinary-closed-fix')
kernel = repo / 'lean-kernel/.lake/build/bin/qleisli-kernel'
compiler = Path('/Users/masa/git/Qleisli/target/debug/qleisli')
version = tomllib.loads((repo / 'Cargo.toml').read_text())['package']['version']
out = base / 'observations-first'
out.mkdir(exist_ok=False)
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def snapshot():
    inputs = sorted(base.glob('*/main.qli')) + sorted(base.glob('*/case.json')) + sorted(base.glob('*/request.qlv'))
    return dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
                kernel_sha256=digest(kernel), compiler_sha256=digest(compiler),
                inputs={str(p.relative_to(base)):digest(p) for p in inputs},
                plan_sha256=digest(base/'plan.json'), observer_sha256=digest(Path(__file__)))
before = snapshot()
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
results=[]
for case in ['baseline','consumed-local','qualified-control','unshadowed-control']:
    operations=[('native',[str(kernel),'--qmatch-source-check',version],(base/case/'request.qlv').read_bytes()),
                ('rust',[str(compiler),'check','--entry=same::choose','--module=same='+str(base/case/'main.qli'),
                         '--ir-profile=raw','--lean-kernel='+str(kernel),'--format=json'],None)]
    for mode,argv,payload in operations:
        label=case+'-'+mode; started=time.monotonic()
        with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
            run=subprocess.run(argv,input=payload,cwd=repo,env={**os.environ,'LEAN_NUM_THREADS':'1'},
                               stdout=stdout,stderr=stderr,timeout=60)
        results.append(dict(label=label,argv=argv,exit_code=run.returncode,seconds=time.monotonic()-started,
                            stdout_sha256=digest(out/(label+'.stdout')),stderr_sha256=digest(out/(label+'.stderr'))))
after=snapshot()
report=dict(before=before,after=after,stable=before==after,results=results,
            peak_rss_bytes=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
            scope='Actual local native acceptance/refusal and CLI diagnostics for preserved tiny packets. '
                  'No production fix, publication, source/IR theorem or new guarantee is claimed.')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'stable':report['stable'],'peak':report['peak_rss_bytes'],
                  'results':[{k:v for k,v in r.items() if k in ['label','exit_code','seconds']} for r in results]},indent=2))
for item in results:
    label=item['label'];print(label+': '+(out/(label+'.stdout')).read_text()[:2000])
    error=(out/(label+'.stderr')).read_text()
    if error:print(error[:1500])
