"""Informed tiny first-source study; no replay or clean-build attestation.

Original selected CLI and explicit selected native checker identities are
observations. Source identity alone is not executable build provenance.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path('/Users/masa/git/Qleisli')
HERE = Path(__file__).resolve().parent
CLI = ROOT / 'target/debug/qleisli'
KERNEL = ROOT / 'lean-kernel/.lake/build/bin/qleisli-kernel'
EXPECTED_KERNEL = '54c9d60b80f67217abd95c8fe6ec1c06aa262e142d5e6db30f46a20cb90faf07'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def snapshot():
    names = set(git('ls-files', '-z', '--', '*.rs').decode().split('\0'))
    names.update(git('ls-files', '--others', '--exclude-standard', '-z', '--', '*.rs').decode().split('\0'))
    return {
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'branch': git('branch', '--show-current').decode().strip(),
        'git_status_porcelain': git('status', '--porcelain=v1').decode(),
        'rust_source_sha256': {name: sha(ROOT / name) for name in sorted(names) if name},
        'cli_sha256': sha(CLI), 'kernel_sha256': sha(KERNEL),
    }

cases = [
    ('phase-unused', '''use std::quantum::phase_eighth;
unitary fn unused[const U:Op<Unit>](q:Q<Unit>)->Q<Unit>
requires Applicable(U){phase_eighth(ctrl q);U(q)}
''', 'Accept, but baseline generic primitive action may receive no native sector request.'),
    ('phase-direct', '''use std::quantum::phase_eighth;
unitary fn direct(q:Q<Unit>)->Q<Unit>{phase_eighth(ctrl q);q}
''', 'Accept: exact scalar global phase preserves the empty control-axis set.'),
    ('x-unused', '''use std::quantum::x;
unitary fn unused[const U:Op<Bit>](q:Q<Bit>)->Q<Bit>
requires Applicable(U){x(ctrl q);U(q)}
''', 'Refuse: X changes the controlled sector; suspected baseline dormant generic gap may accept.'),
    ('x-direct', '''use std::quantum::x;
unitary fn direct(q:Q<Bit>)->Q<Bit>{x(ctrl q);q}
''', 'Refuse at the original x(ctrl q) action: X changes the controlled sector.'),
]
manifest = 'schema-version = 2\n\n[qrate]\nedition = "2026"\n'
if (HERE / 'observations.json').exists():
    raise SystemExit('Refusing to replace retained first observations')
for name, source, _prediction in cases:
    project = HERE / name
    project.mkdir(exist_ok=False)
    (project / 'main.qli').write_text(source)
    (project / 'Qargo.toml').write_text(manifest)
first = {
    'classification': 'informed study, prior CLI; no zero-prior benchmark or build attestation',
    'scope': 'Only 0-qubit scalar phase and 1-bit X; no maximum-size quantum case. Current phase_eighth is the existing global-phase primitive, not a proposed canonical API.',
    'cases': [{'name': name, 'prediction': prediction,
               'main_sha256': sha(HERE / name / 'main.qli'),
               'manifest_sha256': sha(HERE / name / 'Qargo.toml')}
              for name, _source, prediction in cases],
    'before': snapshot(),
}
assert first['before']['kernel_sha256'] == EXPECTED_KERNEL
(HERE / 'predictions-and-inputs.json').write_text(json.dumps(first, indent=2) + '\n')
observations = []
for name, _source, _prediction in cases:
    before = snapshot()
    argv = [str(CLI), 'check', str(HERE / name), '--format=json', '--lean-kernel=' + str(KERNEL)]
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, env=os.environ.copy())
    (HERE / (name + '.stdout')).write_bytes(result.stdout)
    (HERE / (name + '.stderr')).write_bytes(result.stderr)
    after = snapshot()
    observations.append({'name': name, 'argv': argv, 'exit': result.returncode,
                         'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                         'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
                         'before': before, 'after': after, 'stable_window': before == after})
    print(name, result.returncode, result.stdout.decode(), result.stderr.decode())
last = snapshot()
(HERE / 'observations.json').write_text(json.dumps({'observations': observations, 'after': last,
     'stable_total_window': first['before'] == last}, indent=2) + '\n')
assert first['before'] == last
