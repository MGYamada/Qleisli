from pathlib import Path
import hashlib,json,os,subprocess,sys,time,datetime
ROOT=Path('/Users/masa/git/Qleisli')
CLI=Path('/private/tmp/qleisli-369-validation-nvmrn6l8/normal-qleisli')
KERNEL=ROOT/'lean-kernel/.lake/build/bin/qleisli-kernel'
SOURCES=Path(sys.argv[1]); OBS=Path(sys.argv[2])
EXPECTED_CLI='fb76379c81758517cc12e2b992e9855cdbbfa5c4c2768887f772d649a35b347c'
EXPECTED_KERNEL='54c9d60b80f67217abd95c8fe6ec1c06aa262e142d5e6db30f46a20cb90faf07'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def packet():
    return {str(p.relative_to(SOURCES)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(SOURCES.rglob('*')) if p.is_file()}
def window():
    paths=sorted([*ROOT.joinpath('src/frontend').rglob('*.rs'),*ROOT.joinpath('stdlib').rglob('*.qli'),ROOT/'Cargo.toml',ROOT/'Cargo.lock',ROOT/'stdlib/Qargo.toml',ROOT/'src/bin/qleisli/source_plan.rs',ROOT/'src/bin/qleisli/source_plan/options.rs'])
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'cli_sha256':sha(CLI),'kernel_sha256':sha(KERNEL),'runtime_files':{str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths},'first_source_files':packet()}
def working():
    names=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT)
    state=hashlib.sha256(); files={}
    for n in sorted(set(names.split(b'\0'))-{b''}):
        p=ROOT/os.fsdecode(n); state.update(n+b'\0')
        if p.is_symlink():v={'symlink':os.readlink(p)};state.update(b'link\0'+os.fsencode(v['symlink']))
        elif p.is_file():v={'mode':p.stat().st_mode&0o777,'bytes':p.stat().st_size,'sha256':sha(p)};state.update(str(v['mode']).encode()+b'\0'+v['sha256'].encode())
        else:v={'missing':True};state.update(b'missing')
        state.update(b'\0');files[os.fsdecode(n)]=v
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'working_inputs_sha256':state.hexdigest(),'files':files}
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
# New literal specifications below are authored for this study; no argv is
# read from old observation records or executed from an archive/manifest.
CASES=[('ordinary-empty-bits-constructor',['main'],['raw']),('unused-closed-empty-owner-identity',['main','unused'],['raw']),('selected-empty-owner-identity',['main'],['raw']),('explicit-empty-consume-reintroduce',['main'],['hierarchy','raw']),('unit-is-not-empty-register',['main'],['raw']),('implicit-zero-owner-drop',['main'],['raw']),('duplicate-zero-owner',['main'],['raw']),('bit-is-not-one-bit-register',['main'],['raw'])]
assert sha(CLI)==EXPECTED_CLI and sha(KERNEL)==EXPECTED_KERNEL
first=window();dump(OBS/'context-before.json',first);before_working=working();dump(OBS/'working-inputs-before.json',before_working)
records=[]
for cid,modules,profiles in CASES:
    project=SOURCES/'cases'/cid/'current-explicit-old-imports'
    commands=[('finite',[str(CLI),'--format=json','check',str(project),'--lean-kernel='+str(KERNEL)])]
    for profile in profiles:
        argv=[str(CLI),'--format=json','check','--entry=main::entry','--ir-profile='+profile,'--lean-kernel='+str(KERNEL)]
        argv.extend('--module='+name+'='+str(project/(name+'.qli')) for name in modules)
        commands.append(('selected-'+profile,argv))
    for profile,argv in commands:
        target=OBS/'checks'/cid/profile;target.mkdir(parents=True)
        before=window();dump(target/'before.json',before)
        start=time.monotonic();timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat();timeout=False
        try:
            run=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60,check=False)
            code=run.returncode; stdout=run.stdout;stderr=run.stderr
        except subprocess.TimeoutExpired as e:
            timeout=True;code=None;stdout=e.stdout or b'';stderr=e.stderr or b''
        elapsed=time.monotonic()-start
        (target/'stdout').write_bytes(stdout);(target/'stderr').write_bytes(stderr)
        after=window();dump(target/'after.json',after)
        parsed=None;parse_error=None
        try:parsed=json.loads(stdout)
        except Exception as e:parse_error=type(e).__name__+': '+str(e)
        diagnostics=(parsed or {}).get('diagnostics',[]) if isinstance(parsed,dict) else []
        record={'case':cid,'flavor':'current-explicit-old-imports','profile':profile,'argv':argv,'cwd':str(ROOT),'observed_start_utc':timestamp,'elapsed_seconds':elapsed,'exit_code':code,'timeout':timeout,'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'stdout_bytes':len(stdout),'stderr_bytes':len(stderr),'json_parse_error':parse_error,'outcome':parsed.get('outcome') if isinstance(parsed,dict) else None,'diagnostics':diagnostics,'result':parsed.get('result') if isinstance(parsed,dict) else None,'window_stable':before==after,'matches_initial_window':before==first,'record_directory':str(target.relative_to(OBS))}
        dump(target/'record.json',record);records.append(record)
        print(cid,profile,'exit',code,'stable',before==after,'codes',[d.get('code') for d in diagnostics],flush=True)
last=window();dump(OBS/'context-after.json',last);after_working=working();dump(OBS/'working-inputs-after.json',after_working)
summary={'format':'qleisli.empty-bits-finite-first-observations','version':1,'complete':len(records)==17,'desired_forms_executed':False,'invocations':len(records),'accepted':sum(r['exit_code']==0 for r in records),'refused':sum(r['exit_code'] not in (0,None) for r in records),'timeouts':sum(r['timeout'] for r in records),'all_per_invocation_windows_stable':all(r['window_stable'] and r['matches_initial_window'] for r in records),'full_study_window_stable':first==last,'whole_working_inputs_stable':before_working==after_working,'runtime_file_count':len(first['runtime_files']),'source_freeze_sha256':sha(SOURCES/'freeze.json'),'cli_sha256':EXPECTED_CLI,'kernel_sha256':EXPECTED_KERNEL,'records':records,'scope':'First bounded current-vocabulary source/profile observations only; prior immutable CLI is not attested to current dirty source; desired forms uncompiled; no exact requested Meaning/source preservation/PR/RS claim.'}
dump(OBS/'summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k!='records'},indent=2),flush=True)
