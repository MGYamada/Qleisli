import hashlib,json,subprocess
from pathlib import Path
root=Path('/Users/masa/git/Qleisli');out=Path(__file__).parent
cli=root/'target/debug/qleisli';kernel=root/'lean-kernel/.lake/build/bin/qleisli-kernel'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def window():
 return {str(p.relative_to(root)):sha(p) for p in sorted((root/'src').rglob('*.rs'))+sorted((root/'stdlib/src').glob('*.qli'))+[root/'Cargo.toml']}
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True)
source='use std::quantum::{t,init0};use std::observe::measure_z;\nclassical fn predicate(b:Bit)->Bit{b}\npub observe fn main()->Bit{let q=with_computed(init0(),predicate){|a|\n'+'let a=t(a);\n'*1025+'a};measure_z(q)}\n'
project=out/'canonical-1025-t';project.mkdir();(project/'main.qli').write_text(source);(project/'Qargo.toml').write_text('schema-version = 2\n\n[qrate]\nedition = "2026"\n')
argv=[str(cli),'check',str(project),'--lean-kernel='+str(kernel)]
plan={'classification':'informed bounded source compatibility study; one Bit data plus one computed ancilla, no execution, not a maximum-width case','prediction':'accept existing exactly expanded sealed T chain of 1025 operations; no independent request or new equation is claimed','build_attestation':False,'driver_sha256':sha(Path(__file__)),'head_before':git('rev-parse','HEAD').strip(),'dirty_before':git('status','--short'),'sources_before':window(),'executables_before':{str(p):sha(p) for p in [cli,kernel]},'source_sha256':sha(project/'main.qli'),'manifest_sha256':sha(project/'Qargo.toml'),'argv':argv}
with (out/'plan.json').open('x') as f:f.write(json.dumps(plan,indent=2)+'\n')
result=subprocess.run(argv,cwd=root,capture_output=True,timeout=60)
record={'exit_code':result.returncode,'head_after':git('rev-parse','HEAD').strip(),'dirty_after':git('status','--short'),'sources_after':window(),'executables_after':{str(p):sha(p) for p in [cli,kernel]},'source_sha256_after':sha(project/'main.qli'),'build_attestation':False}
for stream in ['stdout','stderr']:
 path=out/(stream+'.txt');path.write_bytes(getattr(result,stream));record[stream]={'path':path.name,'sha256':sha(path)}
record['executables_stable']=record['executables_after']==plan['executables_before'];record['wip_sources_stable']=record['sources_after']==plan['sources_before'];record['original_source_stable']=record['source_sha256_after']==plan['source_sha256']
with (out/'observations.json').open('x') as f:f.write(json.dumps(record,indent=2)+'\n')
assert record['executables_stable'] and record['original_source_stable']
print(json.dumps({'packet':str(out),'exit_code':result.returncode,'wip_sources_stable':record['wip_sources_stable']}),flush=True)
