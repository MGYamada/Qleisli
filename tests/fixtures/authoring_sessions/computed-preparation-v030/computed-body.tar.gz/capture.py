import hashlib,json,subprocess
from pathlib import Path
root=Path('/Users/masa/git/Qleisli');out=Path(__file__).parent
cli=root/'target/debug/qleisli';kernel=root/'lean-kernel/.lake/build/bin/qleisli-kernel'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source_window():
 paths=sorted((root/'src').rglob('*.rs'))+sorted((root/'stdlib/src').glob('*.qli'))+[root/'Cargo.toml']
 return {str(p.relative_to(root)):sha(p) for p in paths}
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True)
prefix='classical fn predicate(b:Bit)->Bit{b}\n'
cases={
'derived_z':('accept after normalization; exact Z', 'use std::gate::z;\n'+prefix+'pub unitary fn main(q:Q<Bit>)->Q<Bit>{with_computed(q,predicate){|a|z(a)}}'),
'derived_t':('accept after normalization; exact T','use std::gate::t;\n'+prefix+'pub unitary fn main(q:Q<Bit>)->Q<Bit>{with_computed(q,predicate){|a|t(a)}}'),
'unrelated_z_wrapper':('accept by actual body, not its name','use std::gate::z;\n'+prefix+'unitary fn turnstile(q:Q<Bit>)->Q<Bit>{z(q)}\npub unitary fn main(q:Q<Bit>)->Q<Bit>{with_computed(q,predicate){|a|turnstile(a)}}'),
'non_diagonal':('refuse actual H because exact cleanup relation fails','use std::quantum::h;\n'+prefix+'pub unitary fn main(q:Q<Bit>)->Q<Bit>{with_computed(q,predicate){|a|h(a)}}'),
'wrong_scalar_meaning':('refuse wrong scalar; never normalize it away','use std::gate::z;use std::quantum::phase_eighth;\nclassical fn keep(b:Bit)->Bit{b}\nclassical fn zero(b:Bit)->Bit{0}\nmeaning Identity:Bit=permutation_by(keep);\nunitary fn wrong(q:Q<Bit>)->Q<Bit>{with_computed(q,zero){|a|phase_eighth(z(a))}}\nunitary fn demand[const U:Op<Bit,Identity>](q:Q<Bit>)->Q<Bit> requires Applicable(U){U(q)}\npub unitary fn main(q:Q<Bit>)->Q<Bit>{demand[wrong](q)}'),
'hidden_reference':('common source refusal for hidden external owner','use std::quantum::h;\nclassical fn zero(u:Unit)->Bit{0}\npub unitary fn main(q:Q<Unit>,r:Q<Bit>)->(Q<Unit>,Q<Bit>){let q=with_computed(q,zero){|a|let r=h(r);a};(q,r)}'),
}
plan={'classification':'informed checking study, at most two allocated quantum wires; no execution','build_attestation':False,'driver_sha256':sha(Path(__file__)),'head_before':git('rev-parse','HEAD').strip(),'dirty_before':git('status','--short'),'sources_before':source_window(),'executables_before':{str(p):sha(p) for p in [cli,kernel]},'cases':{}}
for name,(prediction,source) in cases.items():
 target=out/name;target.mkdir();(target/'main.qli').write_text(source+'\n');(target/'Qargo.toml').write_text('schema-version = 2\n\n[qrate]\nedition = "2026"\n')
 plan['cases'][name]={'prediction':prediction,'source_sha256':sha(target/'main.qli'),'manifest_sha256':sha(target/'Qargo.toml')}
with (out/'plan.json').open('x') as f:f.write(json.dumps(plan,indent=2)+'\n')
rows=[]
for name in cases:
 argv=[str(cli),'check',str(out/name),'--lean-kernel='+str(kernel)]
 result=subprocess.run(argv,cwd=root,capture_output=True,timeout=60)
 row={'case':name,'argv':argv,'exit_code':result.returncode}
 for stream in ['stdout','stderr']:
  path=out/(name+'.'+stream+'.txt');path.write_bytes(getattr(result,stream));row[stream]={'path':path.name,'sha256':sha(path)}
 row['source_sha256_after']=sha(out/name/'main.qli');rows.append(row)
 print(json.dumps({'case':name,'exit':result.returncode}),flush=True)
record={'head_after':git('rev-parse','HEAD').strip(),'dirty_after':git('status','--short'),'sources_after':source_window(),'executables_after':{str(p):sha(p) for p in [cli,kernel]},'observations':rows,'build_attestation':False}
record['executables_stable']=record['executables_after']==plan['executables_before'];record['wip_sources_stable']=record['sources_after']==plan['sources_before'];record['original_sources_stable']=all(row['source_sha256_after']==plan['cases'][row['case']]['source_sha256'] for row in rows)
with (out/'observations.json').open('x') as f:f.write(json.dumps(record,indent=2)+'\n')
assert record['executables_stable'] and record['original_sources_stable']
print(json.dumps({'packet':str(out),'executables':record['executables_after'],'wip_sources_stable':record['wip_sources_stable']}),flush=True)
