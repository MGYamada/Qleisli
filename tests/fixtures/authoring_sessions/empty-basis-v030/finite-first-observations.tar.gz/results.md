# First finite empty-register observations

Eight independently authored cases were frozen before checks. Seventeen new literal current-vocabulary commands ran once each: **4 accepted,13 refused,0 timeout**. Every predeclared outcome/category prediction matched. Desired bare-primitive/ordinary-derived drafts remain uncompiled. No source repair, retry, fallback, old recorded argv execution or build occurred.

| Current case | Finite | Selected Raw | Selected hierarchy |
| --- | --- | --- | --- |
| Ordinary empty_bits() return | unsupported Bits type | accepted | not requested |
| Bit entry with unused closed Q<Bits<0>> sibling | unsupported at unused.qli | accepted | not requested |
| Q<Bits<0>> identity | unsupported Bits type | accepted | not requested |
| Explicit consume_empty then empty | unsupported Bits type | unsupported primitive/capability | accepted |
| finish(Q<Bits<0>>) false Unit coercion | type_mismatch | type | not requested |
| Implicit zero-owner drop | ownership | ownership | not requested |
| Duplicate zero owner | ownership | ownership | not requested |
| Bit/Bits<1> false coercion | type_mismatch | type | not requested |

The four finite profile refusals and four common errors retain full real diagnostics and original spans. In particular, the unused closed sibling rejects an otherwise ordinary finite main; private/unreachable placement is not a remedy. The selected Raw identity beside that sibling still common-checks every supplied module. All authored programs have at most one physical qubit. No maximum-size case was generated or checked; finite requests refused before native materialization.

The three successful Raw checks report native-validity, source_steps_checked=true, request_checked=false, source_meaning_verified=false and source_preservation_verified=false. The one hierarchy success reports a producer-origin composition request with request_checked=true and producer-consistency scope. That request is not an independently authored Meaning, and neither success type proves general source preservation, reference laws, PR, quantitative RS or new-feature completion.

## Identity and preservation

The used immutable prior-candidate CLI is /private/tmp/qleisli-369-validation-nvmrn6l8/normal-qleisli, SHA-256 fb76379c81758517cc12e2b992e9855cdbbfa5c4c2768887f772d649a35b347c. It was NOT built from the currently observed dirty finite connection. Every invocation used /Users/masa/git/Qleisli/lean-kernel/.lake/build/bin/qleisli-kernel, SHA-256 54c9d60b80f67217abd95c8fe6ec1c06aa262e142d5e6db30f46a20cb90faf07. CLI reports checker_identity=unpinned; this study records observed bytes and does not claim a trusted binary attestation. The separately changing, unselected target/debug binary is not the executable used in this study.

Observed HEAD stayed54edaa7717777ac35f86d7a4a9d013069ad676ac. The complete18961-file tracked/untracked working-input map before/after stayed1c12213ae701e3150fd76872b90dc6e88259333b41b1adf122fd33399f4036dd. Each invocation additionally retained its before/after87-file frontend/stdlib/config/source-plan runtime view, the selected CLI/kernel identities and the full first-source packet; all matched the initial view. The full working-input maps cover the remaining repository source files as well. These are observation-window identities, not proof that the old binary executes the current dirty source.

First-source freeze SHA-256:02e9f30765722f3301799c04a99fbace24eb99ed9767ddddc0e93cb56177d4a8. All37 original listed files, exact modes and15003 bytes remain unchanged. freeze.json is an additional38th packet file. All16 source trees include schema-version2/[qrate].edition2026 manifests. The runner was separately frozen before execution; no archived command was loaded as instructions. Raw stdout/stderr, exit codes, durations, fresh argv, JSON classifications and every identity window are retained under checks/.

This is future-feature preparation only. It changes no repository source, issue, native checker, admission/guarantee, edition, budget or current finite PR behavior. #39/#63 and generic-QFT exclusions remain unchanged; overall issue completion remains60/127=47.24%.
