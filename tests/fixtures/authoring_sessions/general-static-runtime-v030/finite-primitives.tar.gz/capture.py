import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/Users/masa/git/Qleisli')
out = Path(__file__).parent
cli = root / 'target/debug/qleisli'
kernel = root / 'lean-kernel/.lake/build/bin/qleisli-kernel'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
cases = {
    'one_axis_roundtrip': '''use std::registers::{empty,consume_empty,put_bit,take_bit};
use std::quantum::{init0,x};use std::observe::measure_z;
pub observe fn main()->Bit {
 let q=put_bit[1,0](x(init0()),empty());
 let(b,z)=take_bit[1,0](q);consume_empty(z);measure_z(b)
}''',
    'word_constructor': '''use std::classical::{empty_bits,prepend_bit};
pub unitary fn main()->Bits<2>{prepend_bit[1](0,prepend_bit[0](1,empty_bits()))}''',
    'exact_phase': '''use std::quantum::{init0,h,phase};use std::observe::measure_z;
pub observe fn main()->Bit{measure_z(h(phase[1,3](h(init0()))))}''',
    'unsupported_phase': '''use std::quantum::{init0,h,phase};use std::observe::measure_z;
pub observe fn main()->Bit{measure_z(h(phase[1,4](h(init0()))))}''',
}
plan = {
 'kind':'informed finite primitive transport study; zero/one quantum axis only',
 'predictions':{'one_axis_roundtrip':'Original finite profile should refuse Nat operands; integrated ordinary path should accept and return1.',
 'word_constructor':'Original profile should refuse closed Bits<2>/Nat operands; integrated path should return low-axis-first word[1,0].',
 'exact_phase':'Original finite profile should refuse Nat operands; integrated exact eighth-turn phase should accept.',
 'unsupported_phase':'Current source checking may admit phase[1,4]; finite Raw must refuse exact representability without rounding/fallback.'},
 'head_before':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'dirty_before':subprocess.check_output(['git','status','--short'],cwd=root,text=True),
 'driver_sha256':sha(Path(__file__)),
 'executables_before':{str(p):sha(p) for p in [cli,kernel]},
 'build_attestation':False,
 'source_window':'WIP source and observed executable have distinct identities; adapter edits are not bound to this old CLI.',
 'execution':'not run','cases':{},
}
for name, source in cases.items():
    target=out/name;target.mkdir()
    (target/'main.qli').write_text(source+'\n')
    (target/'Qargo.toml').write_text('schema-version = 2\n\n[qrate]\nedition = "2026"\n')
    plan['cases'][name]={'source_sha256':sha(target/'main.qli'),'manifest_sha256':sha(target/'Qargo.toml')}
with (out/'plan.json').open('x') as f: f.write(json.dumps(plan,indent=2)+'\n')
observations=[]
for name in cases:
    argv=[str(cli),'check',str(out/name),'--lean-kernel='+str(kernel)]
    result=subprocess.run(argv,cwd=root,capture_output=True)
    row={'case':name,'argv':argv,'exit_code':result.returncode}
    for stream in ['stdout','stderr']:
        target=out/(name+'.'+stream+'.txt')
        with target.open('xb') as f: f.write(getattr(result,stream))
        row[stream]={'path':target.name,'sha256':sha(target)}
    row['source_sha256_after']=sha(out/name/'main.qli')
    observations.append(row)
record={'head_after':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'dirty_after':subprocess.check_output(['git','status','--short'],cwd=root,text=True),
 'executables_after':{str(p):sha(p) for p in [cli,kernel]},'observations':observations,
 'scope':'Actual original diagnostics only; downstream predictions and source/runtime/target preservation are unvalidated.'}
record['executables_stable']=record['executables_after']==plan['executables_before']
record['source_bytes_stable']=all(r['source_sha256_after']==plan['cases'][r['case']]['source_sha256'] for r in observations)
with (out/'observations.json').open('x') as f: f.write(json.dumps(record,indent=2)+'\n')
assert record['executables_stable'] and record['source_bytes_stable']
print(json.dumps({'outcomes':[(r['case'],r['exit_code']) for r in observations],'executables':record['executables_after']},indent=2))
