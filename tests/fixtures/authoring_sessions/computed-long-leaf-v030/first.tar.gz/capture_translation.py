# Saved observer before the first execution; commands are hardcoded, not read from records.
import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/Users/masa/git/Qleisli')
OUT=Path(__file__).parent
CLI=ROOT/'target/debug/qleisli'
KERNEL=ROOT/'lean-kernel/.lake/build/bin/qleisli-kernel'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
 paths=[ROOT/n for n in ('Cargo.toml','Cargo.lock','build.rs')]
 paths+=sorted((ROOT/'src').rglob('*.rs'))
 paths+=sorted((ROOT/'stdlib/src').rglob('*.qli'))
 return {str(p.relative_to(ROOT)):sha(p) for p in paths}
record=OUT/'translation-check.json'
started=OUT/'translation-check.started.json'
if record.exists() or started.exists(): raise SystemExit('existing first observation refused')
first=json.loads((OUT/'translation-source.json').read_text())
for name,digest in first['files'].items():
 if sha(OUT/name)!=digest: raise SystemExit('first source identity changed')
argv=[str(CLI),'check',str(OUT/'attempt-02'),'--format=json','--lean-kernel='+str(KERNEL)]
before=inputs()
metadata={'argv':argv,'cwd':str(ROOT),'observer_sha256':sha(Path(__file__)),'cli_sha256':sha(CLI),'kernel_sha256':sha(KERNEL),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'dirty_status':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True),'inputs_before':before,'scope':'Dirty local executable identity and complete selected Rust/stdlib input window; build record separate. Not compiler/runtime/source preservation attestation, blind model benchmark, proof replay or issue completion.'}
started.write_text(json.dumps(metadata,indent=2)+'\n')
env=os.environ.copy();env['QLEISLI_KERNEL']=str(KERNEL)
begin=time.monotonic()
with (OUT/'translation-check.stdout.txt').open('xb') as stdout,(OUT/'translation-check.stderr.txt').open('xb') as stderr:
 result=subprocess.run(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
after=inputs()
data=metadata|{'exit_code':result.returncode,'seconds':time.monotonic()-begin,'inputs_after':after,'inputs_stable':before==after,'cli_stable':metadata['cli_sha256']==sha(CLI),'kernel_stable':metadata['kernel_sha256']==sha(KERNEL),'source_stable':all(sha(OUT/name)==digest for name,digest in first['files'].items())}
record.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:v for k,v in data.items() if k not in ('inputs_before','inputs_after','dirty_status')},indent=2))
print((OUT/'translation-check.stdout.txt').read_text())
print((OUT/'translation-check.stderr.txt').read_text())
raise SystemExit(0 if all(data[k] for k in ('inputs_stable','cli_stable','kernel_stable','source_stable')) else 99)
