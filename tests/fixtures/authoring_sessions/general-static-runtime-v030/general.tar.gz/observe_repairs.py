#!/usr/bin/env python3
import datetime,hashlib,json,os,pathlib,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/masa/git/Qleisli')
CLI=REPO/'target/debug/qleisli'
KERNEL=REPO/'lean-kernel/.lake/build/bin/qleisli-kernel'
EXPECTED_KERNEL='54c9d60b80f67217abd95c8fe6ec1c06aa262e142d5e6db30f46a20cb90faf07'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def state():
 paths=[*sorted((REPO/'src/frontend/compile').rglob('*.rs')),REPO/'src/frontend/closed.rs',REPO/'src/frontend/check/plans.rs',REPO/'docs/src/reference/static-language.md']
 return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=REPO,text=True),'cli_sha256':digest(CLI),'kernel_sha256':digest(KERNEL),'source_sha256':{str(p.relative_to(REPO)):digest(p) for p in paths}}
manifest=json.loads((ROOT/'repair-manifest.json').read_text())
for item in manifest['projects']:
 for rel,sha in item['files'].items():
  assert digest(ROOT/rel)==sha,(rel,'first source changed')
assert digest(KERNEL)==EXPECTED_KERNEL
OUTPUT=ROOT/'observations-repairs'
OUTPUT.mkdir(exist_ok=False)
initial=state()
(OUTPUT/'before.json').write_text(json.dumps(initial,indent=2)+'\n')
observations=[]
for item in manifest['projects']:
 name=item['name']; before=state()
 argv=[str(CLI),'check',str(ROOT/'repairs'/name),'--format=json','--lean-kernel='+str(KERNEL)]
 started=time.monotonic(); result=subprocess.run(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 seconds=time.monotonic()-started
 (OUTPUT/(name+'.stdout.txt')).write_bytes(result.stdout)
 (OUTPUT/(name+'.stderr.txt')).write_bytes(result.stderr)
 after=state()
 obs={'name':name,'argv':argv,'exit_code':result.returncode,'seconds':seconds,'before':before,'after':after,'stdout':{'path':name+'.stdout.txt','sha256':hashlib.sha256(result.stdout).hexdigest(),'bytes':len(result.stdout)},'stderr':{'path':name+'.stderr.txt','sha256':hashlib.sha256(result.stderr).hexdigest(),'bytes':len(result.stderr)},'cli_identity_stable':before['cli_sha256']==after['cli_sha256'],'kernel_identity_stable':before['kernel_sha256']==after['kernel_sha256'],'source_identity_stable':before['source_sha256']==after['source_sha256']}
 observations.append(obs)
 (OUTPUT/'observations.json').write_text(json.dumps({'scope':'Actual original CLI observations only; source/HEAD/executable hashes are identity observations, not build attestation. Explicit Basis type(T) repairs only; original observations unchanged.','driver_sha256':digest(pathlib.Path(__file__)),'first_manifest_sha256':digest(ROOT/'repair-manifest.json'),'observations':observations},indent=2)+'\n')
 print(name, result.returncode, result.stdout.decode(errors='replace').strip(),result.stderr.decode(errors='replace').strip(),flush=True)
(OUTPUT/'after.json').write_text(json.dumps(state(),indent=2)+'\n')
