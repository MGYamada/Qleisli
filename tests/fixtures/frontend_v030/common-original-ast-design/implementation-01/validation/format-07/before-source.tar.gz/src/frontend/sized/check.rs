//! Closed substitutions of common checked interfaces; no second source judgment.
// Copyright 2026 Masahiko G. Yamada. SPDX-License-Identifier: Apache-2.0.

use super::{BasisBinding, Error, OperationBinding, ParsedProgram, Result, SourceType, Span};
use crate::frontend::check::{
    Interface, Linear, StaticKind, close_type_budgeted, type_size_budgeted,
};
use crate::frontend::resolve::locals::BinderKey;
use crate::frontend::resolve::{DefId, Failure};
use std::collections::{BTreeMap, BTreeSet};

pub(super) struct ClosedInterface {
    pub naturals: BTreeMap<BinderKey, u32>,
    pub bases: BTreeMap<BinderKey, SourceType>,
    pub parameters: Vec<SourceType>,
    pub result: SourceType,
    pub operations: BTreeMap<BinderKey, SourceType>,
}

fn check_bindings<V>(
    actual: &BTreeMap<String, V>,
    expected: &BTreeSet<&str>,
    category: &str,
    subject: &str,
    span: Span,
    charge: &mut impl FnMut(Span, usize) -> Result<()>,
) -> Result<()> {
    for name in actual.keys() {
        charge(span, name.len() + 1)?;
    }
    charge(span, expected.len())?;
    if actual.len() == expected.len() && expected.iter().all(|name| actual.contains_key(*name)) {
        return Ok(());
    }
    let missing = expected
        .iter()
        .filter(|name| !actual.contains_key(**name))
        .copied()
        .collect::<Vec<_>>()
        .join(", ");
    let unexpected = actual
        .keys()
        .filter(|name| !expected.contains(name.as_str()))
        .map(String::as_str)
        .collect::<Vec<_>>()
        .join(", ");
    Err(Error::new(
        "static",
        span,
        format!(
            "concrete {category} bindings for {subject} must exactly match the declaration; missing [{missing}]; unexpected [{unexpected}]"
        ),
    ))
}

fn visible_definition<'a>(
    program: &'a ParsedProgram,
    path: &str,
    requester: Option<&str>,
    span: Span,
) -> Result<(DefId, &'a Interface)> {
    let resolution = &program.checked.resolution;
    let id = resolution.qualified(path).map_err(|kind| {
        let mut error = ParsedProgram::resolution_error(Failure {
            module: String::new(),
            span,
            kind,
        });
        error.module = None;
        error
    })?;
    let interface = program.checked.interface(id);
    if !resolution.visible(id, requester.and_then(|name| resolution.module(name))) {
        return Err(
            Error::new("visibility", span, format!("dependency {path} is private"))
                .in_module(requester.unwrap_or(&interface.module)),
        );
    }
    if !program.checked.effects.contains_key(&id) {
        return Err(Error::new(
            "type",
            span,
            "entry or provider must be an ordinary runtime function",
        )
        .in_module(&interface.module));
    }
    Ok((id, interface))
}

fn closed_linear(
    linear: &Linear,
    naturals: &BTreeMap<BinderKey, u32>,
    span: Span,
    charge: &mut impl FnMut(Span, usize) -> Result<()>,
) -> Result<i128> {
    charge(span, 1)?;
    linear
        .terms
        .iter()
        .try_fold(linear.constant, |sum, (key, coefficient)| {
            charge(span, 1)?;
            let n = naturals.get(key).ok_or_else(|| {
                Error::new(
                    "static",
                    span,
                    format!("missing concrete natural {}", key.name),
                )
            })?;
            let term = coefficient.checked_mul(i128::from(*n)).ok_or_else(|| {
                Error::new("limit", span, "concrete premise multiplication overflow")
            })?;
            sum.checked_add(term)
                .ok_or_else(|| Error::new("limit", span, "concrete premise addition overflow"))
        })
}

/// Consume normalized common facts. The original source is never reclassified
/// by the temporary concrete lowering representation.
pub(super) fn closed_interface_budgeted(
    program: &ParsedProgram,
    id: DefId,
    types: &BTreeMap<String, BasisBinding>,
    naturals: &BTreeMap<String, u32>,
    subject: &str,
    span: Span,
    mut charge: impl FnMut(Span, usize) -> Result<()>,
) -> Result<ClosedInterface> {
    let interface = program.checked.interface(id);
    // Reserve both temporary binding sets before collecting them; copied keys
    // below retain the original static identities rather than spelling lookup.
    charge(
        span,
        interface
            .statics
            .len()
            .checked_mul(3)
            .ok_or_else(|| Error::new("limit", span, "closed binding accounting overflow"))?,
    )?;
    let expected_types = interface
        .statics
        .iter()
        .filter_map(|formal| {
            matches!(formal.kind, StaticKind::Basis).then_some(formal.key.name.as_str())
        })
        .collect();
    let expected_naturals = interface
        .statics
        .iter()
        .filter_map(|formal| {
            matches!(formal.kind, StaticKind::Natural).then_some(formal.key.name.as_str())
        })
        .collect();
    check_bindings(types, &expected_types, "Basis", subject, span, &mut charge)?;
    check_bindings(
        naturals,
        &expected_naturals,
        "natural",
        subject,
        span,
        &mut charge,
    )?;
    for formal in &interface.statics {
        charge(span, formal.key.name.len() + 1)?;
    }
    for basis in types.values() {
        let size = type_size_budgeted(&basis.ty, 4096, 64, true, span, &mut |span, cells| {
            charge(span, cells).map_err(|error| crate::frontend::check::SourceError {
                code: error.code,
                module: error.module,
                span: error.span,
                message: error.message,
            })
        })
        .map_err(Error::from)?;
        charge(span, size.nodes)?;
    }
    let resolved_naturals = interface
        .statics
        .iter()
        .filter(|formal| matches!(formal.kind, StaticKind::Natural))
        .map(|formal| (formal.key.clone(), naturals[&formal.key.name]))
        .collect::<BTreeMap<_, _>>();
    let resolved_bases = interface
        .statics
        .iter()
        .filter(|formal| matches!(formal.kind, StaticKind::Basis))
        .map(|formal| (formal.key.clone(), types[&formal.key.name].ty.clone()))
        .collect::<BTreeMap<_, _>>();
    let mut satisfied = false;
    for alternative in &interface.premises.alternatives {
        charge(span, 1)?;
        let mut valid = true;
        for constraint in alternative {
            if closed_linear(constraint, &resolved_naturals, span, &mut charge)? > 0 {
                valid = false;
                break;
            }
        }
        if valid {
            satisfied = true;
            break;
        }
    }
    if !satisfied {
        return Err(Error::new(
            "size",
            span,
            "concrete function premise is false",
        ));
    }
    let mut close = |ty: &crate::frontend::check::Ty| -> Result<SourceType> {
        let closed = close_type_budgeted(
            ty,
            &resolved_naturals,
            &resolved_bases,
            span,
            |span, cells| {
                charge(span, cells).map_err(|error| crate::frontend::check::SourceError {
                    code: error.code,
                    module: error.module,
                    span: error.span,
                    message: error.message,
                })
            },
        )
        .map_err(Error::from)?;
        super::elaborate::concrete_capacity(&closed, span)?;
        Ok(closed)
    };
    let parameters = interface
        .params
        .iter()
        .map(&mut close)
        .collect::<Result<_>>()?;
    let result = close(&interface.result)?;
    let operations = interface
        .statics
        .iter()
        .filter_map(|formal| match &formal.kind {
            StaticKind::Operation { basis, .. } => {
                Some(close(basis).map(|basis| (formal.key.clone(), SourceType::quantum(basis))))
            }
            _ => None,
        })
        .collect::<Result<_>>()?;
    Ok(ClosedInterface {
        naturals: resolved_naturals,
        bases: resolved_bases,
        parameters,
        result,
        operations,
    })
}

pub(super) fn instantiate(
    program: &ParsedProgram,
    entry: &str,
    types: &BTreeMap<String, BasisBinding>,
    naturals: &BTreeMap<String, u32>,
    operations: &BTreeMap<String, OperationBinding>,
) -> Result<(DefId, BTreeMap<String, DefId>)> {
    let (entry_id, interface) = visible_definition(program, entry, None, Span::default())?;
    let resolution = &program.checked.resolution;
    let original = &program
        .syntax(&interface.module)
        .expect("retained original")
        .decls[interface.ast_index];
    let span = original.span;
    let mut remaining = 100_000usize;
    let mut charge = |span, cells| {
        remaining = remaining.checked_sub(cells).ok_or_else(|| {
            Error::new(
                "limit",
                span,
                "closed preparation exceeds 100000 concrete cells",
            )
        })?;
        Ok(())
    };
    let result = (|| {
        let closed = closed_interface_budgeted(
            program,
            entry_id,
            types,
            naturals,
            &format!("entry {entry}"),
            span,
            &mut charge,
        )?;
        charge(span, interface.statics.len())?;
        let expected = interface
            .statics
            .iter()
            .filter_map(|formal| {
                matches!(formal.kind, StaticKind::Operation { .. })
                    .then_some(formal.key.name.as_str())
            })
            .collect();
        check_bindings(
            operations,
            &expected,
            "operation",
            &format!("entry {entry}"),
            span,
            &mut charge,
        )?;
        let mut providers = BTreeMap::new();
        let mut nested_operation_provider = false;
        for formal in &interface.statics {
            if let StaticKind::Operation { .. } = &formal.kind {
                let binding = &operations[&formal.key.name];
                let (provider_id, provider) = visible_definition(
                    program,
                    &binding.definition,
                    Some(&interface.module),
                    span,
                )?;
                charge(span, provider.statics.len())?;
                nested_operation_provider |= provider
                    .statics
                    .iter()
                    .any(|p| matches!(p.kind, StaticKind::Operation { .. }));
                let provider_closed = closed_interface_budgeted(
                    program,
                    provider_id,
                    &binding.types,
                    &binding.naturals,
                    &format!(
                        "operation {} provider {}",
                        formal.key.name, binding.definition
                    ),
                    span,
                    &mut charge,
                )?;
                let effect = program.checked.effects[&provider_id].inferred();
                if effect != crate::ir::Effect::Unitary {
                    return Err(Error::new(
                        "effect",
                        span,
                        crate::frontend::effects::unitary_required(&format!(
                            "operation provider {} has inferred body effect `{effect:?}`; Unitary is required",
                            resolution.path(provider_id)
                        )),
                    ));
                }
                if provider_closed.parameters.len() != 1
                    || provider_closed.parameters[0] != provider_closed.result
                    || !provider_closed.result.is_quantum_owner()
                {
                    return Err(Error::new(
                        "type",
                        span,
                        "concrete provider must have one quantum input with the exact output type",
                    ));
                }
                if provider_closed.result != closed.operations[&formal.key] {
                    return Err(Error::new(
                        "type",
                        span,
                        "concrete provider type or tuple/size shape mismatch",
                    ));
                }
                charge(span, formal.key.name.len() + 1)?;
                providers.insert(formal.key.name.clone(), provider_id);
            }
        }
        if nested_operation_provider {
            return Err(Error::new(
                "unsupported",
                span,
                "concrete providers with operation parameters are unsupported",
            ));
        }
        // Check every closed binding before any requested body eligibility.
        // An unsupported entry/body cannot mask an invalid supplied provider.
        program.definition(entry_id)?;
        for provider_id in providers.values() {
            program.definition(*provider_id)?;
        }
        Ok((entry_id, providers))
    })();
    result.map_err(|e| e.in_module(&interface.module))
}

#[cfg(test)]
mod visibility_tests {
    use super::*;

    #[test]
    fn private_definitions_remain_visible_in_their_own_module() {
        let program = ParsedProgram::parse(BTreeMap::from([(
            "local".into(),
            "unitary fn f(q: Q<Bit>) -> Q<Bit> { q }".into(),
        )]))
        .unwrap();
        let span = Span::default();
        assert!(visible_definition(&program, "local::f", Some("local"), span).is_ok());
        for requester in [None, Some("other")] {
            assert_eq!(
                visible_definition(&program, "local::f", requester, span)
                    .unwrap_err()
                    .code(),
                "visibility"
            );
        }
    }
}
