//! Complete original-source judgments, before concrete adapter eligibility.
//!
//! These are untrusted frontend facts. They authorize neither native acceptance
//! nor source preservation, exact cleanup, provider correspondence or a guarantee.
// Copyright 2026 Masahiko G. Yamada. SPDX-License-Identifier: Apache-2.0.

mod body;
mod declarations;
mod normalize;
pub(super) mod primitive;

use super::ast::{self, FnKind, Span};
use super::effects::{BodyEffects, FunctionEffect};
use super::resolve::locals::{BinderKey, Index, Table};
use super::resolve::{self, DefId, Resolution};
pub(super) use super::sized::linear::{Context, Linear};
use super::types::{Kind, Type};
use std::cell::Cell;
use std::collections::{BTreeMap, BTreeSet};
use std::rc::Rc;
use std::sync::Arc;

pub(super) type Ty = Type<Linear>;
pub(super) type Result<T> = std::result::Result<T, SourceError>;

#[derive(Clone, Debug)]
pub(super) struct SourceError {
    pub code: &'static str,
    pub module: Option<String>,
    pub span: Span,
    pub message: String,
}
impl SourceError {
    pub fn new(code: &'static str, span: Span, message: impl Into<String>) -> Self {
        Self { code, module: None, span, message: message.into() }
    }
    pub fn in_module(mut self, module: &str) -> Self {
        if self.module.is_none() { self.module = Some(module.into()); }
        self
    }
}
impl From<super::sized::Error> for SourceError {
    fn from(error: super::sized::Error) -> Self {
        let code = match error.code() {
            "limit" => "limit", "size" => "size", "type" => "type",
            "name" => "name", "static" => "static", "access" => "access",
            "ownership" => "ownership", "effect" => "effect", "cycle" => "cycle",
            "contract" => "contract", "unsupported" => "unsupported",
            "module" => "module", "visibility" => "visibility", "arity" => "arity", _ => "source",
        };
        Self { code, module: error.module().map(str::to_owned), span: error.span(), message: error.message().into() }
    }
}

/// Capacity options select limits, never another source semantics.
#[derive(Clone, Copy, Debug)]
pub(super) struct SourceLimits {
    pub work: usize,
    pub retained_scope_cells: Option<usize>,
}
impl SourceLimits {
    pub fn finite() -> Self { Self { work: 1_000_000, retained_scope_cells: None } }
    pub fn selected() -> Self { Self { work: 1_000_000, retained_scope_cells: Some(16_384) } }
}

pub(in crate::frontend) struct Budget {
    remaining: Cell<usize>,
    limits: SourceLimits,
}
impl Budget {
    pub fn charge(&self, span: Span, cells: usize) -> Result<()> {
        let remaining = self.remaining.get().checked_sub(cells).ok_or_else(|| {
            SourceError::new("limit", span, "common source judgment exceeds its 1000000 work capacity")
        })?;
        self.remaining.set(remaining);
        Ok(())
    }
    pub fn sized_charge(&self, span: Span, cells: usize) -> super::sized::Result<()> {
        self.charge(span,cells).map_err(|e|super::sized::Error::new(e.code,e.span,e.message))
    }
    fn ty(&self, span: Span, ty: &Ty) -> Result<usize> {
        self.charge(span,1)?;let mut pending=vec![(ty,1usize)];let mut cells=0usize;
        while let Some((node,depth))=pending.pop(){
            self.charge(span,1)?;if depth>64{return Err(SourceError::new("limit",span,"type exceeds depth 64"));}
            if !matches!(node.kind,Kind::Q(_)){cells=cells.checked_add(1).ok_or_else(||SourceError::new("limit",span,"type cell count overflow"))?;}
            if cells>4096{return Err(SourceError::new("limit",span,"type exceeds 4096 cells"));}
            match &node.kind {
                Kind::Bits(size)=>self.charge(span,size.storage_cells()?)?,
                Kind::Parameter(parameter)=>self.charge(span,parameter.name.len()+parameter.key.as_ref().map_or(0,|key|key.name.len())+1)?,
                Kind::Q(child)=>{self.charge(span,1)?;pending.push((child,depth));},
                Kind::Tuple(fields)=>{if fields.len()>64{return Err(SourceError::new("limit",span,"type tuple exceeds 64 fields"));}self.charge(span,fields.len())?;pending.extend(fields.iter().rev().map(|field|(field,depth+1)));},
                _=>{},
            }
        }
        Ok(cells)
    }
    fn copy_ty(&self, span: Span, ty: &Ty) -> Result<Ty> { self.ty(span, ty)?; Ok(ty.clone()) }
    fn key(&self,span:Span,key:&BinderKey)->Result<BinderKey>{self.charge(span,key.name.len()+1)?;Ok(key.clone())}
    fn values(&self,span:Span,values:&BTreeMap<BinderKey,Binding>)->Result<BTreeMap<BinderKey,Binding>>{
        let mut copied=BTreeMap::new();for (key,value) in values{
            let key=self.key(span,key)?;let ty=self.copy_ty(span,&value.ty)?;self.charge(span,1)?;
            copied.insert(key,Binding {identity:value.identity,ty});
        }Ok(copied)
    }
    fn copy_context(&self, span: Span, context: &Context) -> Result<Context> {
        Ok(context.copy_budgeted(span,&mut |span,cells|self.sized_charge(span,cells))?)
    }
}

#[derive(Clone, Debug)]
pub(super) enum StaticKind {
    Natural,
    Basis,
    Operation { basis: Ty, meaning: Option<DefId>, access: [bool; 3] },
}
#[derive(Clone, Debug)]
pub(super) struct StaticFormal {
    pub key: BinderKey,
    pub kind: StaticKind,
}
#[derive(Clone, Debug)]
pub(super) struct Interface {
    pub module: String,
    pub ast_index: usize,
    pub kind: FnKind,
    pub statics: Vec<StaticFormal>,
    pub params: Vec<Ty>,
    pub result: Ty,
    pub premises: Context,
}

#[derive(Clone, Debug)]
pub(super) enum ObligationKind {
    Injectivity,
    ProtectedClean,
    CertifiedClean { logical: OperationIdentity },
    Provider { provider: DefId, meaning: Option<DefId> },
    MeaningEquality { required: DefId, supplied: Option<DefId> },
    TransformedMeaning,
}
#[derive(Clone,Debug)]
pub(super) enum OperationIdentity {Global(resolve::Target),Formal(BinderKey)}
#[derive(Clone, Debug)]
pub(super) struct Obligation {
    pub definition: DefId,
    pub span: Span,
    pub kind: ObligationKind,
}

/// Immutable identities and checked facts from one current original collection.
#[derive(Debug)]
pub(super) struct CheckedProgram {
    pub resolution: Resolution,
    pub interfaces: BTreeMap<DefId, Interface>,
    pub effects: BTreeMap<DefId, FunctionEffect>,
    pub lexical: BTreeMap<DefId, Arc<Table>>,
    pub obligations: Vec<Obligation>,
    pub dependency_order: Vec<DefId>,
}
impl CheckedProgram {
    pub fn interface(&self, id: DefId) -> &Interface { &self.interfaces[&id] }
    pub fn effect(&self, id: DefId) -> Option<FunctionEffect> { self.effects.get(&id).copied() }
}

#[derive(Clone)]
struct Operation { basis: Ty, meaning: Option<DefId>, access: [bool; 3] }
#[derive(Clone, Debug, PartialEq, Eq)]
struct Binding { identity: usize, ty: Ty }
struct Scope {
    naturals: BTreeMap<BinderKey, Linear>,
    bases: BTreeMap<BinderKey, Ty>,
    operations: BTreeMap<BinderKey, Operation>,
    context: Context,
    values: BTreeMap<BinderKey, Binding>,
    moved: BTreeSet<usize>,
    next_binding: Rc<Cell<usize>>,
}
impl Scope {
    fn copy(&self, budget: &Budget, span: Span) -> Result<Self> {
        let mut naturals=BTreeMap::new();for (key,value) in &self.naturals{naturals.insert(budget.key(span,key)?,value.copy_budgeted(span,&mut |span,cells|budget.sized_charge(span,cells))?);}
        let mut bases=BTreeMap::new();for (key,value) in &self.bases{bases.insert(budget.key(span,key)?,budget.copy_ty(span,value)?);}
        let mut operations=BTreeMap::new();for (key,value) in &self.operations{operations.insert(budget.key(span,key)?,Operation {basis:budget.copy_ty(span,&value.basis)?,meaning:value.meaning,access:value.access});}
        budget.charge(span,self.moved.len()+1)?;
        Ok(Self { naturals,bases,operations,context:budget.copy_context(span,&self.context)?,values:budget.values(span,&self.values)?,moved:self.moved.clone(),next_binding:Rc::clone(&self.next_binding) })
    }
}

struct Program<'a> {
    modules: BTreeMap<&'a str, &'a ast::Module>,
    resolution: Resolution,
    indices: BTreeMap<DefId, Index<'a>>,
    interfaces: BTreeMap<DefId, Interface>,
    obligations: Vec<Obligation>,
    unitary_regions: Vec<(DefId,Span,BodyEffects)>,
    budget: Rc<Budget>,
}
impl<'a> Program<'a> {
    fn decl(&self, id: DefId) -> &'a ast::Decl {
        let d=self.resolution.declaration(id);
        &self.modules[d.name.0.as_str()].decls[d.ast_index]
    }
    fn module(&self,id:DefId)->&str { &self.resolution.declaration(id).name.0 }
}

/// All original declarations are checked before returning any interface/effect.
pub(super) fn program<'a>(modules:BTreeMap<&'a str,&'a ast::Module>,limits:SourceLimits)->Result<CheckedProgram> {
    program_with(modules,limits,|_,_,_,_,_|Ok(())).map(|(facts,())|facts)
}

pub(super) fn program_with<'a,R>(modules:BTreeMap<&'a str,&'a ast::Module>,limits:SourceLimits,finish:impl FnOnce(&Resolution,&BTreeMap<DefId,Interface>,&BTreeMap<DefId,FunctionEffect>,&mut BTreeMap<DefId,Index<'a>>,&Budget)->Result<R>)->Result<(CheckedProgram,R)> {
    let budget=Rc::new(Budget {remaining:Cell::new(limits.work),limits});
    let resolution=Resolution::new_budgeted(modules.iter().map(|(name,module)|(*name,*module)),|span,cells|budget.charge(span,cells))?;
    let mut program=Program {modules,resolution,indices:BTreeMap::new(),interfaces:BTreeMap::new(),obligations:Vec::new(),unitary_regions:Vec::new(),budget};
    declarations::prepare(&mut program)?;
    let mut bodies=BTreeMap::new();
    let mut edges=BTreeMap::new();
    // Canonical DefId order deliberately does not choose declaration diagnostics.
    let mut order=Vec::new();
    for (name,module) in &program.modules {
        let owner=program.resolution.module(name).expect("registered original module");
        program.budget.charge(module.span,module.decls.len())?;
        for decl in &module.decls { order.push(program.resolution.local(owner,&decl.name.text).expect("registered original declaration")); }
    }
    for id in &order {
        let (body,dependencies)=body::check(&mut program,*id).map_err(|e|e.in_module(program.module(*id)))?;
        program.budget.charge(program.decl(*id).span,2)?;
        bodies.insert(*id,body);edges.insert(*id,dependencies);
    }
    if let Some((owner,span,_))=resolve::cycle_budgeted(order.iter().copied(),&edges,false,|span,cells|program.budget.charge(span,cells))? {
        return Err(SourceError::new("cycle",span,"recursive source dependency cycle is unsupported").in_module(program.module(owner)));
    }
    program.budget.charge(Span::default(),edges.len()+edges.values().map(Vec::len).sum::<usize>())?;
    let dependency_order=resolve::order_budgeted(edges.iter().map(|(id,targets)|(*id,targets.iter().map(|(target,_)|*target).collect())).collect(),|span,cells|program.budget.charge(span,cells))?.map_err(|id|SourceError::new("cycle",program.decl(id).name.span,"recursive source dependency cycle is unsupported").in_module(program.module(id)))?;
    let inferred=super::effects::infer_with(&bodies,|span,cells|program.budget.charge(span,cells))?.ok_or_else(||SourceError::new("effect",Span::default(),"unresolved checked effect dependency"))?;
    let mut effects=BTreeMap::new();
    for id in &order {
        let decl=program.decl(*id);
        if matches!(decl.kind,FnKind::Basis|FnKind::Meaning) {continue;}
        let fact=FunctionEffect::checked(decl.kind,inferred[id]).ok_or_else(||SourceError::new("effect",bodies[id].origin(&inferred),super::effects::assertion_error(&decl.name.text,decl.kind,inferred[id])).in_module(program.module(*id)))?;
        for (provider,span) in &bodies[id].unitary {
            if inferred[provider]!=crate::ir::Effect::Unitary {
                return Err(SourceError::new("effect",*span,super::effects::unitary_required("operation provider's inferred body effect must be Unitary")).in_module(program.module(*id)));
            }
        }
        program.budget.charge(decl.span,1)?;effects.insert(*id,fact);
    }
    for (owner,span,region) in &program.unitary_regions {
        if region.inferred_with(&inferred)!=Some(crate::ir::Effect::Unitary) {
            return Err(SourceError::new("effect",*span,super::effects::unitary_required("with_computed body must be unitary")).in_module(program.module(*owner)));
        }
    }
    let output=finish(&program.resolution,&program.interfaces,&effects,&mut program.indices,&program.budget)?;
    program.budget.charge(Span::default(),program.indices.len()*2)?;
    let lexical=program.indices.into_iter().map(|(id,index)|(id,Arc::new(index.table))).collect();
    Ok((CheckedProgram {resolution:program.resolution,interfaces:program.interfaces,effects,lexical,obligations:program.obligations,dependency_order},output))
}

pub(super) fn equivalent_types(a:&Ty,b:&Ty,context:&Context,span:Span)->Result<bool> {
    a.equivalent_by(b,&mut |a,b|Ok(context.proves_le(a,b,span,"while checking type size equality")? && context.proves_le(b,a,span,"while checking type size equality")?))
}

pub(super) fn close_type(ty:&Ty,naturals:&BTreeMap<BinderKey,u32>,bases:&BTreeMap<BinderKey,Type<u32>>,span:Span)->Result<Type<u32>> {
    close_type_budgeted(ty,naturals,bases,span,|_,_|Ok(()))
}

pub(super) fn close_type_budgeted(ty:&Ty,naturals:&BTreeMap<BinderKey,u32>,bases:&BTreeMap<BinderKey,Type<u32>>,span:Span,mut charge:impl FnMut(Span,usize)->Result<()>)->Result<Type<u32>> {
    let mut pending=Vec::new();charge(span,1)?;pending.push((ty,1usize));let mut cells=0usize;
    while let Some((node,depth))=pending.pop(){
        charge(span,1)?;if depth>64{return Err(SourceError::new("limit",span,"closed type exceeds depth 64"));}
        let n=match &node.kind {
            Kind::Parameter(parameter)=>{
                let replacement=parameter.key.as_ref().and_then(|key|bases.get(key)).ok_or_else(||SourceError::new("static",span,format!("missing Basis binding {}",parameter.name)))?;
                let size=replacement.storage_size(4096,65-depth).ok_or_else(||SourceError::new("limit",span,"expanded Basis exceeds closed type capacity"))?;
                if replacement.linear(){return Err(SourceError::new("type",span,"a Basis binding cannot contain quantum ownership"));}
                charge(span,size.nodes)?;size.nodes
            },
            Kind::Tuple(fields)=>{if fields.len()>64{return Err(SourceError::new("limit",span,"closed tuple exceeds 64 fields"));}charge(span,fields.len())?;pending.extend(fields.iter().rev().map(|field|(field,depth+1)));1},
            Kind::Q(child)=>{charge(span,1)?;pending.push((child,depth));0},
            _=>1,
        };
        cells=cells.checked_add(n).ok_or_else(||SourceError::new("limit",span,"closed type cell count overflow"))?;
        if cells>4096{return Err(SourceError::new("limit",span,"closed type exceeds 4096 expanded cells"));}
    }
    charge(span,cells)?;
    ty.map_parts(&mut |linear| {
        let mut value=linear.constant;
        for (key,coefficient) in &linear.terms {
            charge(span,1)?;
            let n=naturals.get(key).ok_or_else(||SourceError::new("static",span,format!("missing natural binding {}",key.name)))?;
            value=value.checked_add(coefficient.checked_mul(i128::from(*n)).ok_or_else(||SourceError::new("limit",span,"closed size multiplication overflow"))?).ok_or_else(||SourceError::new("limit",span,"closed size addition overflow"))?;
        }
        u32::try_from(value).map_err(|_|SourceError::new("size",span,"closed size must fit a nonnegative u32"))
    },&mut |parameter| {
        parameter.key.as_ref().and_then(|key|bases.get(key)).cloned().ok_or_else(||SourceError::new("static",span,format!("missing Basis binding {}",parameter.name)))
    })
}
