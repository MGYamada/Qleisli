# Changelog

Versions follow the versioning and compatibility policy.
The [VM plan](https://github.com/MGYamada/Qleisli/issues/276) and fixture records distinguish
development milestones from the scope of their evidence.

## Unreleased

- Share checked formal operation bases, finite Meaning payloads and explicit
  Apply/Adjoint/Controlled grants between the two declaration paths. Retain
  original binder identities, ordered kind availability, diagnostic and budget
  order; borrow sized kind environments instead of cloning whole scopes.
  Generic assumptions grant no native acceptance or arbitrary provider access.
  Common body convergence and canonical std integration remain unfinished
  (#32, #317).
- Share ordered static and runtime parameter-name checks over the original
  common AST. Preserve exact declaration/parameter association, per-argument
  type checks, complete unused-declaration rejection, capacities and existing
  profile-specific diagnostic/native order. Full declaration/body convergence
  and canonical generic std integration remain unfinished (#32, #317).
- Share actual runtime wildcard, duplicate-name and exact tuple/Unit binding
  rules between finite lowering and sized generic checking. Retain existing
  value moves, owner identities, capacity checks and diagnostic order; the
  borrowed sized pattern bridge does not complete declaration/body convergence
  or expose canonical std APIs (#32, #317).
- Share retained original source, common syntax and provenance through a private
  immutable collection. Preserve complete declaration checks, source budgets,
  diagnostic order and the fixed ordinary std registry; retain selected file
  paths without inventing in-memory manifest provenance. Common checker and
  canonical std namespace integration remain unfinished (#32, #317).
- Include #317 in the maintainer-confirmed 111-Issue scope and release gate.
  Reject prior 110-Issue candidates that omit semantic stdlib namespace criteria
  or acceptance evidence; preserve all earlier targets and historical records.
- Lower principal Iso selected-source roots through the existing fresh-zero,
  unitary hierarchy and zero-measurement readout transport, retaining quantum
  result trees, Unit-owner phase and complete caller frames. Return the single
  unnormalized coefficient vector from `run`; require a principal Observe
  entry for sampling and named QPE. Raw quantum Unit support and general source
  preservation remain unfinished; no native primitive or guarantee is added
  (#43).
  Report incompatible native hierarchy checker versions explicitly while
  retaining strict rejection of generic success and malformed response frames.
- Infer ordinary function effects from typed bodies and callees, with optional
  prefixes checked as upper-bound assertions. Reject contradictions with an
  explicit semantic diagnostic that `"externally unitary"` is unsupported,
  without Issue links. Export immutable body facts and checked documentation;
  remove redundant prefixes from ten derived stdlib functions while preserving
  mathematical contracts, source bodies and native acceptance (#315).
  Apply the same semantic explanation to host-selected providers, preserve
  independent shape errors, and teach ordinary `fn` in provider/parser hints.
- Add bounded opaque Basis parameters and explicit exact type/provider bindings
  to the common selected-source path. Check generic bodies before specialization,
  preserve exact trees in caches and charge retained substitutions; general
  Meaning refinement and final directory-profile integration remain open (#44).
  Migrate the active sized forwarding fixture to the adopted ordered-kind rule,
  retaining its original failure and forward-reference rejection coverage.
- Include #315 in the maintainer-confirmed 110-Issue scope and release gate.
  Reject prior 108/109-Issue candidates that omit the added criteria or evidence;
  ordinary-source effect inference and stdlib migration remain required work.
  Preserve the frozen scope records' bytes during whole-tree whitespace checks.
- Keep the non-UTF-8 CLI regression aligned with the current usage/discovery
  contract while retaining historical help fixtures. Clarify the current v5
  guarantee ledger and pending exactness supplement in contributor guidance.
- Add standalone text help and an embedded canonical ecosystem discovery
  chapter. Route usage failures to the same introduction, distinguish familiar
  structure from native/specification-only concepts, and expose planned tool
  status without executing a project or checker (#253).
- Name missing and unexpected explicit Nat/Op bindings, affected providers and
  ordered source-call static parameters in deterministic diagnostics. Preserve
  rejection priorities, locations, explicit provider choices and the
  uniqueness/no-physics inference law (#100).
- Document the architecture principle "Policy as Theorem. Constitution as
  Harness. Compiler as Executor" and its human/proof/execution separation,
  fail-closed boundaries, diagnostic recovery and future design review (#254).
- Admit exact packaged quantum tuple bases and explicit binary `split`/`join`
  in the selected hierarchy, preserving nested trees, ordered axes and linear
  owners. Compose explicit Unit unitors without losing scalar phase or retained
  reference correlations; bind lowering to the existing structural rules and
  charge retained recursive frame types to the trace storage budget (#43).
- Update the primitive-omission calibration to the current catalog macro so
  it reaches exhaustive-handler checking instead of failing at macro parsing.
- Expose explicit `unit(())` and `finish(q)` maps on the common hierarchy
  path, preserving exact Unit owners, scalar phase and complete argument
  evaluation through existing checked structure (#43). Finite/Raw support
  remains separate unfinished integration work.
- Require constitutional state to be reread and checked at agent startup and
  after model/session/context changes. Preserve adopted human decisions,
  pending obligations and paused work across handoffs.
- Admit exact `Q<Unit>` and `Op<Unit>` in the common selected-source projection,
  preserving zero-width ownership separately from ordinary Unit and Bits(0).
  Carry the existing scalar `phase_eighth` through checked hierarchy structure,
  including adjoint, repetition and control (#27, #32, #43).
- Include #311 in the maintainer-confirmed 109-Issue release scope and progress
  denominator. Require its criteria and evidence in release readiness; preserve
  the original 108 targets and historical validation records (#142).
- Record the Guardian's adopted EXACT-2026-01 interpretation: epsilon error
  bounds cannot replace edition-2026 exact QS, PR or RS obligations. Preserve
  the Constitution, three original interpretations, two admitted guarantees
  and current evidence; protect the additive ledger-v5 transition and pending
  release disclosure. Read actual pending-ledger identities in the release
  gate instead of the incompatible test-only row shape, and bind receipts to
  the exact ledger bytes returned by verification (#311, #142).
- Connect explicit module/entry source selection and the legacy `sized`
  adapter to one CLI execution plan. Select Raw or hierarchy before native
  checking, preserve independent requests and reject unsupported invocations
  without falling back after a failed check. Keep source/native check scopes
  explicit; final frontend convergence and open runtime invocation remain
  unfinished (#32, #250).
- Share ordinary Boolean type checking, eager operand evaluation and Raw
  instruction emission across finite and sized source preparation. Add a
  source-bound Unit/Bit/Q<Bit>/product Raw proposal and independent step replay.
  Share physical register state and primitive transitions for mixed calls,
  measurement postprocessing and exact eighth-turn phases, preserving pending
  owners and caller entanglement. General physical target capabilities remain
  unfinished (#32).
- Accept exact ordinary function parameter patterns through the common parser
  and finite/sized checking. Keep whole argument types, source arity and effects;
  reject duplicate names and implicit quantum-owner discard (#32, #43).
- Restrict native round-trip compilation to current corpus provider roots,
  preserving migration archives as history. Select an explicit canonical
  bare-CR diagnostic input while retaining its original bytes (#27, #32).
- Match ordinary `Unit` with `()` in finite let and basis patterns using the
  same exact shape rule as sized checking. Preserve effectful computations,
  quantum owners and scalar phase; reject other zero-width types (#43).
- Select explicitly migrated Qleisli fixtures in external-format and Lean
  comparison clients while retaining original source hashes and independent
  format, phase and probability checks (#27, #32).
- Preserve the exact routed-control experiment as in-memory source evidence;
  distinguish its unused historical manifests from schema-2 filesystem admission
  instead of rewriting recorded inputs (#303).
- Check scoped release readiness from a reviewed criterion base, complete
  evidence and exact same-run CI receipts/artifacts. Preserve pending broader
  obligations and require real replay of admitted guarantees; missing inputs
  reject. Tagging and publication remain separate (#142).
- Remove owned distribution build work after success or failure while keeping
  reports, logs and candidate archives. Add `--keep-work` for debugging and
  preserve caller-owned external Cargo targets (#142).
- Use canonical ordinary `Unit`, `Bit`, `Bits<n>` and `0`/`1` through common
  source type classification. Reject retired classical spellings with migration
  diagnostics; migrate active clients and keep explicit historical translations.
  Sized Unit values and empty patterns preserve executed operations while
  omitting only ordinary Unit ports. Public type kind accessors now require
  `is_quantum()` to distinguish ownership (#22, #27, #43).
- Retain immutable corpus authoring records across source migrations, checking
  ordered predecessor hashes, complete project snapshots and source-bound
  observations. Record the six predicate-domain migrations and their original
  provenance-check failures without rewriting earlier trials (#25).
- Prove exchange of original hierarchy entry bodies with their distinct routed
  control/target frames, same-artifact typing, fresh wiring summaries and
  computed two-sided inverses. Retain exact provider and evaluation premises,
  arbitrary reference amplitudes, and valid noncommuting/output-route
  counterexamples; source access rules remain separate (#303).
- Require one explicit, exact basis-domain parameter for both forms of
  `with_computed`; reject nullary and multi-parameter predicates without
  implicit tuple packing. Preserve ordinary call arity, noninjective predicates,
  ordered truth tables and controlled Unit phase. Migrate active examples,
  standard-library code and corpus clients, retaining historical sources with
  explicit current translations and bounded semantic comparisons (#25).
- Check every supported ordinary declaration in sized modules, including
  private and forward siblings and unused bodies. Preserve distinct definition
  identities, public host-entry visibility, decreasing self-recursion and
  rejection of mutual call/provider cycles (#32).
- Resolve local, basis, static-natural and static-operation bindings through
  common structural identities in both finite compilation and sized checking
  and elaboration. Preserve dynamic ownership, source diagnostic order,
  public Send/Sync and retained proposal bytes (#32).
- Restore contextual type words such as `Q` and `Op` as static natural names
  in the shared parser, including comparisons, dimensions and specialization;
  preserve ordinary runtime and operation-binder keyword rules (#32).
- Keep the native round-trip fixture recorder warning-free under the actual
  Rust 1.85 Clippy toolchain while preserving its emitted proposal bytes.
- Separate append-only admitted guarantee identities from current evidence in
  ledger schema v4. Require explicit admission registrations, exact verifier
  coverage, trusted-base continuity and stable snapshots during replay; retain
  the two scoped guarantees and three pending broader obligations (#135, #141).
- Prove exact exchange of shared coherent-control operations on disjoint ordered
  target factors, connected to the existing hierarchy tensor/control/sequence
  meanings and arbitrary reference amplitudes, including zero-width phase.
  This is a local proof component, not a source access or reordering rule (#303).
- Align the retained finite-profile corpus regression with the shared parser:
  static `Nat` parameters parse once, then reject as unsupported with the exact
  parameter span. Preserve the original source and historical diagnostics (#32).
- Check current-artifact continuity for the two admitted QLV1 guarantees against
  an elaborated historical baseline. Allow unchanged-meaning formatting and
  theorem proof maintenance, reject witness/decoder weakening and concurrent
  evidence replacement, and preserve the original human admission (#141).
- Share declaration identities, import visibility and dependency graph traversal
  across finite compilation and sized checking/elaboration. Retain existing
  profile differences, canonical evidence names and provider identities; local
  owner scopes and the final source cutover remain separate (#32, #41, #65).
- Prove adjacent protected literal phases commute on arbitrary joint/reference
  states, and connect both successful executable matrix checks to identical
  complex entries and actions. Retain shared-control and zero-target examples
  plus a noncommuting phase/X counterexample; general access rules remain open
  (#303).
- Quote generic type notation in API documentation so strict packaged rustdoc
  generation succeeds after the common type refactor.
- Share exact type trees, structural comparison and linear-owner classification
  across finite, symbolic-sized and concrete-sized checking. Preserve existing
  source profile restrictions, capacities and public type accessors; ordinary
  Bit/Bits surface migration remains separate (#27).
- Prove that the encoded native-contract wrapper computes the original root's
  exact matrix, including zero-width phase and ordered axes. Connect actual
  byte acceptance to the original `BodyMeaning` and encoded equation for any
  reference amplitude function; preserve existing guarantee admission scopes.
- Specify closed specialization, exact forward realization, workspace and
  quantitative resource boundaries in the Language Reference (#120, #127).
  Distinguish actual target evidence from synthesis completeness and from the
  existing bounded export checks.
- Parse finite and sized source with one grammar and recursive AST. Project the
  shared AST into the existing sized checker and reject unsupported finite forms
  before lowering. Preserve bounded source/proposal comparisons, explicit profile
  limits and diagnostics for reserved words and documentation migration (#32).
- Forward the required product version through dynamic preparation/readout
  transports and require their native regression checks in CI (#289).
- Expand small accepted-artifact round trips to nested shared circuits,
  compute/uncompute and both conditional branches, comparing actual cached
  matrices with independent exact oracles. Require this suite in CI (#288).
- Require the expected exact basis tree in `FunctionEvidence::check_binding`,
  rejecting same-width tuple and Unit substitutions inside the attachment API.
  Migrate Rust callers and native comparison harnesses to the complete check
  without changing native acceptance or evidence construction (#265).
- Specify the 0.3.0 target ordinary/quantum type boundary, Bit literals, exact
  tree equality, zero-width owner phase and explicit generic responsibilities.
  Record these ordinary design choices separately from implementation and
  retain the operation/Meaning calculus as a reviewable design candidate.
- Share physical source scanning between finite and sized frontends, preserving
  original UTF-8 spans, contextual token adapters and existing capacity limits.
  Sized comments now follow the same control-character and whitespace rules;
  retain old/new diagnostics and proposal comparisons for the migration (#32).
- Record the human ratification of the edition-2026 Constitution and adoption of
  governance, effective 2026-10-04 (Asia/Tokyo), appointing Masahiko G. Yamada as
  initial Guardian. Preserve the exact approved hashes, human reply, Draft 5,
  candidate diff and pre-existing alpha baseline. Add ratified identity checks
  and a bootstrap guarantee ledger; no QS/PR/RS interpretation or proof discharge
  is implied by ratification. Document the authority hierarchy and prepare the
  initial interpretation candidates for a separate human decision.
- Record the subsequent explicit Guardian adoption of QS-2026-01, PR-2026-01
  and RS-2026-01 as binding pending obligations. Preserve the exact reviewed
  packet and human answer separately from proof discharge.
- Record the subsequent human adequacy judgment and admission of two scoped
  QLV1 guarantees: original-root ownership and classical scope. Preserve their
  reviewed meanings and historical evidence separately from current proof and
  source binding; the three broader QS/PR/RS obligations remain pending.
- Protect the admitted semantic dependency closure and elaborated acceptance
  witness fields in constitutional CI. Retain a compiled witness-weakening
  counterexample and reject it even after mutable source hashes are refreshed.
- Prove actual native encoded/leaf-contract acceptance-to-root-meaning bridges
  without changing executable acceptance. Preserve explicit limits on encoded
  wrapper correspondence and distinguish these proofs from ledger admission.
- Inventory 21 current production paths and nine native modes, distinguishing
  fresh acceptance, hierarchy/component checks, proposal generation and host
  execution. Bind their references to tests and actual source entry points.
- Rename the ownership-only Lean predicate and checker-facing theorems from
  `ResourceSafe` to `OwnershipSafe` under #287, preserving their mathematical
  content and acceptance behavior. Ownership and clean return belong to QS;
  quantitative Resource Safety remains a distinct pending obligation.
- Track the 108 selected 0.3.0 issues through a GitHub milestone and the existing
  release-readiness umbrella. Edition identifies the constitutional regime;
  the syntax/frontend migration remains within edition 2026.
- Pin the external mdBook documentation tool to 0.5.4 with an official binary
  checksum in docs CI; add a minimal book and document its separation from
  Qargo, language acceptance and Qleisli API documentation.
- Move existing documentation into ordinary mdBook chapters under `docs/src/`,
  remove the former files and update source/build references. Each chapter is
  maintained in one place while the new tutorial is prepared.
- Select `0.3.0-alpha` for the Rust, Lean, Python and standard-library product
  versions and prepare version maintenance and native archives for prereleases.
  This is prerelease preparation; the v0.3.0 type-system goals remain open.
- Complete the planned documentation cleanup: delete `docs-old/`, retain
  imaginary-v1 and the Lean backend plan in `docs/src/`, and write new chapters
  from adopted decisions, code and proofs.
- Require an explicit matching product version in every native kernel mode;
  update direct tests, forwarding shims and relocated bundle checks (#289).
- Bound JSON prescan allocation by scanning the input string directly, retaining
  only bounded keys and bare tokens while preserving native protocol validation
  and duplicate-field rejection (#290).
- Add accepted-artifact round trips and recursive function/meaning evidence
  matrix comparisons, including explicit QIRF2 meaning entries (#288).
- Avoid cloning untrusted function-evidence inputs before bounded transport
  validation, and retain parsed command names in CLI JSON with leading options.
- Preserve empty classical-unit boundaries in sized-source compaction without
  dropping zero-width quantum owners or their scalar phases.
- Limit shared prerelease selectors to stable, alpha, beta and rc forms whose
  Python normalization preserves release ordering; keep `0.3.0-alpha` unchanged.
- Select full proof replay and schema binding when either Lean audit changes.
- Replace repeated quadratic history-subset scans with a proved-equivalent
  linear fast path for growing histories, addressing the classical-constant
  timeout reproduced under #278 without changing native decisions or work counts.

## 0.2.9 — 2026-10-04

Published to crates.io and GitHub with macOS arm64 and Linux x86-64 native
checkers. [Publication evidence](tests/fixtures/releases/v0.2.9/publication.json)
binds the checked commit, full CI, fresh installation and public downloads.

- Migrate the retained research raw-IR adapter to native acceptance and make
  foreign/Python comparison tests bind both environment and per-call selection
  to the requested checker, including CI jobs without an inherited kernel path.
- Repair distribution CI follow-ups: retain QIRF envelope pointers after native
  rejection, update diagnostic/work expectations, isolate nested CI output paths,
  and keep QPE response-fault tests on the intended protocol while finite leaves
  use the real checker. Record the stricter public QIRF limits separately from
  component-level comparison results.
- Prepare native checker distribution archives for macOS/Linux with SHA-256
  files, retained runtime licenses, installation instructions, exact source
  commit binding and required fresh Lean replay. Full CI retains the candidates;
  publication remains a separate step after all checks on that commit succeed.
- Close remaining simulation copy-budget gaps: charge classical and quantum
  branch phi metadata, including empty owners, and reserve projection copies
  before visible or hidden sampling observations consume randomness.
- Repair v0.2.8 bug reports #257–#271: account for retained outer ensembles and
  classical-state copies; bound source discovery and parse each manifest once;
  anchor Unix qrate traversal in held directories and reject mixed-case `target`;
  isolate documentation comments, handle closed stdout, preserve closed v1 JSON
  codes, and distinguish malformed circuit shapes from capacity or equation
  failures. Regressions cover mainless library checks through the native route.
- Share finite/hierarchical native process transport. Unix uses nonblocking pipes
  without detached IO threads and terminates the invocation's process group.
  Windows process-tree containment remains open in #268; no cross-platform
  containment claim is made. Deferred #275/#278 work remains targeted at v0.3.1.
- Add the requested v0.3.1–v0.3.9 Lean backend expansion plan, including
  input/output preservation gates, staged Rust retirement and compatibility
  prerequisites. This plan and the entire `docs/imaginary-v1/` tree are the
  only two exceptions retained across the v0.3.0 docs cleanup boundary.
- Complete the approved v0.2.9 implementation switch to Lean-only acceptance
  (#276). Delete `src/verify.rs`, `VerifiedProgram`, the root `verify` API and
  `interchange::dual`; use immutable `Proposal` / `AcceptedProgram` and native
  `Kernel` APIs. CLI, Rust, Python, foreign formats and finite contracts now
  require a matching native checker. Cargo builds/docs still require only Rust.
- Reconstruct retained function-evidence DAGs from native-accepted bytes, retain
  exact source/type bindings and shared dependencies, and route encoded equations
  and complete finite-leaf requests to existing Lean checkers. Keep counterexample
  diagnostics outside acceptance. Full supported-profile Soundness remains v0.5.0.
- Require explicit checker selection and matching product versions; reject missing,
  failed or incompatible runtimes without discovery, download or Rust fallback.
  Retain audited relocated bundle packaging and require a kernel for runtime CI.
- Preserve the original 799 Rust/Lean comparison inputs and decisions; replace
  the obsolete two-verifier generator with replay through the sole native route.
  Native QIRF graph/JSON/time bounds and per-decision work now also constrain raw
  Rust APIs. Shared compiler budgets charge every fresh native decision. Former
  large Rust stress cases can exceed these bounds; they remain retained and
  deferred, with repeated native invocations/batching tracked in #274.
- Separate untrusted serialization from acceptance, bound raw transport before
  recursion, and remove redundant export/import round trips in selected paths.
- Prove classical scope safety and global SSA uniqueness from actual ordinary
  native packet acceptance, including both arms and simultaneous phi inputs.
  Full-profile soundness remains the v0.5.0 milestone; #276 advances the
  implementation-authority migration to v0.2.9.

- Preserve incomplete/failed corpus reports with completed results, diagnostics
  and exact input hashes; reject changed inputs and return failure honestly.
- Check maintained Markdown across the repository, including Python and CI;
  reject retired reference/HTML/web links and remove dangling prose references.
- Compile native test drivers through one shared kernel-library build per CI
  run, retaining independent execution and source/product mutation checks.
- Add a reviewed version/source-binding maintenance command and a checked VM29
  public-path inventory with explicit blockers and legacy-removal gates.

- Add nine small translations from the unchanged QuantumKatas, Qualtran and
  PennyLane pins (78 to 87), with preserved first attempts, full complex-entry
  comparisons and nine additional type-correct semantic faults (54 to 63).
- Delete the completed v0.2 migration-plan document; retain imaginary-v1 and the new v0.3 backend plan in `docs/`;
  move other documents to temporary `docs-old/`, to be deleted at v0.3.0.
  Remove retiring-document links and their generated-status/template-linter
  dependencies, retaining metadata, source, semantic and proof checks.
- Select development version 0.2.9 across Rust, Lean, Python and the std qrate.
- Add CLAUDE.md with the same working rules as AGENTS.md; check byte-for-byte
  equality and the 100-line / 6,000-byte limit for each in documentation CI.
- Rename the trust policy to [TRUSTBOUNDARY.md](TRUSTBOUNDARY.md) and update
  current links and protected CI paths. Record the separately approved #276
  implementation-scheduling amendment without changing the trusted partition.

## 0.2.8 — 2026-10-03

- Repair GitHub review findings: retain qrate directory identity across loading,
  restore search-only ancestor access on macOS 11+ and listed Linux targets,
  locate source load/limit diagnostics,
  keep interop JSON codes within v1, bind Python's QIR reader to its installation,
  reject unused QIRF sources natively, and bind CI execution to the checked
  toolchains and an explicit environment. Clarify terminal allocation ordering
  and check bundled source documentation references and Python README versions.
  Older macOS keeps its existing descriptor walk/read requirement; a runtime
  Darwin-version gate avoids newer flags on the unchanged deployment targets.
- Partially advance #223: propagate CI lanes to native bundle builds, retaining
  builds/audits/relocated tests in every lane and fresh replay in `full`.
  Record performed replay and command timings; reject unknown lanes and keep
  full validation as the standalone default. Driver consolidation and hosted
  shadow/performance validation remain open.
- Prove independent linear ResourceSafe for all 19 ordinary raw constructors,
  both branch arms, local axis bounds, scratch freshness and complete Unit/phi
  returns. Connect actual raw/QIRF/native acceptance to the judgment and retain
  optional finite semantics. Full EffectSound and hierarchical S05 remain open.
- Refactor native QIRF acceptance into typed stages with named refinement
  contracts. Prove compatibility for every input/work budget and compose the
  actual packet checker with independent original-body finite semantics and
  reference laws; full effect/hierarchical S05 obligations remain open.

- Add opt-in Rust/Lean dual checking to ordinary check/run/sample/emit-ir/verify-ir
  and `interchange::dual::Kernel`. Native checking receives the original QIRF
  and optional independent request; either rejection or transport failure blocks
  execution/emission. Add actual-checker lemmas, small differential/fault tests
  and fresh audited native bundles; S05 and full migration remain open.
- Reduce tracked `docs/` UTF-8 bytes by approximately 54% from the current 0.2.7
  checkout; retain active plans, their acceptance gates and imaginary-v1.
  Retire detailed specification files with fixed-release references, preserving
  language contracts and the four quick-reference executable programs as fixtures.
- Add nine finite translations from the unchanged QuantumKatas, Qualtran and
  PennyLane inputs (69 to 78), first-source diagnostics, independent full-entry
  complex comparisons and nine paired semantic faults (45 to 54).
- Synchronize Rust, Lean, Python and std qrate to 0.2.8; edition 2026, Rust
  authority, external-schema gates and theorem scope remain unchanged.

Published to crates.io and GitHub; [release evidence](tests/fixtures/releases/v0.2.8/publication.json)
binds the checked commit, full CI, package, fresh installation and source downloads.

## 0.2.7 - 2026-10-03

Published to crates.io and GitHub; [immutable validation and installation evidence](tests/fixtures/releases/v0.2.7/publication.json).
The candidate was selected on 2026-10-02; publication completed on 2026-10-03 (Asia/Tokyo).

- Fix finite Pair/nested tuple reconstruction (#207), retain named-QPE host
  fault checks in CI (#208), reject run_elab/run_meta in kernel policy (#209),
  and validate corpus attribution by its actual upstream source (#210).
- Diagnose local-only value calls at the callee rather than as missing imports
  (#211); prevent sized proposal output from overwriting files or following
  destination symlinks (#212); keep unused-manifest warnings host-independent
  with stable ancestor-manifest locations under --qrate (#214).
- Prove actual native QIRF graph/root complex and reference semantics; discharge
  every finite leaf, independent request pair and phase-fixed H body. Add all-field
  Rust/Lean decoder comparisons (362 cases), align eight QIRF wire integer bounds,
  and extend whole-hierarchy/named-QPE reference coefficient tests. General
  analytic reader-to-Operator closure and universal decoder/compiler proofs remain open.
- Move original QIRF1/2 leaf graphs, finite-request equality and phase-fixed H
  to native Lean checking for hierarchy/Fourier/instrument/QPE reports. Add
  native-only experimental APIs; retain independent bounded native work and
  Rust sealed-handle reconstruction for compatible executable reports.
  VM-27 closure and production authority transfer remain open.
- Adopt test-oriented routine CI (#223): native builds/audits and all retained
  comparisons, separate changed-model proof compilation, full fresh replay
  for release/tag/manual full and policy-risk inputs. Reuse #206's bounded
  native runner and exact source/toolchain/coverage records.
- Select development version 0.2.7 across Rust, Lean, Python and the std qrate.
- Reduce current documentation by approximately 55% in tracked UTF-8 bytes while
  preserving plans and imaginary-v1; consolidate repeated contracts and retire
  historical narrative with repaired links and regenerated status views.
- Add nine small translations from frozen QuantumKatas, Qualtran and PennyLane
  inputs (60 to 69), complete first-source diagnostics, independent full-entry
  phase/order checks and nine paired semantic faults (36 to 45).

## 0.2.6 — 2026-10-02

Published to crates.io and GitHub; [immutable validation and installation evidence](tests/fixtures/releases/v0.2.6/publication.json).

- Synchronize Rust, both Lean packages, Python and the std qrate to 0.2.6.
- Extend the independent Lean boundary to all raw constructors, observing
  operations, classical SSA and complete branch phis. Prove CP/TNI and total TP
  from actual matrix-free coefficients refining original complex actions;
  bind freshly reconstructed functions including closed classical branches.
- Reduce active docs while preserving current contracts, v0.2.x plans and
  evidence outside docs; historical lookup uses Git history (#48).
- Add six small finite translations from the same three frozen input sources,
  with first-source records, full complex-entry oracles and six semantic faults.
- Replace AGENTS.md histories and repeated specifications with working rules;
  enforce a 100-line, 6,000-byte limit in the documentation check.
- Remove duplicate branch-push/PR CI runs, cancel superseded ordinary PRs and
  select docs-only checks conservatively while preserving all required contexts
  and exact-source release validation (#145).
- Repair review bugs #180, #182–184 and #187–189: scope tuple hints to direct
  lexical names, restore canonical JSON root validation and
  manifest locations, accept leading `./`, warn on ignored non-table metadata,
  correct doc usage and reject reversed inventory markers without rewriting.
- Remove host paths from tuple-owner messages (#186), preserving public
  diagnostic types and the existing structured primary location.
- Require exact failure framing in every Lean runtime mode, including nonzero
  process exits (#193); no checker authority or acceptance semantics change.

Validation and publication are retained in the immutable release record.
VM-26 is checked; VM-27–29 remain open. Production acceptance remains in Rust.

## 0.2.5 — 2026-10-02

Published to crates.io and GitHub on 2026-10-02 (Asia/Tokyo), following
authorization on 2026-10-01. Exact-source validation and publication outcomes are recorded in the
release record.

- Repair 0.2.4 review findings (#160): fold exact terminal phase words, export
  negative controls and controlled H/phases, and represent bit-axis permutations.
  QFT2/QFT3 now export with explicit clean synthesis workspace counted against
  the target cap; public IR and production verifier rules remain unchanged.
- Add opt-in declared qrate source-root selection and unused manifest-key warnings.
  Improve public-module import hints, nested register-pattern actual types and
  quantum tuple binding locations. Document finite user composition contracts.
- Generate the current corpus inventory from manifests and remove fixed current
  per-source census assertions while retaining provenance, licenses, authoring
  coverage and historical validation identities. Track breaking phase/cost IR
  and wider type/pipeline/theorem obligations in their versioned Issues.

- Replace macOS source loading's `O_NOFOLLOW_ANY` dependency with held-parent
  `openat`/`O_NOFOLLOW`, preserving the existing deployment minimum and rejecting
  source/parent symlink replacements and FIFOs; add macOS/MSRV CI (#146).
- Align crate-level documentation links with the selected package version and
  check package-facing version pins in the documentation linter (#147).

- Synchronize release version 0.2.5 for compatible internal refactoring;
  synchronize Rust, the lockfile, both Lean packages, Python and the std qrate.
- Share CLI source checking, compilation, reference execution and seeded
  sampling between text and JSON output. Consolidate canonical decimal argument
  parsing and sample-result JSON transport; separate sized argument validation
  from its checking/execution adapter. Preserve public contracts and limits.
- Separate finite numerical state management from deterministic circuit
  execution; share ordered wire-axis lookup within the simulator. Encapsulate
  static circuit flattening state and unify checked logical-circuit emission.
- Consolidate explicit QIRF record/enum field maps and bounded integer codecs;
  separate operations and evidence transport. Extract strict native hierarchy
  response/process handling and share final reconstruction-report assembly.
  Retain exact field order, diagnostics, work accounting and independent checks.

- Share Lean conditional transitions, finite/ordinary dispatch and invariant
  proofs while preserving existing public declarations and successful/failing
  results. Name existing hierarchical capacities once, share equality-field
  accounting and replace deeply nested proof projections with named facts.
- Separate Lean protocol/CLI modules, sharing strict framing and IO/error
  handling. Extend source/import and compiled-origin audits and registry source
  binding to every transport submodule; keep pure reference/checker boundaries.

Earlier development checks and remaining gates are recorded in the
0.2.5 release record.

- Retire 17 obsolete docs and condense repeated specification/proof/plan prose;
  retain current contracts, goals, migration gates and executable evidence.
  Historical links use the exact pre-cleanup Git revision (#48).
- Expand the finite corpus from 48 to 54, eighteen cases per approved source:
  CZ/Toffoli, inclusive/strict comparisons, mixed-sign rotations and a two-wire
  QAOA mixer. Preserve first sources, the actual CZ repair, frozen provenance
  and six new valid-source semantic counterexamples.
- Move pure raw ownership/effect checking and bounded actual-body extraction
  into the Mathlib-free Lean kernel. Cover eleven straight-line constructors,
  retained raw body pairs and both compute forms; prove actual structural,
  reference/matrix and finite zero-return laws. Prove every constructor's
  extraction agrees with an independent original-operation trace, including
  output order and matrix spaces; prove literal local embedding coefficients.
  Complete independent complex raw action, non-dense protected zero return and
  exact retained signature/body/name/source binding with fresh dependency graphs
  and published capacity limits. Add native Rust/rational/source, 180 trace and
  146 attachment/capacity comparisons. Evaluate protected coefficients directly
  without imposing a combined data/auxiliary dense-width restriction on functions.
  Production Rust authority, VM-26–29
  integration and general source soundness stay separate.

## 0.2.4 — 2026-10-01

Publication authorized on 2026-10-01; outcomes are recorded in the
release record.

- Add sealed `s`, `sdg`, `tdg`, `id` and `phase_eighth` aliases using existing
  finite IR (#130). Remove two private QFT wrappers and modernize ten active
  corpus kernels; retain exact phase, original source attempts and VM-22 pins.
- Clarify realizability with backend workspace and resource/layout obligations
  (#120), preserve exact determinant/parity counterexamples, and specify future
  generic-contract/pipeline consolidation (#131) and LiftBasis synthesis (#132).
  Correct the quick reference version and explain branch wire-ID renaming.

- Track the root Cargo.lock to retain the compiler/CLI dependency resolution.

- Fix manifest symlink/non-file rejection before platform opening (#116),
  sized entry/provider visibility bypasses (#117), and execution-only `--basis`
  handling in `sized check` (#119). Document and diagnose the existing Linux
  procfs source-loading requirement without weakening no-follow protection (#118).

- Move VM-24 finite circuit reconstruction, canonical matrix descriptions and
  phase-sensitive encoded equations into the Mathlib-free Lean kernel. Prove
  actual column traces, arbitrary-reference action, clean encoding return and
  whole-space inverse laws. Freshly check dependencies and independent root
  requests; add native Rust/rational comparisons and adversarial CI checks.
  Production Rust authority and later raw-IR/transport gates remain separate.
- Expand the finite corpus from 42 to 48 cases, sixteen per approved source:
  negative-control X, exact Bell ZX, modulo-four decrement, one-address QROM,
  and RX/RY at negative quarter turns. Preserve first attempts and six new
  type-correct semantic faults; no new stdlib API or acceptance rule.
- Remove the redundant quantum-bookkeeping design narrative, shorten completed
  0.2.2/0.2.3 reports and retire historical roadmap entries. Delete the obsolete
  Physlib environment report, keeping its current dependency gate in the Lean
  README. Condense hierarchy component histories and duplicate proof summaries;
  retain current contracts, v0.2.x goals, proofs and validation fixtures.
- Synchronize compiler, Python host, both proof packages and bundled std qrate
  to 0.2.4. Edition 2026, Rust 1.85 and dependencies remain unchanged.

## 0.2.3 — 2026-10-01

- Introduce Qleisli edition `"2026"`, declared explicitly in each source tree's
  schema-2 `Qargo.toml`. Filesystem source loading diagnoses missing, invalid
  and unsupported editions. The README quickstarts include the migration form.
- Give the `std` qrate in `stdlib/` its complete qargo-compatible manifest;
  put edition-only manifests in corpus, examples and test trees. All source
  trees will migrate to qrate management. [Issue 96](https://github.com/MGYamada/Qleisli/issues/96)
  records the user's narrow PATCH exception for the manifest requirement.
- Synchronize the compiler, Python package, both Lean packages and bundled
  library to 0.2.3.
- Expand the finite corpus to 42 cases, fourteen per approved source, with
  phase/order checks and six new semantic counterexamples on small systems.
- Retire eleven completed reports from `docs/` and shorten authoring feedback.
  Current goals and verification plans remain available until the v0.3 rewrite.
- Complete VM-23's actual Lean scalar/matrix meaning, canonicality, reference,
  capacity and aggregate-work proofs, with 815 native compatibility comparisons.
  The [packet](tests/fixtures/verification_v023/README.md) records the exact scope.
- Report the verification request and execution authority on every sized CLI
  result (#92). Use one sized primitive signature catalog (#93) and retain
  source spans on arithmetic and solver-limit diagnostics (#95).
- Recognize QFT traces across commuting gate reorderings and factor root
  definitions, preserving original source, phase, axes and output ports.
- Reduce redundant primitive and Fourier routing in generated IR. Named QPE
  `(1,3)` now checks with both tested QFT schedules under the existing budget.
- Diagnose forbidden `with_computed` captures separately from consumed owners,
  with a concrete `join`/data-binder repair hint.
- Preflight sized lowering root signatures with an additive API and precise
  diagnostics. Support complete multiple-input transparent quantum providers,
  including the arithmetic corpus; require GHZ's positive-width premise.
- Compare Rust/Python sized sources in CI, repair static comparison parsing,
  and retain the explicit generic-versus-concrete size-checking scopes.
- Fix the interop test harness's stdin race. Add 4,000 deterministic finite/sized
  ownership comparisons and independent small-system corpus/QFT regressions.
- Clarify LiftBasis wire identity, classical-indexed Unitary semantics and finite
  register invariants. Native failure diagnostics name the selected check and
  capacity allowance.
- State the GitHub policy: **Issues track implementation. Discussions determine
  the language.**
- Preserve three AI-generated logo concepts for v0.4.0 discussion in
  [assets](assets/logo-concepts/v0.4.0/README.md), with the original commit history.

The release record and
status ledger hold validation and proof status.

## 0.2.2 — 2026-09-30

Compatible corpus, verification preparation and bounded source/QPE additions.
Publication results are recorded separately in the release record.

- Bound grouped-import prefix copying per module before allocation, including
  nested groups and separate `use` items. Check both identifier count and name
  bytes, and bound repeated documentation before cloning. Render each documented
  group once, preserving existing ungrouped paths; add amplification,
  exact-boundary, diagnostic-span and compatibility regressions.

- Adopt **docs/ cleanup boundary at v0.3.0**: retain active v0.2.x goals and
  migration plans, aggressively retire obsolete documentation now, and write
  v0.3.0 documentation from scratch after removing the remaining legacy files.
  Delete old release/review/decision/conformance pages, the backlog and generated
  status history; use Git history for lookup. Executable evidence stays intact.

- Resume the deferred measured-QPE feature track with fresh-zero/readout
  checkers, recursive corpus helpers, measured clients and a composed Lean/Rust
  host that discharges exact finite obligations. Prove conditional full branch
  matching, actual zero-input branch columns and instrument completeness/reference
  trace preservation under finite-leaf unitarity and meaning premises using
  independent reference modules. Add actual routed controlled-power matching
  with an explicit provider equation premise.
- Preserve inverse subgraphs and phase/owner structure in untrusted compaction.
  Reuse checked typing and remove repeated root/component work charges without
  changing acceptance predicates or increasing limits. Composed QPE `(1,3)`
  passes at 1,268,842 structural units and `(2,4)` at 1,920,516 through
  the Python-produced generic composition. Named QPE checks retain a separate
  `(2,4)` limit rejection under the unchanged 2,000,000 allowance.
- Add checked hierarchy reference execution with explicit memory/work limits,
  actual finite leaves and complete measurement branches. Fresh-shot sampling
  explicitly normalizes input, charges each execution and returns conditional
  residual/reference states; seeded order/amplitude clients use actual outcomes.
  Add bounded Rust sized-source preparation/lowering and an additive sized CLI.
  Named QPE checking binds an independent provider request, actual circuit trace
  and measurement order, with exact finite/provider/H discharge. Actual Kraus,
  reference and classical-result theorems retain explicit correspondence and
  specification premises. Small source/CLI and measured-client checks pass;
  general source/runtime correspondence and release gates remain separate.

- Implement VM-22: freeze acceptance constructors/APIs, boundary requests,
  coefficient interpretations and capacities; retain simple corpus additions.
  Add small phase-sensitive finite/source/native/hierarchy comparison fixtures,
  independent complex/word oracles and CI drift/mutation checks. Preserve Rust
  authority and Rust-only installation; later Lean replacement remains pending.

- Fix #55: use LLVM block identity for optional QIR import, accepting unnamed
  and mixed acyclic chains while retaining cycle/unvisited-block rejection.
- Fix #56: retain QIRF diagnostic pointers and OpenQASM source spans in interop
  JSON, consistently through Python; add text/bitcode and location regressions.
- Reduce docs before Reference consolidation (#48): delete five superseded
  plans, compress repeated roadmap/backlog/status reports and retain unique
  contracts, source evidence, validation and publication records. Plan document
  roles, authority, lifecycle and CI discipline for v0.3.0.


- Address the published 0.2.1 review in the 0.2.2 tree: checked width/phase
  narrowing; compiler-owned sealed signature inventory; grouped imports with
  stable AST/spans/docs; explicit receipt-identity equality and clearer effect
  diagnostics; one-body plus serial-copy repeat_static validation, avoiding
  product-matrix overflow for TH 512/1000/1024 while retaining other capacities.
- Add fixed-seed exact-extractor/source-CLI differential CI checks; compatible
  QFT symbolic-path matching and complex Fourier/reference proofs; separate
  cyclic reference semantics and enforce one-way imports. Preserve old Lean
  theorem APIs, production Rust authority and disabled external schemas.
- Put examples/installation first in README and generate separate current,
  historical and detailed-inventory status pages. Record v0.3 domain/Toffoli
  migration questions and retain corpus-first library growth until v0.5.0.


- Establish `STDLIB.md` for mathlib-style open-source library growth from v0.5.0,
  keeping new algorithms in corpus before then as a general rule. Add a short
  composable contract template and QFT2/Add2/AND-phase pilots over existing code;
  separate source checks, tests, actual-IR proofs, source preservation and
  specification review. Add CI documentation linting and mutation regressions,
  without a new bundled API, borrowing syntax or implemented `qlippy` executable.

- Plan verification migration through 0.2.2–0.2.9: acceptance inventory,
  exact arithmetic/finite evidence, pure and observing raw IR, hierarchical
  root binding, then native/production dual integration and coverage audit.
  Move K1/K2 implementation earlier while preserving compatibility,
  small-system validation and the v0.5.0 theorem/authority gates. This is a
  schedule/documentation change, with no new checker or enabled schema.

- Add six simple finite corpus translations from the existing pinned sources:
  SWAP/Fredkin, constant XOR/bitwise complement and exact RX/one-bit phase
  kickback. Grow the production CLI corpus from 30 to 36 cases, retain untouched
  first sources and source-specific notices, and add six type-correct semantic
  faults with independent phase/order checks. Heavy sized-QPE gates remain pending.

- Select development version 0.2.2 after the published 0.2.1 release;
  synchronize Rust, both Lean packages and the Python host. Keep shared-QPE
  integration and proof gates pending, preserve small-system validation scope,
  and distinguish development installation from published packages.
- Organize the reusable release procedure: exact-commit validation and clean
  distribution checks, annotated source tag, crates.io publication, fresh
  registry/hosted-doc verification and GitHub Release source verification.
  Preserve immutable 0.2.1 publication records and separate Python distribution.

## 0.2.1 — 2026-09-30

Published as `qleisli` on crates.io and as the
[v0.2.1 GitHub Release](https://github.com/MGYamada/Qleisli/releases/tag/v0.2.1).
Validation and publication evidence are recorded in the release record.

- **Rust package/import migration:** adopt `qleisli` for the first crates.io
  release at the user's explicit request. Earlier Git/path users must rename
  the `qleisli-core` dependency and `qleisli_core` imports, or use the documented
  Cargo alias. This is a narrow pre-registry identity exception; CLI/source/IR
  semantics remain unchanged. Registry publication is authorized after rechecking.

- Prepare the first crates.io release: add a registry README,
  checkout-independent quickstart, Rust API example/guide and discovery metadata.
  Repair rustdoc formatting and require warning-free docs plus doctests in CI.
  Extend clean distribution validation to install the extracted package and run
  documented source, bundled-library and ownership checks outside the checkout.
  Document package contents and the separately authorized publication step.

- Adopt Resource Safety as the third theorem pillar toward v1, alongside
  Soundness and Physical Realizability. Record the 2026-09-30 trust-boundary
  amendment as **to prove**: finite static resource bounds, compositional cost
  semantics and preservation through actual compilation. Add RS-C1–C5 without
  claiming existing ownership/work limits prove them or changing 0.2.1/0.2.2 gates.

- Add a structured `qleisli interop` CLI and installable Python host package
  for finite import/check/run/sample/export. Optional pinned PyQIR reads the
  declared QIR 2.0 Base text/bitcode subset before Rust ownership/IR checking;
  retain exact gate meanings, terminal measurement and explicit output order.
  Adaptive input and all-in-one platform wheels remain outside this slice.
- Split the release at the completed corpus/review/experimental-component
  boundary. Retain bounded connections in 0.2.1; move heavy measured shared-QPE
  implementation, production integration and proofs to 0.2.2 with unmet gates.
  The original corpus completion goal is deferred, not achieved.

- Reuse the same coherent QPE source in local order-finding and finite
  amplitude-estimation clients. Add explicit natural/operation forwarding in
  declaration order, preserve capability checks and key instantiations by
  complete nested providers. Small-system phase/reference and sign-fault tests
  pass; measured `CBits`, classical-result and production integration remain open.

- Add shared sized AddK and Equals sources with coherent carry, recursive
  controls and input restoration. Extend the experimental producer with explicit
  multi-owner calls/control/adjoint and complete-content imported-graph sharing.
  Validate widths 0–3, inverse/controlled clients, empty ownership and seven
  arithmetic faults; use small-system source regressions in CI. Production
  integration, named arithmetic binding and efficient general synthesis remain open.

- Add one shared coherent QPE source with explicit controlled access, bounded
  static powers, a reusable Hadamard definition and the same imported inverse
  QFT. Validate small selected sizes, reference states, off-grid phases and
  phase-sensitive provider changes. Follow the user's small-system validation
  scope for remaining work, preserving the earlier (8,8) limit as history;
  measured `CBits`, named QPE binding and production integration remain open.

- Add shared sized QFT source with explicit output reversal, dyadic phases and
  guarded affine sizes. Connect ordinary source modules and `adjoint` to the
  same shared graph; independently check forward Fourier requests and inverse,
  repeated-call and entangled-frame behavior. Record actual repeated execution
  cost; production CLI, QPE/CBits and general source preservation remain open.

- Prioritize actual corpus source: add one sized Xor and one sized GHZ
  definition with an untrusted development compiler and independent native
  reconstruction at every selected width. Check complete basis columns,
  coherent reference columns, linear/size failures and valid-but-wrong circuit
  mutations. Production sized-source CLI integration remains open.

- Connect singleton Fourier requests to the existing fresh `check_against` API.
  Compose complete Lean artifact checking with actual Fourier inspection;
  reconstruct all finite proofs and every phase-fixed H from the same bytes.
  Enforce the named contract's closed single-`Bits<n>` boundary and retain the
  full request, aggregate budgets and conditional unitary/reference proofs.
  Production hierarchy values and native/reader correspondence remain open.

- Bind the actual complete QFT entry to an independently requested Fourier width
  and interface. Derive identity renaming, recursive coefficients and explicit
  output reversal from actual bodies; prove full complex/reference amplitudes
  under bound exact-H obligations. Native widths 1–8 fit the unchanged shared
  budget. Production transport/seals, correspondence and source/corpus gates
  remain open; external schemas stay disabled.

- Compute phase-free wiring from actual shared hierarchical definitions and
  prove exact physical coefficients with arbitrary reference amplitudes.
  Check the QFT producer's outer renames/SWAPs within the existing aggregate
  budget; retain whole-artifact typing and the separate full Fourier-root gate.

- Classify proof maintenance by importance and retirement intent. Extend the
  temporary-proof inventory to the legacy reference alias and transitional
  QFT/QPE projection interfaces, with explicit replacement/removal gates.
  Retain actual-checker proofs, reusable mathematics and all current audits.

- Bind the complete shared recursive QFT body through one structural budget.
  Prove its full reversed-output Fourier coefficients from actual base,
  control/repetition and recursive definitions, leaving only bound exact finite
  H equations and transitional reader/native assumptions. Fresh H reconstruction
  rejects X, global -H and stale owner bindings. Complete actual outer reversal,
  independently requested Fourier roots and source/corpus integration remain open.

- Prove the shared QFT stage coefficient law and the explicit output-reversal
  equation, retaining full phases and reference amplitudes. Bind actual
  five-node stage geometry with a bounded pure inspector and native mutation
  checks; exact H, recursive/base and complete requested-root obligations remain
  explicit, with all external schemas still disabled.

- Clarify that GitHub Issues require no duplicate local backlog entry, update
  or backlog ID; retain existing backlog history.

- Bind actual shared-gradient definitions through a bounded Lean inspector and
  prove their complete complex diagonal by induction, including empty owners,
  actual routing and arbitrary reference amplitudes. Native producer/mutation
  checks and independent phase probes fit the existing shared budget. Complete
  outer QFT/Fourier and source/corpus integration remain pending.

- Prove exact diagonal laws for the actual hierarchical complex operators,
  including controlled repetitions, tensor products, inverse routing and
  arbitrary reference amplitudes. Add sparse coefficient scaling/control
  helpers with kernel proofs and independent native checks, without expanding
  repeated bodies. Complete QFT graph/Fourier binding remains pending.

- Reuse the actual complete-artifact typing context in conditional ordinary
  rule matching, with Lean proofs of the original acceptance predicate.
  Preserve all endpoint/phase/premise checks and existing work ceilings.
  Directly lifted QFT hierarchy fixtures pass through width four. A subsequent
  shared-gradient producer retains recursive register boundaries and shares
  controlled repetitions, admitting every width 1–8 without new checker rules
  or larger budgets. Independent Fourier schema/source integration remains open.

- Bind the supported conditional hierarchy to a separately supplied root
  contract through the actual Lean checker and fresh exact Rust reconstruction.
  Prove equal requested denotations and unitary/reference laws under the actual
  finite obligations. Preserve sharing and phase; reject coordinated circuit/
  meaning mutations, malformed pair proposals and aggregate work excess.
  Add a compatible request API and CI checks; complete production/profile,
  sized-source and corpus integration remain pending.

- Reaffirm the required Lean backend and its ban on `unsafe def`,
  `@[implemented_by]`, `@[extern]` and `partial def`. Extend existing source/
  compiled-audit CI regressions to nested backend modules, private/generated
  helpers and axiom-free theorems with runtime replacements. This changes no
  production acceptance rule and does not implement the future backend.

- Adopt sequential Rust-to-Lean pipeline migration from either end, retaining
  independent IR checking at the language boundary and extending the verified
  downstream segment through actual-pass preservation proofs or translation
  validation. Keep external candidate search, including rotation-synthesis
  norm-equation search, behind a planned proved Lean `LeafRealizer` checker;
  apply the de Bruijn criterion per pass without requiring all code to migrate.
  Keep the fixed trust partition and existing authority/proof gates.

- Plan Qleisli type-system specification as part of the v0.3.0 breaking-change
  release and defer QLT implementation to v0.4.0 or later. Concrete type rules
  and migrations remain to be specified; current 0.2.1 contracts and manifests
  are unchanged by this scheduling decision.

- Connect strict hierarchy JSON to a fresh native Lean conditional check and
  reconstruct every returned finite obligation from the same immutable bytes
  under one shared exact budget. Retain sharing under zero and large powers;
  reject phase/type/binding faults and malformed transport. Keep independent
  root-contract acceptance, remaining profile rules and external schemas pending.

- Propagate bound finite-leaf unitarity through actual conditional derivations,
  constructing a common unitary entry and both inverse laws with arbitrary
  finite references. Add strict exact matrix byte transport with independent
  dyadic exponents and fresh reconstruction of both sides of a finite equation.
  Keep all existing capacities and the explicit Rust/decoder correspondence
  boundary; complete hierarchy transport and production acceptance remain open.

- Compose actual finite reconstruction obligations through a separate bounded
  hierarchical derivation pass, retaining every request even under zero powers.
  Prove constructed operator and reference-map equality conditional on exact
  interpretations of those leaf bytes. Keep host/decoder correspondence
  and production acceptance pending.

- Add a finite unitary-leaf adapter that reconstructs complete QIRF1/2 bytes,
  checks exact type/owner/axis boundaries and an independently supplied matrix,
  and shares the existing exact-work budget across leaves. Preserve scalar phase
  and zero-width ownership. Add a pure Lean projection with proved binding of
  actual finite requests to indexed bytes, interfaces and encodings. Connecting
  those requests to the Rust result and the remaining leaf
  profile is still pending.

- Add an untrusted shared-call expansion into existing rewire/sequence nodes,
  preserving the actual callee index. Prove its coordinate transport and
  unitary/reference laws; check generated artifacts with independent phase
  and axis mutations. Retain the measured fragmented-header capacity case.
  Production call transport and sized-source integration remain pending.

- Adopt linear size obligations and explicit ordered bit-segment reshape in
  the 0.2.1 design, with `n+1` recursive interfaces and checked size transport.
  Preserve the first `n+m`/`2*n` source and real parser failure. Add focused
  axiom guards for the two existing reshape theorems; sized source, the new
  arithmetic/segment proofs and the separate array API remain pending.

- Begin the authorized sized-corpus continuation with preserved Xor source and
  actual diagnostics. Prove whole-space unitarity laws for the existing
  hierarchical complex operators, including coherent control and arbitrary
  finite reference extensions; bind phase, rewire and structural leaves to
  actual typing predicates. Recursively derive entry unitarity from supported
  internal checker success without assumed child isometries. Finite leaves,
  remaining full-profile rules and sized source remain pending. Correct the
  remaining current-design `CWord` table entry to `CBits`.

- Address the 0.2.0 review: prevent roundoff drift from
  rejecting long samples; count shared source snapshots once in QIRF and reuse
  imported storage; remove empty error locations; list all CLI commands/options;
  reject Lean `#eval`/`#eval!` in runtime source policy. Clarify numerical residues,
  improve finite-capacity diagnostics, and add `check_reference_value` while
  preserving the narrower `check_reference` compatibility theorem.

- Adopt the standard-library goal of a BLAS/LAPACK-like foundation for quantum
  computing integrated with a textbook and formal specifications: readers
  should be able to learn quantum information by reading the library. The
  comprehensive organization and generalized APIs remain separate decisions.

- Add a proved experimental canonical-reshape metadata helper before sized
  source: explicit single-owner regrouping preserves typed leaves, ordered
  axes, labels and reference coefficients without basis enumeration. Keep
  desired source, counterexamples and independent native checks; no new
  production rule or `reshape` source API is enabled.

- Expand the approved three-source input corpus from 24 to 30 finite translations:
  majority-oracle Deutsch–Jozsa, Bell measurement, constant addition, equality,
  LCU projector embedding and quantum-kernel overlap. Preserve first attempts,
  pinned originals and source-specific notices; add phase/reference oracles
  and six deliberate type-correct semantic faults. No new language rule or
  general algorithm support is claimed.

- Select development version 0.2.1, synchronizing Rust and both Lean packages
  with the continuation record. Shared sized QPE,
  production hierarchy and H1–H5 remain pending under the existing plan.
- Fix the README soundness formula for GitHub rendering by replacing
  `\operatorname` and specialized double-bracket macros with basic TeX notation.

## 0.2.0 — 2026-09-29

Finite machine interfaces, sampling and trials, arity-preserving tuples,
resource-policy review fixes and the experimental Lean kernel/proof foundation.
See the migration and validation record and
[GitHub publication evidence](https://github.com/MGYamada/Qleisli/releases/tag/v0.2.0).
Production finite verification remains Rust-authoritative; common sized QPE
and the remaining production hierarchy/H1–H5 work target 0.2.1.

- Record a future 0.x.0 Lean-assisted mathematical debugger: bounded obligation
  reports, independently checked mismatch witnesses and IR/source/backend
  tracing, distinct from missing evidence or undecided checks. No debugger is
  implemented and no current release or theorem gate is added.

- Split the release scope: retain implemented finite interfaces, tuple/resource
  policy changes and the experimental Lean foundation in 0.2.0, with migration and
  release validation recorded separately. Move remaining production hierarchy,
  sized source/shared QPE and execution/H1–H5 to the 0.2.1 target without
  weakening their gates or permitting incompatible PATCH changes.

- Construct successful, unique complex denotations from actual supported
  hierarchical derivations, removing the assumed interpretation environment
  for their entry operator/reference equations. Keep whole-space unitarity,
  finite reconstruction and full source/schema integration as separate gates.
  Mark known migration-only proofs `temporary` with replacements and removal
  conditions; maintain their normal build, audit and API compatibility checks.

- Bind the three closed component schemas to rebuilt Lean theorem types,
  parameter domains and a content revision of their source/audit dependencies.
  Add CI and source-archive manifest checks; external schema entries remain
  disabled until full IR/provider binding is implemented. Add bounded scheduling
  for the full hierarchy's dependency graph, prove actual-checker acyclicity,
  and test shared graphs and aggregate capacities without semantic expansion.

- Record the fixed architectural trust partition in [TRUSTBOUNDARY.md](TRUSTBOUNDARY.md):
  trusted foundations/specifications, soundness/realizability proof obligations,
  and independent validation of untrusted frontend output.

- Record the future QLT mathematical test-language design, first source drafts
  and semantic counterexamples. Plan a Rust exact/cost/doctest experiment in
  0.3–0.4, followed by instrument evaluation, Lean migration and later interval
  certificates. No QLT runtime is implemented and no 0.2.0/S05/PR gate is added.

- Adopt the Physical Realizability Theorem and a proved Lean backend as v1
  requirements: derive CPTP semantics from soundness, then construct and
  synthesize its isometric dilation over a declared gate set. Clarify the
  longer-term Lean migration beyond the frontend and the remaining boundaries
  of an end-to-end guarantee. This records a plan, not a completed proof.

- Prove the actual QPE controlled-power schedule and residual target/reference
  instrument, with fresh-zero, measurement-order and retained-owner checks.
  Prove all-outcome completeness and joint trace preservation under an explicit
  provider-isometry premise. Derive both inverse laws for the accepted QFT
  graph and denotation existence from QPE acceptance. Add native width/mutation tests and independent
  off-grid coherence, normalization and missing-outcome counterexamples.
  Fixed component dispatch now binds theorem IDs, versions, independent
  parameters and actual witnesses, with semantic acceptance theorems. Full
  external IR/provider/registry binding remains pending.

- Bind the QFT theorem to an internal typed shared-circuit graph: exact
  `Bits(m)` interfaces, effects, call boundaries, actual dependencies and final
  data permutation. Prove cached checking agrees with literal graph execution
  and extend the Fourier/reference theorem to that graph's coefficients. Add
  native semantic mutations, graph limits and sharing-cost checks; external
  hierarchy projection and schema registry remain pending.

- Prove symbolic H/phase path compilation and the actual width-1–8 QFT
  circuit matcher's positive normalized Fourier coefficients, including final
  reversal and arbitrary reference amplitudes. Add native symbolic and independent
  Fourier comparisons, a type-correct wrong-reversal source, CI and retained
  proof attempts. External schema/typed hierarchy binding remains pending.

- Prove local Hadamard cancellation and phase normalization for arbitrary joint
  amplitudes in the Mathlib-free runtime. Add a one-way complex interpretation
  bridge in the separate proof package, including local probability identities
  and the existing phase/layout checker's weighted basis transitions. Validate
  the actual native normalizer with independent complex oracles and two retained
  source clients. This adds no external acceptance profile or QFT/QPE schema.

- Connect sparse dyadic phases to typed shared layouts in the experimental Lean
  kernel, including controlled conditions and retained scalar phase. Prove actual
  normalization/remapping/composition and request binding, charge claim validation
  and preserve expanded phase counts after cancellation. Add independent native
  and finite-source interference tests, pure API limits, CI and retained records.
  Non-diagonal gates, general transforms and QFT/QPE schemas remain pending.

- Connect typed layouts to shared calls and ordered composition in the experimental
  Lean kernel. Compute actual dependency/adapter maps once per definition, bind
  every receipt and the separate request, and prove acceptance against direct
  graph semantics. Add native mutation/scaling oracles, pure-API limits and CI
  coverage; retain first source, proof/audit diagnostics and validation records.
  Production QPE hierarchy and source integration remain pending.

- Continue CD-3 with a Mathlib-free typed layout checker: exact n-ary type trees,
  complete owner/axis permutations including zero-width owners, independent
  requests and proved inverse/reference reindexing. Add native rejection and
  16-bit capacity tests. General hierarchy integration and QPE remain pending.

- Preserve tuple arity and nesting across source AST, type checking, ownership
  and finite evidence: `(Bit,Bit,Bit)` differs from `((Bit,Bit),Bit)`.
  Add the consolidated type contract, explicit conversion
  and migration rules, and source/external-evidence
  regressions. Existing binary interfaces retain their shapes. This supersedes
  the earlier plan to preserve the 0.1.8 left-folding rule.
- Adopt Rust as the default when type or ownership design is uncertain;
  document quantum-specific differences and their checking obligations.

- Begin CD-3 with a Mathlib-free shared phase DAG checker: explicit owner ports,
  exact shape tags, independently bound summaries and requests, closed powers
  without body expansion, and actual cyclic-action soundness proofs. Add native
  mutation/scaling CI and preserved first-source diagnostics. Full hierarchical
  QPE, complex interpretation and sized source remain pending.

- Make proof of the **Qleisli Soundness Theorem** the central v0.5.0 milestone,
  with explicit production-kernel scope and S05-C1–C5 gates. Plan broader
  community open-source development from v0.5 onward, with preparation in
  0.4.x and translation validation from 0.6.0. These are future targets, not
  completed proofs, a license change or a current-version bump.

- Adopt the staged Lean kernel migration. Add a
  Mathlib-free Lean 4.30.0 executable phase-word checker with an actual
  acceptance soundness theorem, independent requirement protocol, Rust launcher,
  compiled-declaration audit and native differential CI. Production Rust
  verification and the pending common-QPE/H1–H5 gates remain in place.
  Development Python checks now require Python 3.11 for standard-library TOML.

- Retain shared sized QPE/QFT as the 0.2.1 continuation target and R14/H1–H5;
  name copyable measured sequences `CBits<m>`.
- Add trajectory sampling, the seeded `sample` command and typed fresh-trial
  host APIs, including bounded validated period/factor postprocessing.
- Apply bounded CLI source loading with explicit capacity/legacy overrides;
  preserve legacy Rust loader/compiler entry points. This default is breaking.
- Implement bounded QIRF1/QIRF2 transport and independent contract requests,
  exclusive atomic `emit-ir` and fresh-process `verify-ir`. Reconstruct finite
  evidence through the existing exact checker and retain complete root types.
- Preserve first QPE/Grover attempts and real baseline diagnostics. Hierarchy,
  external schema binding and sized source are still pending; component proofs
  are included in the experimental Lean foundation.
- Address the v0.1.9 follow-up review: share
  exact work across compilation, use repeated squaring, compare finite closed
  transforms independently, and reject bare CR throughout source. Aggregate
  checking capacities and the CR restriction are breaking 0.2.0 changes.
  Extend corpus link checking, consolidate helpers, harden source opening on
  macOS/listed Linux targets and hash-pin the external validation wheels.


## 0.1.9 — 2026-09-28

Compatible review fixes, the completed finite B019 foundation and preparation
for code-driven development. See the release record
and [GitHub publication evidence](https://github.com/MGYamada/Qleisli/releases/tag/v0.1.9).

### Added

- A closed three-source [input corpus](corpus/README.md): 24 finite executable
  translations from QuantumKatas, Qualtran Bloqs and PennyLane Demos, pinned
  originals/licenses/hashes, per-case contracts and exclusions, initial authoring
  snapshots and real diagnostics. Independent numerical oracles check 9,412
  semantic probes, with four local rejection fixtures. No upstream framework
  or general algorithm implementation is claimed.
- Adopted [source/licensing policy](corpus/POLICY.md): preserve MIT for Katas
  translations and Apache-2.0 for the other two; Qleisli stays Apache-2.0.
  Source additions/replacements require an explicit policy amendment.
- Explicit development method:
  start with quantum programs as they ought to be expressed, then develop the
  language with AI. Record current-source friction as A020-14–16 without
  adopting syntax, new checker rules or continuous-angle APIs.
- A dated B019 boundary check, with a local F2
  reproduction, finite revalidation and explicit audit/candidate closure work.
  Preserve it as the initial assessment; subsequent closure has separate records.
- Completed B019 finite foundation, with
  frontend/trusted-boundary review dispositions, an independent 4,608-case exact
  phase/layout/control/adjoint sweep, successful exact-commit Linux CI and clean
  package/complete-source-archive checks. Publication remains separate.
- A code-driven continuation procedure, with
  source-grounded obstacles A020-17–20 and bounded work packets for the
  user-selected 0.2.0 direction. It adopts no future grammar or checker rule.
- A clean-commit distribution checker for the verified production package and
  complete source archive, including nested research, proofs, exact source bytes
  and third-party notices; CI also checks its adversarial regressions.

### Fixed

- Reject incomplete or invalid M1 `StaticOp` syntax at the current token/EOF
  before consuming a constructor. Previously `g` could panic (exit 101),
  violating the existing grammar error and X1 single-JSON failure contracts;
  it now returns `expected a static operation description`, `parse`, exit 1.
  Keep EOF as a parser sentinel. Regressions cover all constructor/example/std
  token prefixes, exact spans, JSON `check/run` and Markdown `doc` failure.
- Make CI whitespace checking compare the entire committed tree with the empty
  tree, so a clean checkout no longer turns the check into an empty comparison.
- Share a single bounded immutable source snapshot across static-provider and
  function-contract receipts, charging source bytes once before copying.
  [F2/A020-10 is resolved without changing
  public owned identities, source/raw binding, exact checks or existing limits.
  The 100 KB/256-provider case and an additional 25 KB comment module now pass.

### Changed

- Locate function-effect failures at a causal expression and show derived and
  declared effects, retaining declared callee effects and both-branch checking.
- Suggest checked separate imports and ordinary unary wrappers for unsupported
  grouped imports and static `h/x/z/t` arguments. Explain retained source copies
  when a new provider/contract snapshot exhausts the existing work budget.
- Clarify direct versus constructor-derived capabilities and record source
  snapshot accounting omitted from the original M1 work-unit description.
  Preserve current accepted derivations and limits; A020-09 remains future
  opaque-provider design work, while A020-10 is resolved by shared retention.
- Distinguish ideal iterative-QPE probability one from floating-point residuals.
  Record additional authoring feedback and pending multi-error/boilerplate/display
  work as A020-11–13, without a model benchmark or new syntax claim.

No public Rust/IR/evidence API, accepted source meaning, JSON v1 schema,
dependency or toolchain requirement changes. No capacity is reduced; duplicate
snapshot work is removed. The 0.1.8 migrations remain historical.

## 0.1.8 — 2026-09-28

Fixed-width operation contracts and executable authoring improvements, with
version **0.1.8** retained at the user's request. See the
implementation/migration record and
[GitHub publication evidence](https://github.com/MGYamada/Qleisli/releases/tag/v0.1.8).
Historical entries retain the version policy used at the time; the revised
policy below governs new changes.

### Added

- Fixed three-bit iterative QPE in ordinary `.qli`, compared with coherent QPE
  and an independent Fourier-instrument oracle on off-grid entangled inputs.
- Preserved first-source and curated repair sessions, with actual diagnostics,
  revision snapshots and CI checks for record integrity.

- A living v0.2.0 issue backlog connecting authoring friction to concrete
  source evidence, acceptance experiments and existing checking dependencies.

- Basis function parameter patterns for product components, whole subtrees
  and ignored basis values, checked through existing finite tables.
- N-ary tuple types, values and patterns, left-folded to exact binary trees.
  Independently checked pair meanings, executable clients and negative
  ownership/shape/depth regressions exercise these forms.

- Runnable Bell/teleportation/dense-coding/swapping components and shared
  operation-parameter QPE, amplitude-amplification and Hadamard-test examples.
  A checked-in `.qli` corpus covers successful clients, rejected authoring
  attempts and type-correct algorithm faults, including reference correlations.
- A concise implemented-source reference whose complete code fences compile
  and execute in Rust CI, and an evidence-based authoring feedback report.
- Fixed-width static operation parameters, explicit access constraints and
  bracket arguments, phase-fixed permutation/phase meanings, `bind_op`, and
  six checked composition constructors. One unchanged client can accept
  independently checked implementations of the same meaning.
- `FiniteMeaning` / `MeaningEvidence` reuse existing monomial and function
  evidence. Final IR retains receipts; no core acceptance rule is added.
- Parametric access/type/ownership checking and concrete exact cleanup checks,
  bounded specialization, source/evidence rejection regressions and a runnable
  operation-contract example.

### Changed

- Include expected/actual exact types in concrete mismatch diagnostics and
  suggest the explicit logical-contract form for restricted cleanup failures;
  keep acceptance, source locations, error categories and JSON v1 unchanged.

- Replace public Rust `Param.name` with `Param.pattern`; this incompatible
  AST migration is documented while the user retains development version
  0.1.8. Existing accepted binary `.qli` programs retain their meaning.
- Locate unreturned quantum ownership at its actual binding, including
  nested patterns, shadowing, parameters and computed-region binders.

- Align initial-development versioning with Cargo: for 0.y.z with y > 0,
  compatible fixes/features/syntax additions use PATCH; breaking changes use
  MINOR. Compatible features need no exception. Preserve historical migrations
  and the 0.1.8 checkpoint; 1.0+ rules and verification gates are unchanged.
- Reserve the new M1 keywords and extend public AST/token/error records;
  follow the release record's source and Rust migration. JSON v1 gains emitted
  `capability` / `contract` cases within its specified category set.
- Render meaning definitions and access requirements in source documentation.
- Split parser routines to preserve existing deep-syntax acceptance/rejection
  without increasing stack requirements. Keep old IR, toolchains and limits.

QIR import, remaining machine interfaces, type/size generalization and M2 remain
separate work. The v0.2.0 backlog includes reconsidering
the tuple layout itself; 0.1.8 retains explicit binary trees and left-folded sugar.

## 0.1.7 — 2026-09-28

Start M1 with JSON results and bounded OpenQASM 3/QIR connections, under the
user's explicit feature-release exception. This is new functionality, not
compatible-maintenance-only work. The release record
and [GitHub publication evidence](https://github.com/MGYamada/Qleisli/releases/tag/v0.1.7)
separate implementation, validation and publication.

### Added

- Start M1.1-A with bounded OpenQASM 3 import/export and QIR 2.0 Base text output.
  Require explicit OpenQASM initialization, retain exact gate phases and output
  order, and independently verify imported ownership through the existing core.
  Add a Rust host example, adversarial/exact tests and independent parser/LLVM
  validation. See the connection contract.
- Start M1 X1 with opt-in `--format=json` for `check` and `run`: one version-1
  `qleisli.result` object on stdout, including failures, stable categories,
  nullable original-source locations, and lexicographically ordered distributions.
- Add structured frontend diagnostic APIs alongside the unchanged legacy error
  APIs. Preserve parser/load provenance and coordinates from the loaded source
  snapshot, including Unicode, CRLF and empty EOF spans.
- Validate JSON independently with Python's JSON decoder as well as Rust CLI
  golden and diagnostic regressions; run the JSON suite in primary/MSRV CI.

### Changed

- Adopt the project title “Qleisli: A Language for Structured Quantum Algorithms”
  and the tagline “Write quantum algorithms in the language you use to think
  about them.” in a shorter README with a runnable introduction.
- Translate AGENTS.md into English, preserving the working rules and explicit
  version exceptions. Retain historical Japanese validation records, bilingual
  glossary terms and legacy link anchors.

### Compatibility and scope

- Human output and existing successful invocations remain unchanged. Unknown,
  duplicate or missing-value flags are usage errors. Prefix a path starting with
  `-` by `./`. `doc` keeps its existing Markdown interface and rejects JSON mode.
- JSON mode requires UTF-8 path identities. Non-UTF-8 paths report `project`
  without an invented location; legacy human mode retains its path support.
- Clamp only JSON probability endpoint roundoff within 2^-40; reject nonfinite
  or materially out-of-range output as `numerical`. The numerical reference
  simulator and exact evidence checker are unchanged.
- No new `.qli` form, core checking rule, IR variant, production dependency, existing capacity or
  toolchain requirement. New adapters have explicit local bounds; validation-only
  OpenQASM/ANTLR and LLVM dependencies run separately. QIR import, adaptive
  connections and Python distribution remain pending. X2–X6, N1–N6 and M2 remain unimplemented.

## 0.1.6 — 2026-09-28

IR/evidence maintenance plus the user's explicit version-policy exception for
the comment/docstring extension. Rust and Lean project versions remain at
0.1.6. The implementation and validation record
separates local checks from exact-commit CI, tagging and publication in the
[GitHub release record](https://github.com/MGYamada/Qleisli/releases/tag/v0.1.6).

### Documentation feature and migration

- Add nested `/* ... */` comments and Rust-style `//!`, `///`, `/*! ... */`
  and `/** ... */` documentation. Check attachment, retain original byte spans
  and expose metadata separately through `parse_documented_module`; existing
  public AST fields and lexer token variants stay unchanged.
- Add `qleisli doc <source-file>` and Markdown rendering without execution or
  a verification claim. Document every bundled module and all twelve public /
  three private definitions in English; ordinary stdlib checking is unchanged.
- Doc spellings previously treated as arbitrary comments now require valid
  placement. Line comments end at LF/EOF; bare CR is forbidden in doc text.
  Use ordinary comment spellings or LF/CRLF when migrating, as described in
  the extension specification.
- Keep 0.1.6 at the user's explicit request despite the normal MINOR rule.
  This feature and its source-acceptance changes are not compatible-only
  maintenance; the exception does not apply to future feature work.

### Fixed

- Enforce the existing raw-IR limit of 64 nested classical branches before
  entering either arm. Previously a 65th branch with empty arms was accepted;
  it now receives the existing depth-limit diagnostic at that branch.

### Validation

- Add raw-IR cases at 63, 64 and 65 levels, with empty/nonempty deepest arms
  on both sides, checking acceptance and rejection locations.
- Check function-evidence preflight at 31, 32 and 33 levels in both the
  implementation and specification, including inactive empty branches and
  complete zero-width ownership. Its existing 32-level bound is unchanged.

### Design

- Select future Python bindings and bounded OpenQASM 3/QIR import/export to
  reduce adoption cost through a shared checked compiler core. Record phase,
  ownership, measurement-reuse, evidence-binding and wheel-installation gates.
  This is a direction, not implemented
  interoperability or a completed extension specification; features require MINOR.
- Adopt the small trusted-core boundary: convenience belongs in untrusted
  desugaring, not in the checker. Inventory raw-only IR variants as compatibility
  debt and specify the obligations for a future versioned core reduction.
- Define desugaring consistently as meaning-preserving translation to already
  specified core operations with untrusted output for independent checks.
  Distinguish it from source checking, runtime adaptation and approximation.
- Record the risk of fixing the design to one future gate architecture and the
  recommendation to parameterize coefficient domains, separating exact,
  approximation and device/noise contracts. Cite STAR primary work; keep the
  current R8 implementation and selected M2 angle profile unchanged.

### Internal

- Route legacy raw `QuantumIf` arm execution through the existing finite
  `CircuitStep` vocabulary. Preserve public IR, independent exact extraction,
  in-place primitive execution and existing execution-step limits. This removes
  duplicate numeric interpretation, not verifier rules or evidence obligations.
- Compare all legacy arm primitives, both polarities, empty/Unit arms and mixed
  sequences with independent exact extraction, including coherent references,
  reversed physical axes, exact budget boundaries and state-vector reuse.

The IR/evidence changes preserve existing valid core programs and public IR.
The comment extension adds APIs and the documented lexical/attachment changes
above. Quantum rules, declared capacities, dependencies and toolchains are
unchanged; no original M1/M2 slice or general proof is implemented.

## 0.1.5 — 2026-09-27

Compatible review/design maintenance release. Rust and Lean versions are
synchronized at 0.1.5. The release record separates
local validation from the exact commit, CI, tagging and publication recorded
in the [GitHub release](https://github.com/MGYamada/Qleisli/releases/tag/v0.1.5).

### Changed

- Reflect the v0.1.4 review with a concrete next-scope
  dossier and version-independent M0–M5 milestones. Fixed-width M1 may retain
  existing finite checking; bounded kernel continuation and hierarchical IR
  gate M2 size generalization. Replace indefinite deferral and no-go completion
  with a selected path and dated scope checkpoint.
- Advance the local v0.1.5 maintenance roadmap with explicit completion
  evidence for review/specifications, checks and distribution; keep exact-commit
  CI, tagging and publication as pending release gates.
- Complete the selected future M1 language and machine-interface specifications:
  static grammar/access judgments, permutation/phase meanings, portable finite
  IR/evidence, JSON diagnostics, trajectory sampling, typed retries and source
  limits with legacy migration. Specify the bounded M2 hierarchy/schema/QPE
  profile and implementation acceptance matrices; no new feature is implemented.
- Correct the follow-up specification review: retain and independently validate
  exact root input/output type trees in portable IR, reject equal-width tree
  substitutions in requested contracts, and define controlled operations in
  the existing least-significant-control basis order. Add future acceptance
  cases; these interfaces remain unimplemented.
- Make truth-table-free reversible synthesis and hierarchical IR/evidence
  binding explicit scaling prerequisites. Record basis-derived semantic
  vocabulary, ideal dyadic QPE angles, early portable evidence/JSON/sampling
  slices and special-form/public-IR migration as future MINOR work.
- Prioritize independent IR-verifier and evidence-kernel proof obligations;
  select finite instrument/CPTP semantics as the first planned Physlib use.
- Defer Physlib to that future concrete bridge: remove its direct requirement
  and five exclusive transitive packages, drop its default CI build/audit,
  and preserve the external probe under research. Retain all nine Mathlib
  dependency records, Lean/Mathlib 4.30.0 and Qleisli proof declarations.
- Centralize mutable planning state and a fourteen-group rule-to-code,
  test and proof inventory in JSON; generate Markdown and reject drift in the
  existing document checker. Preserve historical records and legacy IDs.
- Correct AE's conjugation-based access/cost account, Shor indentation and
  dependency-history wording; simplify AGENTS.md to durable rules and links.

### Validation

Add five document-checker regressions and six phase-sensitive conjugation
convention fixtures. The validation record
states actual local checks and remaining publication gates. Numerical fixtures
do not establish general theorems or execute imaginary source.

No production/research Rust, Qleisli proof declaration, public behavior,
supported capacity or toolchain change. The unused external Lean dependency
is removed as above; no `.qli` migration is needed. Experiments importing
QuantumInfo directly must declare their own Physlib dependency.

## 0.1.4 — 2026-09-27

Compatible documentation/plan maintenance release. Rust and Lean project
versions are synchronized at 0.1.4. The release record
records validation scope; the [GitHub release](https://github.com/MGYamada/Qleisli/releases/tag/v0.1.4)
identifies the exact commit, CI, tag and published source distribution.

### Changed

- Adopt the v0.x plan and B019-1–B019-6 boundary through
  v0.1.9: finite-core compatibility and conformance, evidence-boundary review,
  explicit proof obligations, next-minor decisions and reproducible validation.
- Make operation capabilities the next design focus alongside ownership,
  effects, established auxiliary invariants and proof contracts. Require new
  abstractions to remove an author obligation through independently checked
  evidence. Existing finite effects and certificates remain the foundation.
- Assign conditional themes from v0.2 toward v1 without adopting new syntax
  or APIs. Preserve the symbolic-kernel deferral with no selected release,
  the scaling prerequisite, six imaginary drafts and executable V1-C1–C5.
- Align current-version guidance and remove the stale README statement that
  the preceding 0.1.3 release was still awaiting publication.

No production/research Rust or Lean source, public contract, supported capacity,
toolchain requirement or dependency changes. The independent non-published
research package retains 0.1.3. No migration is needed.

### Validation

Fresh local candidate checks pass on macOS with Rust 1.98.1 and 1.85.0:
258 production and 43 research tests each, primary fmt and all-target Clippy
for both packages. Pinned Lean builds and separate audits pass for 577 Qleisli
and eight Physlib declarations. All 43 Python tests, 52 mathematical checks,
39 exact assertions and all ten CLI projects and Shor pass. The
P014 record separates
candidate distribution checks, clean-commit CI and publication. These results
do not complete later maintenance audits or new language features.

## 0.1.3 — 2026-09-27

Compatible maintenance and mathematical-research release. The Rust and Lean
packages remain aligned at 0.1.3. The release record
states validation scope; the [GitHub release](https://github.com/MGYamada/Qleisli/releases/tag/v0.1.3)
identifies the exact commit, CI, tag and published source distribution.

### Fixed

- Reject empty, ragged and dimensionally incompatible matrices in the
  imaginary-design and exact semantic-contract helpers before `zip` can
  silently truncate data. Preserve valid rectangular/scalar fixtures and
  rational/quadratic arithmetic.
- Reject NaN and infinity in either comparison operand, including complex
  components, with `ValueError`. Invalid input cannot make positive or
  negative mathematical checks pass. Finite comparison tolerance is unchanged.
- Add 29 helper regression tests across the two suites and run both in CI.
  Preserve the existing 52 imaginary-design checks and 39 exact assertions.

### Design and independent research

- Verify the supplied v0.1.2 review against the tag and release CI. Require
  composition without whole logical dense matrices before size generalization,
  with an explicit first-QPE angle and exact/approximate checking profile.
- Record a first-principles meaning/implementation/evidence architecture and
  an independent, non-published symbolic semantic-kernel prototype. Its typed
  terms, frozen requested contracts and bounded exact leaves support a limited
  raw-IR adapter; it does not change production source acceptance or execution.
- Add 20 local Lean semantic lemmas with explicit premises. These mathematical
  rule proofs do not prove correctness of the Rust checker or compiler.
- Retain the prototype and regressions while deferring further kernel development
  and production integration to future roadmap work, with no target release.
- Record isolated Physlib/QuantumInfo and lean-quantum interface experiments,
  with pinned sources, reproducible probes and declaration-level axiom evidence.

### Lean environment

- Add Physlib's compatible `v4.30.0` commit
  `f5242c99d796b59a390d26cd7d1a8057e04c46b5`, preserving Lean/Mathlib 4.30.0
  and all pre-existing dependency revisions. Lock the inherited documentation
  dependencies and record their licenses.
- Build selected QuantumInfo state/channel/measurement dependencies in CI and
  audit eight external declarations separately from all Qleisli declarations.
  Library availability does not establish source/IR semantic correspondence.

### Validation and compatibility

Local macOS release checks pass on Rust 1.98.1 and minimum Rust 1.85.0:
258 production tests and 43 research tests each, primary fmt, and Clippy on both.
The 43 research tests include 5,425 exact differential cases within one test.
Python checks cover 18 imaginary-helper, 11 exact-helper and 14 document-checker
regressions, plus the 52 mathematical checks and 39 exact assertions.
The release record separates local checks, hosted Linux CI, package validation
and publication evidence.

Production Rust behavior, existing public contracts, capacity limits and
supported toolchains are unchanged. No source migration is needed.
Imaginary source and production symbolic integration remain unimplemented;
these checks do not establish general compiler soundness.

## 0.1.2 — 2026-09-27

Documentation/design maintenance release. Both project manifests are
synchronized at 0.1.2. The release notes record scope
and validation; the [GitHub release record](https://github.com/MGYamada/Qleisli/releases/tag/v0.1.2)
identifies the tagged commit, required CI, source archives, and publication.

### Changed

- Align current-version records and define a staged roadmap for six imaginary
  Qleisli 1.0 algorithm drafts, per-draft semantic contracts, a shared
  requirements index, semantic review, and release validation.
- Make the next-minor sequence explicit: complete the existing imaginary-v1
  prerequisite, select and specify the smallest required generalization,
  then implement and validate it with evidence retained in final IR.
  V1-C1–C5 remain the separate executable acceptance target.
- Translate ten current Japanese design, planning, overview, and finite-IR
  proof documents into English. Preserve semantic premises, proposal/proof
  status, historical evidence, source links, and legacy heading anchors.
  Add a documentation authority/inventory map; retain Japanese operational
  guidance and original dated conformance entries as supporting records.
- Correct the review summary's odd-QSVT direction to right-to-left singular
  spaces, matching the unchanged `L p(Sigma) V†` contract and circuit.

### Added

- An English language-evolution framework separating current normative rules,
  imaginary notation, extension specifications, implementation and proof.
  Correct stale v0.1 status summaries without changing acceptance rules.
- Six original imaginary-v1 algorithm bodies for QPE, Grover, amplitude
  estimation, Shor, a symmetric Szegedy walk and QSVT; per-draft contracts,
  shared requirements R01–R14 and a semantic/counterexample review.
- A reproducible 52-check mathematical script covering Fourier/phase conventions,
  residual/reference coherence, amplification signs, factor validation, walk
  reflections, and QSVT parity/selector boundaries, also run in documentation CI.

### Validation and limits

Before English consolidation, the local 0.1.2 candidate passed 258 Rust tests and Clippy on both Rust 1.98.1
and 1.85.0, Lean build and its 527-declaration axiom audit, 14 documentation
checker tests, 39 exact examples, 52 new mathematical checks, all ten CLI
projects and Shor, and 155-file source-candidate packaging/rebuild. Linux CI
and clean-release-commit packaging are publication gates; their final results
belong in the GitHub release record. Subsequent
English translation passed independent fidelity review, document checks and
14 checker tests, the 39/52 mathematical fixtures, and updated 156-file
packaging/rebuild, recorded separately.
It does not claim to rerun Rust execution tests, Clippy, or Lean suites.

The initial design-corpus prerequisite before 0.2.0 is met by the recorded
artifacts and review. All imaginary source remains uncompiled; no new language
forms, standard APIs or general proof guarantees are delivered. The
release record and
conformance ledger distinguish local candidate
validation from clean-commit CI, tagging and publication. The compiler fixes
and historical results of 0.1.1 remain recorded under 0.1.1.

## 0.1.1 — 2026-09-27

Compatible maintenance release. Both project manifests are synchronized at
0.1.1. See the release notes for scope and checks;
the [GitHub release record](https://github.com/MGYamada/Qleisli/releases/tag/v0.1.1)
identifies the published commit and its CI evidence.

### Changed

- Require an initial imaginary Qleisli 1.0 code corpus before v0.2.0 feature
  implementation or release, covering QPE, Grover, amplitude estimation,
  Shor, quantum walk, and QSVT. Noncompiling, revisable design code and its
  semantic requirements are distinct from executable v1 acceptance evidence.
  The policy is adopted; the corpus is still pending and is not a prerequisite
  for this compatible maintenance release.

### Fixed

- Reuse immutable function evidence within one frozen compiler project without
  repeatedly comparing and charging its source/raw snapshots. New artifacts
  still pay for snapshot copies; external binding checks remain exact.
- Point independent IR contract errors at the originating source expression,
  including nested branches, and report an exact counterexample entry.
  Parser messages identify parse failures without changing public error codes.
- Detect material numerical leakage before certified auxiliary projection,
  preserving exact release certification and unnormalized probability weights.
  Scale only the diagnostic ratio to prevent subnormal or underflowed weights
  from hiding leakage; preserve stored amplitudes and non-finite-weight alarms.
- Harden signed dyadic scaling against a future denominator-bound change and
  make contract-composition basis invariants explicit.
- Clarify CLI bit order and tiny numerical weights; address the reported
  older-Clippy expression/lifetime patterns and add Clippy to the MSRV CI job.
  Actual Rust 1.85 validation also identified test bit-packing expressions;
  explicit parentheses preserve their meaning and satisfy MSRV Clippy.

### Verification

- Validate the 0.1.1 candidate on macOS: 258 tests and all-target Clippy pass
  on both Rust 1.98.1 and minimum Rust 1.85.0. Documentation checks, 39 exact
  assertions, Lean build and the 527-declaration axiom audit, all ten CLI
  projects, Shor, and candidate source packaging/verification pass. Linux CI
  and clean-release-commit packaging are separate publication gates, recorded
  against the exact release commit in the GitHub release record.
- Reproduce the cleanup alarm's underflow failure before fixing it. Add a
  scale-invariance regression covering real/imaginary leakage, both sides of
  the alarm threshold, subnormal and zero-rounded weights, the smallest
  positive amplitude, and unchanged projected amplitude bits.
- Add deterministic generated comparisons of exact circuit matrices with
  numerical execution, adjoints, controls, and retained physical auxiliary
  implementations. See the review disposition
  for checked findings, deferred design changes, and validation results.

## 0.1.0 — 2026-09-27

Initial source release. See the release notes
for usage, verification scope, and known limits. The annotated `v0.1.0` tag
identifies the release commit; the GitHub release records publication.

### Added

- Finite `.qli` parsing, module resolution, type/effect/linear-ownership
  checking, independent raw-IR verification, and reference execution.
- Bundled finite basis, algorithm-routine, transform, and arithmetic
  definitions, with executable quantum-algorithm examples.
- Exact finite semantic contracts `U E_in = E_out u`, compositional evidence,
  and independently checked auxiliary zero return.
- `apply_contract` with immutable function evidence retained through
  composition, axis remapping, adjoint, coherent control, and repetition;
  interchangeable phase-oracle implementations under one fixed client.
- Explicit ownership, semantics, and source/IR specifications; a separate
  Lean development for the recorded ownership and matrix lemmas.
- Apache-2.0 licensing for Qleisli's own code, proofs, examples, and
  documentation, with contribution and versioning policies and explicit
  attribution to Masahiko G. Yamada.
- A Japanese design note on quantum bookkeeping as a language responsibility,
  with QPE, amplitude amplification, and Shor as successive design tests.
- CI coverage for the declared minimum Rust version, 1.85.0, alongside the
  primary Rust toolchain, Lean build/axiom audit, and documentation checks.

### Verification and limits

The release validation record reports the local
245 Rust tests, 14 documentation-checker tests, 39 exact mathematical example
assertions, Lean build and 527-declaration axiom audit, and package validation.
Those are implementation/model checks, not a general proof of the Rust compiler
or noisy-hardware behavior. General size/operation parameters, portable proof
loading, and the v1 algorithm-structure milestone remain open.
