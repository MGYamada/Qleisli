OPENQASM 3.0;
include "stdgates.inc";
qubit[1] q;
bit[1] c;
reset q;
c[0] = measure q[0];
