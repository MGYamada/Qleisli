from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
ROOT=Path('/Users/masa/git/Qleisli')
PACKET=Path('/private/tmp/qleisli-stdlib-exact-v3-86tj659p')
OBS=Path('/private/tmp/qleisli-stdlib-exact-v3-observations-hlydv0l8')
CLI=Path('/private/tmp/qleisli-369-experiment-cli-0yu9btrs/qleisli')
KERNEL=ROOT/'lean-kernel/.lake/build/bin/qleisli-kernel'
CLI_SHA='601ec6e800e70d6d085c69c0fe568add0e2faa6429c02dd78ec7b420a71c6578'
KERNEL_SHA='54c9d60b80f67217abd95c8fe6ec1c06aa262e142d5e6db30f46a20cb90faf07'
PREDECESSORS={
 'first_packet':Path('/private/tmp/qleisli-stdlib-first-sources-03c401uq'),
 'first_observations':Path('/private/tmp/qleisli-stdlib-first-observations-9teutxrb'),
 'v2_packet':Path('/private/tmp/qleisli-stdlib-exact-v2-ektmoa9a'),
 'v2_observations':Path('/private/tmp/qleisli-stdlib-exact-v2-observations-2m3m5r1c')}
# Fresh manually authored case table. No record, plan or saved argv is executed.
CASES=[
 ('t-positive','derived',True),('t-adjoint-positive','derived',True),
 ('t-power-zero-positive','derived',True),('t-power-eight-positive','derived',True),
 ('t-controlled-packed','derived',True),('t-reference-packed','derived',True),
 ('cp-generic-packed','ordinary',True),('cp-fixed-by-derived-t-packed','derived',True),
 ('structural-permute-packed',None,True),('physical-swap-packed',None,True),
 ('t-wrong-global',None,False),('t-erased-phase',None,False),
 ('t-wrong-inverse','derived',False),('t-wrong-reference-axis','derived',False),
 ('cp-wrong-whole-scalar',None,False),('swap-wrong-identity',None,False)]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def filemap(r): return {str(p.relative_to(r)):sha(p) for p in sorted(r.rglob('*')) if p.is_file() and '.lake' not in p.relative_to(r).parts and '__pycache__' not in p.relative_to(r).parts}
def dump(p,d): p.write_text(json.dumps(d,indent=2)+'\n')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
old_context=json.loads((PREDECESSORS['v2_observations']/'context-before.json').read_text())
runtime_paths=set(old_context['runtime_closure'])
for prefix,suffix in [('src','.rs'),('lean-kernel','.lean'),('stdlib/src','.qli')]:
 for p in (ROOT/prefix).rglob('*'+suffix):
  if p.is_file() and '.lake' not in p.relative_to(ROOT).parts: runtime_paths.add(str(p.relative_to(ROOT)))
for p in ['Cargo.toml','Cargo.lock','build.rs','lean-kernel/lean-toolchain','lean-kernel/lakefile.lean','lean-kernel/lakefile.toml','lean-kernel/lake-manifest.json','stdlib/Qargo.toml']:
 if (ROOT/p).is_file(): runtime_paths.add(p)
def context():
 d={'utc':now(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'cli_path':str(CLI),'cli_sha256':sha(CLI),'kernel_path':str(KERNEL),'kernel_sha256':sha(KERNEL),
 'runtime_closure':{p:sha(ROOT/p) if (ROOT/p).is_file() else None for p in sorted(runtime_paths)},
 'v3_packet':filemap(PACKET)}
 for k,r in PREDECESSORS.items(): d[k]=filemap(r)
 return d
assert sha(CLI)==CLI_SHA and sha(KERNEL)==KERNEL_SHA
freeze=json.loads((PACKET/'v3-freeze.json').read_text())
for x in freeze['files']: assert sha(PACKET/x['path'])==x['sha256']
assert len(CASES)==16
identity=CLI.parent/'identity.json'; dump(OBS/'cli-copy-identity.json',json.loads(identity.read_text()))
dump(OBS/'execution-design-before.json',{'schema':3,'authored_before_execution':True,'not_blind_benchmark':True,'source_packet':str(PACKET),'v3_freeze_sha256':sha(PACKET/'v3-freeze.json'),'manual_command_construction':'Literal commands in run-v3.py, no record argv loaded or executed','request_scope':'unchanged preauthored artifact-only requests selected from outset; separate source-step check','cases':[{'id':x,'module_kind':m,'expected_exact_accept':e} for x,m,e in CASES],'max_authored_program_qubits':2,'retained_unchanged_bundled_qft3_allowed':True,'no_retry_or_fallback':True,'runner_sha256':sha(Path(__file__))})
initial=context(); dump(OBS/'context-before.json',initial)
records=[]
def call(case,kind,args):
 d=OBS/'checks'/case/kind; d.mkdir(parents=True)
 before=context(); dump(d/'context-before.json',before)
 started=now(); t=time.monotonic()
 env=os.environ.copy(); env['QLEISLI_KERNEL']=str(KERNEL)
 try:
  p=subprocess.run([str(CLI),*args],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
  stdout,stderr,code=p.stdout,p.stderr,p.returncode; timed_out=False
 except subprocess.TimeoutExpired as e:
  stdout=e.stdout or b''; stderr=e.stderr or b''; code=None; timed_out=True
 (d/'stdout').write_bytes(stdout); (d/'stderr').write_bytes(stderr)
 after=context(); dump(d/'context-after.json',after)
 stable=all(before[k]==after[k] for k in before if k!='utc')
 rec={'schema':3,'case':case,'kind':kind,'fresh_manual_argv':[str(CLI),*args],'cwd':str(ROOT),'started_utc':started,'elapsed_seconds':time.monotonic()-t,'exit_code':code,'timed_out':timed_out,'stdout_sha256':sha(d/'stdout'),'stderr_sha256':sha(d/'stderr'),'identity_stable':stable,'cli_and_kernel_expected_hashes':before['cli_sha256']==CLI_SHA and before['kernel_sha256']==KERNEL_SHA and after['cli_sha256']==CLI_SHA and after['kernel_sha256']==KERNEL_SHA,'head_before':before['head'],'head_after':after['head'],'observation_kind':'real fresh invocation; no retry or fallback'}
 dump(d/'record.json',rec); records.append(rec)
 print(json.dumps({'case':case,'kind':kind,'exit_code':code,'identity_stable':stable}),flush=True)
 return rec
(OBS/'artifacts').mkdir()
results=[]
for case,module_kind,expected in CASES:
 modules=['--module=main='+str(PACKET/'cases'/case/'main.qli')]
 if module_kind=='derived': modules.insert(0,'--module=derived='+str(PACKET/'common/derived-current.qli'))
 if module_kind=='ordinary': modules.append('--module=ordinary='+str(PACKET/'common/generic-cp-current.qli'))
 artifact=OBS/'artifacts'/(case+'.qirf.json')
 emit=call(case,'emit',['emit-proposal','--entry=main::entry','--ir-profile=raw','--format=json','--output='+str(artifact),*modules])
 verify=None
 if emit['exit_code']==0 and artifact.is_file():
  verify=call(case,'verify-exact-artifact',['verify-ir',str(artifact),'--against='+str(PACKET/'requests'/(case+'-artifact-only.json')),'--lean-kernel='+str(KERNEL),'--format=json'])
 else:
  d=OBS/'checks'/case/'verify-exact-artifact'; d.mkdir(parents=True); dump(d/'unperformed.json',{'reason':'required emitted artifact unavailable; no retry or fallback','emit_exit_code':emit['exit_code'],'artifact_exists':artifact.is_file()})
 source=call(case,'source-step-check',['check','--entry=main::entry','--ir-profile=raw','--lean-kernel='+str(KERNEL),'--format=json',*modules])
 results.append({'id':case,'expected_exact_accept':expected,'emit_exit_code':emit['exit_code'],'artifact_path':str(artifact) if artifact.is_file() else None,'artifact_sha256':sha(artifact) if artifact.is_file() else None,'verify_exit_code':verify['exit_code'] if verify else None,'source_exit_code':source['exit_code'],'exact_prediction_matches':(verify['exit_code']==0)==expected if verify else None,'all_invocation_windows_stable':emit['identity_stable'] and (verify['identity_stable'] if verify else True) and source['identity_stable']})
 dump(OBS/'structured-results.json',results)
final=context(); dump(OBS/'context-after.json',final); dump(OBS/'all-observations.json',records)
summary={'case_count':len(results),'actual_invocations':len(records),'emitted_artifacts':sum(x['artifact_path'] is not None for x in results),'exact_request_accepted':sum(x['verify_exit_code']==0 for x in results),'exact_request_refused':sum(x['verify_exit_code'] not in [None,0] for x in results),'source_steps_accepted':sum(x['source_exit_code']==0 for x in results),'prediction_mismatches':[x['id'] for x in results if x['exact_prediction_matches'] is False],'blocked':[x['id'] for x in results if x['artifact_path'] is None],'all_per_invocation_windows_stable':all(x['identity_stable'] for x in records),'whole_window_stable':all(initial[k]==final[k] for k in initial if k!='utc'),'head_start':initial['head'],'head_finish':final['head'],'original_predecessors_unchanged':all(initial[k]==final[k] for k in PREDECESSORS),'v3_packet_unchanged':initial['v3_packet']==final['v3_packet'],'runtime_closure_unchanged':initial['runtime_closure']==final['runtime_closure']}
dump(OBS/'summary.json',summary); print(json.dumps(summary,indent=2),flush=True)
