# Informed stdlib exact follow-up v3: manifest-corrected observations

The new input packet is /private/tmp/qleisli-stdlib-exact-v3-86tj659p. Its
v3-freeze.json SHA256 is
03546a7847dd6170eb74baefd8253ebf6616fc7b859bd306e68ce337d9f455ee.
It copies all 91 v2 files byte-for-byte and adds the missing schema-2,
edition-2026 common/Qargo.toml plus V3-PLAN.md. All 16 programs, preauthored
requests and independent matrix files are unchanged. The copied v2 plans and
absolute paths remain historical records, not executed instructions. This is
informed follow-up after v2's real edition failures, not a blind benchmark.

## Actual bounded results

All 16 unary selected Raw roots emitted; all 16 separate native source-step
checks accepted. All 48 fresh literal invocations completed without retry or
fallback. Independent preauthored artifact-only exact requests accepted the
10 positives and refused the 6 negatives, with no prediction mismatch.

Positives: derived T, T adjoint, T^0, T^8, controlled T on an ordered packed
pair, T beside one owned reference, ordinary generic CP[1,3], fixed CP derived
from T, structural permutation and three-CNOT physical SWAP. Negatives:
wrong global T phase, erased T phase, wrong inverse, T on the wrong reference
axis, whole-scalar CP and identity claimed as SWAP. All six artifacts remain
native-valid with independently rejected requested meanings. The refusal JSON
reports contract rejection; it does not expose a finer equation diagnostic.

The checks directly consume unchanged exact phase8/permutation requests. The
separately authored R8 matrix files are preserved mathematical inputs but were
NOT passed to a dense-matrix API; no direct check of those file encodings is
claimed. Artifact equality is not a source-to-IR preservation theorem.

## Actual artifact inspection

All 16 artifacts have their predeclared ordered input/output wire maps, and
none introduces a physical wire. An independent Python token/wire traversal
records every actual operation and its live wires in artifact-inspections.json.
This is descriptive inspection of these artifacts, not a certified backend
resource bound.

Direct T packs a zero-width Unit owner, joins it beside physical wire 0,
applies a scalar phase8(1) monomial with no action indices controlled by wire
0, splits, and unpacks the empty Unit owner. No initialized ancilla or extra
physical wire appears. T adjoint collapses to one scalar phase8(7) controlled
step with no pack/unpack. T^0 emits no operations. T^8 retains eight explicit
Unit pack/join/phase/split/unpack blocks even though its exact requested map is
identity; exact equality does not imply an optimization or cost claim. The
one-reference positive applies T on wire 0 and retains reference wire 1.

Generic CP emits phase8 [0,1] on action wire 1 controlled by wire 0. CP derived
from T and controlled T emit scalar phase8(1) with controls on wires 1 and 0.
Their root map remains [0,1]. CP's symmetric diagonal does not by itself
distinguish exchanged owner roles; no noncommuting role probe or general
arbitrary-reference theorem was added.

Structural SWAP has split+join and output wire map [1,0]. Physical SWAP has
split+three cnot+join, actual CNOT directions 0->1, 1->0, 0->1, and output
wire map [0,1]. Both satisfy the same independently requested exact SWAP map,
with distinct actual emitted operations and routing. No synthesized target
gate/depth/workspace certificate follows from these counts.

## Binding and limits

All 48 per-invocation windows and the whole execution window stayed stable.
HEAD was 79f4abeabfe8e721f68a3d39135d3fd04caa5ea2 throughout. Every current
runtime-closure hash, immutable CLI, explicit native kernel, all four
predecessor directories and the v3 frozen packet were checked before/after
every invocation and stayed unchanged. The CLI SHA256 is
601ec6e800e70d6d085c69c0fe568add0e2faa6429c02dd78ec7b420a71c6578; the
kernel SHA256 is
54c9d60b80f67217abd95c8fe6ec1c06aa262e142d5e6db30f46a20cb90faf07.
cli-copy-identity.json states the actual runtime build and its limitations.
These byte identities are not a source/compiler/runtime correctness proof;
native JSON checker_identity is still unpinned.

All 16 separate source reports state native-validity, source_steps_checked=true,
source_meaning_verified=false and source_preservation_verified=false. The
10 successful exact checks state request_checked=true and
source_preservation_verified=false. Emitted source tables are empty, and the
chosen requests intentionally omit source_snapshot. No stronger source-bound
request was retried through a weaker request.

The experiment has no blocked case. It changes no repository file, build,
commit, CI, production API, adopted interpretation or guarantee. Authored
programs use at most two qubits; the allowed unchanged bundled QFT3 was not
needed by these selected-only invocations. No hardware, PR, quantitative RS,
EXACT discharge, general compiler/source preservation, arbitrary-reference
proof or certified target/resource bound is claimed. Original first sources,
128 first observations, v2 sources and all v2 observations remain unchanged.

Constitutional continuity was checked against previously reviewed
28c6e75ac7341e53f8a06c22bd6634b8cbbc38cb before execution and passed; this
is identity/continuity checking, not a new Lean replay or admission.

See summary.json, structured-results.json, all-observations.json,
artifact-inspections.json and each checks/<case>/<kind> record/stdout/stderr
and before/after context.
