import QleisliKernel.Qirf.EngineeringInstrument

/-! TEMP TP-31-TARGET-QASM-01 (P1): independent canonical target-byte study.
Replace after specification review and production integration; preserve sources
and failures. This fixed one-qubit terminal profile is not general OpenQASM,
source/export preservation, target semantics adoption, native API, PR or RS.
Copyright 2026 Qleisli Project Contributors. SPDX-License-Identifier: Apache-2.0 -/
namespace CanonicalTarget
open QleisliKernel QleisliKernel.Finite QleisliKernel.Semantics.Exact
open QleisliKernel.Semantics.Raw QleisliKernel.Semantics.Observation

inductive Gate where
  | h | x | y | z | s | sdg | t | tdg
  deriving BEq, DecidableEq, Repr

structure Decoded where
  original : ByteArray
  gates : List Gate
  deriving BEq

private def ascii (text : String) : List UInt8 := text.toUTF8.data.toList

private def gate (line : List UInt8) : Except String Gate :=
  if line == ascii "h q[0];" then .ok .h
  else if line == ascii "x q[0];" then .ok .x
  else if line == ascii "y q[0];" then .ok .y
  else if line == ascii "z q[0];" then .ok .z
  else if line == ascii "s q[0];" then .ok .s
  else if line == ascii "sdg q[0];" then .ok .sdg
  else if line == ascii "t q[0];" then .ok .t
  else if line == ascii "tdg q[0];" then .ok .tdg
  else .error "unsupported canonical gate"

private def word : List (List UInt8) → Except String (List Gate)
  | line :: [] :: [] =>
      if line == ascii "c[0] = measure q[0];" then .ok []
      else .error "missing terminal measurement"
  | line :: rest => do
      let first ← gate line
      return first :: (← word rest)
  | [] => .error "missing terminal measurement"

private def lines (bytes : List UInt8) : List (List UInt8) :=
  bytes.foldr (fun byte rest =>
    if byte == 10 then [] :: rest else match rest with
    | [] => [[byte]]
    | line :: tail => (byte :: line) :: tail) [[]]

private def header : List (List UInt8) :=
  ["OPENQASM 3.0;","include \"stdgates.inc\";","qubit[1] q;","bit[1] c;","reset q;"].map ascii

/-- Literal ASCII header/include means no file is loaded and no UTF-8 runtime
primitive determines the grammar. Exact byte/line syntax and terminal order
reject all unsupported input. Temporary capacities are explicit. -/
def decode (bytes : ByteArray) : Except String Decoded :=
  if bytes.size > 1024 then .error "temporary target byte limit"
  else if !(bytes.data.toList.all fun byte => byte.toNat < 128) then .error "target ASCII"
  else
    let all := lines bytes.data.toList
    if all.take 5 != header then .error "unsupported canonical target header"
    else
      let rest := all.drop 5
      if rest.length > 10 then .error "temporary gate word limit"
      else (word rest).map (fun gates => ⟨bytes,gates⟩)

/-- The retained subject is the literal input bytes, without a reconstructed
text or producer digest replacing the actual target artifact. -/
theorem decode_original (bytes : ByteArray) (decoded : Decoded)
    (ok : decode bytes = .ok decoded) : decoded.original = bytes := by
  unfold decode at ok
  split at ok
  · cases ok
  · split at ok
    · cases ok
    · dsimp only at ok
      split at ok
      · cases ok
      · dsimp only at ok
        split at ok
        · cases ok
        · cases value : word (List.drop 5 (lines bytes.data.toList)) with
          | error error => simp [value,Except.map] at ok
          | ok gates =>
            simp only [value,Except.map,Except.ok.injEq] at ok
            subst decoded
            rfl

private def phaseStep (phase : Nat) : Semantics.Finite.Step :=
  ⟨[],.monomial [0] [0,1] [0,phase]⟩

def gateOp (g : Gate) (input output : Nat) : Semantics.Observation.Op := .pure <| match g with
  | .h => .gate .h input output
  | .x => .gate .x input output
  | .y => .applyUnitary input output [⟨[],.monomial [0] [1,0] [2,6]⟩]
  | .z => .gate .z input output
  | .s => .applyUnitary input output [phaseStep 2]
  | .sdg => .applyUnitary input output [phaseStep 6]
  | .t => .gate .t input output
  | .tdg => .applyUnitary input output [phaseStep 7]

def program (gates : List Gate) : Semantics.Observation.Program :=
  let (owner,ops) := gates.foldl (fun (owner,ops) g =>
    (owner+1,ops ++ [gateOp g owner (owner+1)])) (1,[])
  ⟨[⟨0,[],0⟩],[],[.pure (.unpackUnit 0),.pure (.init0 1 0)] ++ ops ++ [.measure owner 0],
    [],[0],.observe⟩

/-- The adapter retains a zero-width logical input and consumes it explicitly;
physical reset becomes zero preparation only for this closed terminal profile. -/
def artifact (decoded : Decoded) : Qirf.Artifact :=
  ⟨#[program decoded.gates],#[],#[],0,none⟩

theorem logical_unit_input (gates : List Gate) :
    (program gates).inputs = [⟨0,[],0⟩] := rfl

theorem logical_unit_consumed (gates : List Gate) :
    (program gates).operations.head? = some (.pure (.unpackUnit 0)) := by
  simp [program]

theorem terminal_result (gates : List Gate) :
    (program gates).outputs = [] ∧ (program gates).classicalOutputs = [0] ∧
      (program gates).effect = .observe := ⟨rfl,rfl,rfl⟩

def signature : Semantics.InstrumentContract.Signature := ⟨[.unit],[.bit]⟩

def ideal : Qirf.Artifact :=
  ⟨#[program [.h]],#[],#[],0,none⟩

def request (decoded : Decoded) (epsilon : Coefficient) (majorants : List Coefficient) :
    Qirf.EngineeringInstrument.Request :=
  ⟨artifact decoded,#[0],ideal,#[0],signature,signature,
    ⟨"canonical-target","manual-uniform-ideal",[]⟩,
    epsilon,majorants⟩

structure Retained where
  decoded : Decoded
  epsilon : Coefficient
  majorants : List Coefficient
  checked : Qirf.EngineeringInstrument.Checked

private def adapt {α : Type} (value : Except String α) : WorkM α :=
  lift (value.mapError fun _ => .invalid)

/-- One conceptual retained invocation builds the actual graph exclusively
from the independently decoded target bytes and freshly checks both meanings. -/
def check (bytes : ByteArray) (epsilon : Coefficient) (majorants : List Coefficient) : WorkM Retained := do
  let decoded ← adapt (decode bytes)
  let checked ← Qirf.EngineeringInstrument.check (request decoded epsilon majorants)
  return ⟨decoded,epsilon,majorants,checked⟩

structure Binding (bytes : ByteArray) (epsilon : Coefficient) (majorants : List Coefficient)
    (retained : Retained) (work left : Nat) : Prop where
  decoded : decode bytes = .ok retained.decoded
  epsilonBound : retained.epsilon = epsilon
  majorantsBound : retained.majorants = majorants
  executed : (Qirf.EngineeringInstrument.check (request retained.decoded epsilon majorants)).run work =
    (.ok retained.checked,left)

theorem check_bound (bytes : ByteArray) (epsilon : Coefficient) (majorants : List Coefficient)
    (retained : Retained) (work left : Nat)
    (ok : (check bytes epsilon majorants).run work = (.ok retained,left)) :
    Binding bytes epsilon majorants retained work left := by
  obtain ⟨decoded,a,hd,h⟩ := bind_success _ _ _ _ _ ok
  have first := lift_success _ _ _ _ hd
  have decodedBound : decode bytes = .ok decoded := by
    cases value : decode bytes <;> simp_all [adapt,Except.mapError]
  obtain ⟨checked,b,hc,h⟩ := bind_success _ _ _ _ _ h
  obtain ⟨rfl,rfl⟩ := pure_success _ _ _ _ h
  have same := first.2
  subst a
  exact ⟨decodedBound,rfl,rfl,hc⟩

end CanonicalTarget
