import hashlib, json, os, re, signal, subprocess, sys, time
from pathlib import Path
R=Path('/Users/masa/git/Qleisli');Q=Path('/Users/masa/git/qlirgo');P=Path('/private/tmp/qleisli-helper-resume-20261021')
which=sys.argv[1]; assert which in ['normal','msrv'];O=P/('helper-field-'+which+'-rust-v2');O.mkdir();K=R/'lean-kernel/.lake/build/bin/qleisli-kernel'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def state(root):
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'files':{n:digest(root/n) if (root/n).is_file() else 'missing' for n in sorted(set(filter(None,names)))}}
def snap():return {'root':state(R),'qlirgo':state(Q),'kernel':digest(K)}
lean=json.loads((P/'helper-field-full-lean/registry.json').read_bytes());assert lean['status']=='passed'
before=snap();(O/'before.json').write_text(json.dumps(before,indent=2)+'\n');(O/'observer.py').write_bytes(Path(__file__).read_bytes());
bin=Path('/opt/homebrew/bin') if which=='normal' else Path('/Users/masa/.rustup/toolchains/1.85.0-aarch64-apple-darwin/bin')
cargo=str(bin/'cargo');env=os.environ.copy();env.update(PATH=str(bin)+':'+env['PATH'],RUSTC=str(bin/'rustc'),RUSTDOC=str(bin/'rustdoc'),CARGO_TARGET_DIR=str(R/'target'),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',QLEISLI_KERNEL=str(K))
commands=[('cargo-version',[cargo,'--version']),('rustc-version',[str(bin/'rustc'),'--version']),('all-targets',[cargo,'check','--locked','--offline','--all-targets']),('native',['/opt/homebrew/bin/python3','scripts/run_kernel_tests.py','--',cargo,'test','--locked','--offline','--lib','interchange::native','--','--include-ignored','--nocapture'])]
if which=='normal':commands += [('clippy',[cargo,'clippy','--locked','--offline','--all-targets','--','-D','warnings']),('fmt',[cargo,'fmt','--all','--check'])]
(O/'plan.json').write_text(json.dumps({'commands':commands,'environment':{k:env[k] for k in ['PATH','RUSTC','RUSTDOC','CARGO_TARGET_DIR','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','QLEISLI_KERNEL']}},indent=2)+'\n')
rows=[];ok=True
for name,argv in commands:
 if not ok:rows.append({'name':name,'executed':False});continue
 print('START '+which+' '+name,flush=True);start=time.monotonic();timeout=False
 with (O/(name+'.stdout')).open('wb') as out,(O/(name+'.stderr')).open('wb') as err:
  process=subprocess.Popen(argv,cwd=R,env=env,stdout=out,stderr=err,start_new_session=True)
  (O/'live.json').write_text(json.dumps({'name':name,'pid':process.pid,'limit_seconds':900})+'\n')
  try:code=process.wait(timeout=900)
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
   code=process.returncode
 row={'name':name,'argv':argv,'exit_code':code,'timeout':timeout,'seconds':time.monotonic()-start,'stdout_sha256':digest(O/(name+'.stdout')),'stderr_sha256':digest(O/(name+'.stderr'))};rows.append(row);ok=code==0 and not timeout;print(json.dumps(row),flush=True)
 if not ok:
  for suffix in ['stdout','stderr']:
   with (O/(name+'.'+suffix)).open('rb') as f:f.seek(max(0,(O/(name+'.'+suffix)).stat().st_size-2500));print(f.read(2500).decode(errors='replace'),flush=True)
after=snap();summaries=[]
if (O/'native.stdout').exists():
 with (O/'native.stdout').open(errors='replace') as stream:
  summaries=[line.strip() for line in stream if line.startswith(('test result:','native test gate:'))]
 ok=ok and len(summaries)==2 and '21 passed; 0 failed; 0 ignored' in summaries[0] and summaries[1]=='native test gate: zero conditional native skips'
report={'format':'qleisli.helper-field-rust-validation','version':1,'toolchain':which,'commands':rows,'before':before,'after':after,'source_windows_unchanged':before==after,'test_summaries':summaries,'pass':ok and before==after}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['toolchain','pass','source_windows_unchanged','test_summaries']}),flush=True);sys.exit(0 if report['pass'] else 1)
