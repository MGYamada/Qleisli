#!/usr/bin/env python3
"""Capture bounded documentation and scheduling checks, without native builds.

Copyright 2026 Masahiko G. Yamada. SPDX-License-Identifier: Apache-2.0
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
MDBOOK = Path("/private/tmp/qleisli-mdbook-0.5.4-bin/mdbook")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def selected_inputs():
    paths = set(ROOT.glob("*.md"))
    paths.update((ROOT / "docs/src").rglob("*.md"))
    paths.add(ROOT / "docs/book.toml")
    paths.update(ROOT / name for name in (
        "scripts/check_docs.py", "scripts/check_book.py",
        "scripts/check_authoring_sessions.py", "scripts/test_run_native_ci.py",
        "scripts/run_native_ci.py", "scripts/native_harness.py",
        ".github/ci/native-comparisons.json", ".github/workflows/ci.yml",
        ".github/ci/README.md", "tests/quantum_unit_source.rs",
        "tests/fixtures/authoring_sessions/README.md",
    ))
    paths.update((ROOT / "tests/fixtures/authoring_sessions").glob("*/session.json"))
    study = ROOT / "tests/fixtures/authoring_sessions/quantum-unit-v030"
    paths.update(path for path in study.rglob("*") if path.is_file() and "__pycache__" not in path.parts)
    return {str(path.relative_to(ROOT)): sha(path) for path in sorted(paths) if path.is_file()}


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("attempt", choices=("initial", "scheduler-fixed", "scheduler-final"))
    args = parser.parse_args()
    destination = HERE / args.attempt
    destination.mkdir(exist_ok=False)
    commands = [["python3", "scripts/test_run_native_ci.py"]]
    if args.attempt == "initial":
        commands += [
            ["python3", "scripts/check_docs.py"],
            [str(MDBOOK), "--version"],
            [str(MDBOOK), "build", "docs"],
            ["python3", "scripts/check_book.py"],
            ["python3", "scripts/check_authoring_sessions.py"],
            ["python3", "scripts/run_native_ci.py", "--help"],
            ["python3", str(HERE.relative_to(ROOT) / "check_manifest.py")],
        ]
    before = selected_inputs()
    write(destination / "inputs-before.json", before)
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    metadata = {
        "attempt": args.attempt, "cwd": str(ROOT),
        "environment_overrides": {"PYTHONDONTWRITEBYTECODE": "1"},
        "selected_input_scope": "Selected documentation, checker/scheduler, all authoring session manifests and original quantum-unit study files; not a full repository snapshot.",
        "mdbook": {"path": str(MDBOOK), "sha256": sha(MDBOOK)},
        "recorder_sha256": sha(Path(__file__)),
        "commands": [],
    }
    write(destination / "commands.json", metadata)
    for index, argv in enumerate(commands, 1):
        start = datetime.now(timezone.utc).isoformat()
        clock = time.monotonic()
        result = subprocess.run(argv, cwd=ROOT, env=environment, capture_output=True, check=False)
        elapsed = time.monotonic() - clock
        out, err = destination / f"{index}.stdout.txt", destination / f"{index}.stderr.txt"
        out.write_bytes(result.stdout)
        err.write_bytes(result.stderr)
        metadata["commands"].append({
            "argv": argv, "cwd": str(ROOT), "started_at_utc": start,
            "elapsed_seconds": elapsed, "exit_code": result.returncode,
            "stdout": out.name, "stdout_sha256": sha(out),
            "stderr": err.name, "stderr_sha256": sha(err),
        })
        write(destination / "commands.json", metadata)
        print(f"{index}: exit {result.returncode}: {' '.join(argv)}", flush=True)
    after = selected_inputs()
    write(destination / "inputs-after.json", after)
    changed = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
    write(destination / "result.json", {
        "attempt": args.attempt,
        "all_commands_passed": all(command["exit_code"] == 0 for command in metadata["commands"]),
        "command_count": len(metadata["commands"]),
        "selected_inputs_count": len(before), "selected_inputs_changed": changed,
        "commands_sha256": sha(destination / "commands.json"),
        "inputs_before_sha256": sha(destination / "inputs-before.json"),
        "inputs_after_sha256": sha(destination / "inputs-after.json"),
        "scope": "Actual documentation/authoring-integrity checks and scheduler unit tests. The selected manifest loader does not execute native comparisons; no Rust or Lean build was requested by this driver.",
    })


if __name__ == "__main__":
    main()
